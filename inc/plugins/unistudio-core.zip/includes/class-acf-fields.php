<?php

namespace UniStudioCore;

class ACF_Fields {
    private static $instance = null;
    private $is_acf_pro = false;
    
    public static function getInstance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Check if ACF PRO is available
        $this->is_acf_pro = class_exists('acf_pro');
        
        add_action('acf/init', [$this, 'register']);
        add_action('acf/save_post', [$this, 'sync_section_type_taxonomy'], 20);
    }

    public function register() {
        // Check if ACF is active
        if (!class_exists('ACF')) {
            add_action('admin_notices', [$this, 'acf_missing_notice']);
            return;
        }

        // Register the Page Settings fields
        $this->register_page_settings_fields();
        
        // Register Global Layout Settings
        $this->register_global_section_settings();
    }

    public function acf_missing_notice() {
        ?>
        <div class="notice notice-warning">
            <p><?php _e('ACF PRO is required for important plugin features. Please install and activate ACF PRO.', 'unistudio-core'); ?></p>
        </div>
        <?php
    }

    private function register_page_settings_fields() {
        if (!function_exists('acf_add_local_field_group')) {
            return;
        }

        acf_add_local_field_group([
            'key' => 'group_page_settings',
            'title' => __('Page Settings', 'unistudio-core'),
            'fields' => [
                // Tab - General
                [
                    'key' => 'tab_general',
                    'label' => 'General',
                    'type' => 'tab',
                    'placement' => 'top',
                ],
                [
                    'key' => 'field_page_header_layout',
                    'label' => __('Page Cover Layout', 'unistudio-core'),
                    'name' => 'page_header_layout',
                    'type' => 'button_group',
                    'choices' => [
                        'default' => __('Full Width', 'unistudio-core'),
                        'boxed' => __('Main Content', 'unistudio-core'),
                        'disabled' => __('Disabled', 'unistudio-core'),
                    ],
                    'default_value' => 'default',
                    'layout' => 'horizontal',
                ],
                [
                    'key' => 'field_page_header_template',
                    'label' => __('Page Cover Template', 'unistudio-core'),
                    'instructions' => __('By default inherits the option from Customizer > General Settings > Blog Archive > General.', 'unistudio-core'),
                    'name' => 'page_header_template',
                    'type' => 'button_group',
                    'choices' => [
                        'default' => __('Inherit from Theme', 'unistudio-core'),
                        'custom' => __('Global Sections', 'unistudio-core'),
                    ],
                    'default_value' => 'default',
                    'layout' => 'horizontal',
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_page_header_layout',
                                'operator' => '!=',
                                'value' => 'disabled',
                            ]
                        ]
                    ]
                ],
                [
                    'key' => 'field_page_cover_override',
                    'label' => __('Select Page Cover Template', 'unistudio-core'),
                    'name' => 'page_cover_override',
                    'type' => 'post_object',
                    'instructions' => __('Choose a pre-made page header / cover template via Elementor', 'unistudio-core'),
                    'required' => 0,
                    'post_type' => ['uc_global_sections'],
                    'taxonomy' => [
                        'uc_section_type:pagecover'
                    ],
                    'allow_null' => 1,
                    'multiple' => 0,
                    'return_format' => 'id',
                    'ui' => 1,
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_page_header_template',
                                'operator' => '==',
                                'value' => 'custom',
                            ]
                        ]
                    ]
                ],
                [
                    'key' => 'field_breadcrumbs',
                    'label' => __('Breadcrumbs', 'unistudio-core'),
                    'name' => 'breadcrumbs',
                    'type' => 'true_false',
                    'ui' => true,
                    'default_value' => 1,
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_page_header_layout',
                                'operator' => '!=',
                                'value' => 'disabled',
                            ]
                        ]
                    ]
                ],
                [
                    'key' => 'field_page_template',
                    'label' => __('Sidebar', 'unistudio-core'),
                    'instructions' => __('By default inherits the option from Customizer > General Settings > Site Layout.', 'unistudio-core'),
                    'name' => 'page_template',
                    'type' => 'button_group',
                    'choices' => [
                        'default' => __('Inherit', 'unistudio-core'),
                        'sidebar-right' => __('Right Sidebar', 'unistudio-core'),
                        'sidebar-left' => __('Left Sidebar', 'unistudio-core'),
                        'full-width' => __('Disabled', 'unistudio-core'),
                    ],
                    'default_value' => 'default',
                    'layout' => 'horizontal'
                ],
                [
                    'key' => 'field_body_class',
                    'label' => __('Body Custom Class', 'unistudio-core'),
                    'name' => 'body_custom_class',
                    'type' => 'text',
                    'instructions' => __('Add custom CSS classes to the body tag', 'unistudio-core'),
                ],

                // Tab - Header
                [
                    'key' => 'tab_header',
                    'label' => 'Header',
                    'type' => 'tab',
                    'placement' => 'top',
                ],
                [
                    'key' => 'field_header_type',
                    'label' => __('Header Type', 'unistudio-core'),
                    'instructions' => __('A Global Section is a block of content built with Elementor, that\'s embedded into the website. To use or create more Header global sections, head over to Global Sections. <b>By default inherits the option from Customizer > Header > General</b>.', 'unistudio-core'),
                    'name' => 'header_type',
                    'type' => 'button_group',
                    'choices' => [
                        'disabled' => __('Disable Header', 'unistudio-core'),
                        'inherit' => __('Inherits option', 'unistudio-core'),
                        'theme' => __('Theme Header', 'unistudio-core'),
                        'custom' => __('Global Sections', 'unistudio-core'),
                    ],
                    'default_value' => 'inherit',
                    'layout' => 'horizontal',
                ],
                [
                    'key' => 'field_header_override',
                    'label' => __('Select Header Template', 'unistudio-core'),
                    'name' => 'header_override',
                    'type' => 'post_object',
                    'instructions' => __('Choose a pre-made header template', 'unistudio-core'),
                    'required' => 0,
                    'post_type' => ['uc_global_sections'],
                    'taxonomy' => [
                        'uc_section_type:header'
                    ],
                    'allow_null' => 1,
                    'multiple' => 0,
                    'return_format' => 'id',
                    'ui' => 1,
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_header_type',
                                'operator' => '==',
                                'value' => 'custom',
                            ]
                        ]
                    ]
                ],

                // Tab - Footer
                [
                    'key' => 'tab_footer',
                    'label' => 'Footer',
                    'type' => 'tab',
                    'placement' => 'top',
                ],
                [
                    'key' => 'field_footer_type',
                    'label' => __('Footer Type', 'unistudio-core'),
                    'instructions' => __('A Global Section is a block of content built with Elementor, that\'s embedded into the website. To use or create more Header global sections, head over to Global Sections. <b>By default inherits the option from Customizer > Footer > General</b>.', 'unistudio-core'),
                    'name' => 'footer_type',
                    'type' => 'button_group',
                    'choices' => [
                        'disabled' => __('Disable Footer', 'unistudio-core'),
                        'inherit' => __('Inherits option', 'unistudio-core'),
                        'theme' => __('Theme Footer', 'unistudio-core'),
                        'custom' => __('Global Sections', 'unistudio-core'),
                    ],
                    'default_value' => 'inherit',
                    'layout' => 'horizontal',
                ],
                [
                    'key' => 'field_footer_override',
                    'label' => __('Select Footer Template', 'unistudio-core'),
                    'name' => 'footer_override',
                    'type' => 'post_object',
                    'instructions' => __('Choose a footer template', 'unistudio-core'),
                    'required' => 0,
                    'post_type' => ['uc_global_sections'],
                    'taxonomy' => [
                        'uc_section_type:footer'
                    ],
                    'allow_null' => 1,
                    'multiple' => 0,
                    'return_format' => 'id',
                    'ui' => 1,
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_footer_type',
                                'operator' => '==',
                                'value' => 'custom',
                            ]
                        ]
                    ]
                ],
            ],
            'location' => [
                [
                    [
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'page',
                    ],
                ],
                [
                    [
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'post',
                    ],
                ],
                [
                    [
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'uc_portfolio',
                    ],
                ],
            ],
            'menu_order' => 0,
            'position' => 'normal',
            'style' => 'normal',
            'label_placement' => 'top',
            'instruction_placement' => 'field',
            'hide_on_screen' => '',
            'active' => true,
            'description' => __('Configure page-specific settings and overrides', 'unistudio-core'),
        ]);
    }

    private function register_global_section_settings() {
        if (!function_exists('acf_add_local_field_group')) {
            return;
        }

        $display_rules_choices = [
            'entire_site' => __('Entire Site', 'unistudio-core'),
            'singular' => __('Singular', 'unistudio-core'),
            'archive' => __('Archive', 'unistudio-core'),
            'taxonomies' => __('Taxonomies', 'unistudio-core'),
            'specific_pages' => __('Specific Pages', 'unistudio-core'),
            'specific_posts' => __('Specific Posts', 'unistudio-core'),
            'specific_projects' => __('Specific Projects', 'unistudio-core'),
            'post_types' => __('Post Types', 'unistudio-core'),
            'error_page' => __('Error Page', 'unistudio-core'),
        ];
        
        acf_add_local_field_group([
            'key' => 'group_global_layout_settings',
            'title' => __('Global Section Settings', 'unistudio-core'),
            'fields' => [
                [
                    'key' => 'field_global_section_type',
                    'label' => __('Global Section Type', 'unistudio-core'),
                    'name' => 'global_section_type',
                    'type' => 'button_group',
                    'required' => 1,
                    'choices' => [
                        'generic' => __('Generic', 'unistudio-core'),
                        'header' => __('Header', 'unistudio-core'),
                        'footer' => __('Footer', 'unistudio-core'),
                        'megamenu' => __('Mega Menu', 'unistudio-core'),
                        'offcanvas' => __('Off Canvas', 'unistudio-core'),
                        'popup' => __('Popup', 'unistudio-core'),
                        'card' => __('Dynamic Card', 'unistudio-core'),
                        'pagecover' => __('Page Cover', 'unistudio-core'),
                    ],
                    'default_value' => 'generic',
                    'layout' => 'horizontal',
                ],
                [
                    'key' => 'field_global_section_type_generic',
                    'message' => sprintf(__('Generic sections can be assigned to different page positions, either in Customizer\'s <a href="%s" target="_blank">Global Sections</a> panel (for global use), or for specific pages - into the page (or taxonomy) custom options, or in various places inside the content, See documentation for more details.', 'unistudio-core'), esc_url(wp_customize_url() . '?autofocus[section]=polysaas_global_sections')),
                    'name' => 'global_section_type_generic',
                    'type' => 'message',
                    'wrapper' => [
                        'class' => 'section-type-message',
                    ],
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'generic',
                            ],
                        ],
                    ],
                ],
                [
                    'key' => 'field_global_section_type_header',
                    'message' => sprintf(__('Build your website Headers with Elementor. Headers need to be manually assigned in Customizer\'s <a href="%s" target="_blank">Header</a> panel, or for specific pages - into the page (or taxonomy) custom options, See documentation for more details.', 'unistudio-core'), esc_url(wp_customize_url() . '?autofocus[control]=polysaas_header_layout_type')),
                    'name' => 'global_section_type_header',
                    'type' => 'message',
                    'wrapper' => [
                        'class' => 'section-type-message',
                    ],
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'header',
                            ],
                        ],
                    ],
                ],
                [
                    'key' => 'field_global_section_type_footer',
                    'message' => sprintf(__('Build your website Footers with Elementor. Footers need to be manually assigned in Customizer\'s <a href="%s" target="_blank">Footer</a> panel, or for specific pages - into the page (or taxonomy) custom options, See documentation for more details.', 'unistudio-core'), esc_url(wp_customize_url() . '?autofocus[control]=polysaas_footer_layout_type')),
                    'name' => 'global_section_type_footer',
                    'type' => 'message',
                    'wrapper' => [
                        'class' => 'section-type-message',
                    ],
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'footer',
                            ],
                        ],
                    ],
                ],
                [
                    'key' => 'field_global_section_type_megamenu',
                    'message' => __('Embed Elementor built mega menus to the header\'s main menu items.', 'unistudio-core'),
                    'name' => 'global_section_type_megamenu',
                    'type' => 'message',
                    'wrapper' => [
                        'class' => 'section-type-message',
                    ],
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'megamenu',
                            ],
                        ],
                    ],
                ],
                [
                    'key' => 'field_global_section_type_offcanvas',
                    'message' => __('Create and display any type of content into animated side panels.', 'unistudio-core'),
                    'name' => 'global_section_type_offcanvas',
                    'type' => 'message',
                    'wrapper' => [
                        'class' => 'section-type-message',
                    ],
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'offcanvas',
                            ],
                        ],
                    ],
                ],
                [
                    'key' => 'field_global_section_type_popup',
                    'message' => __('Create and display any type of content into popup modals.', 'unistudio-core'),
                    'name' => 'global_section_type_popup',
                    'type' => 'message',
                    'wrapper' => [
                        'class' => 'section-type-message',
                    ],
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'popup',
                            ],
                        ],
                    ],
                ],
                [
                    'key' => 'field_global_section_type_card',
                    'message' => __('Create custom templates with Elementor to be used in widgets such as Grid, Carousel, Tabs or Accordions, making great use of UniCore Dynamic Tags module. This will allow you to build dynamic listings based on various content sources.', 'unistudio-core'),
                    'name' => 'global_section_type_card',
                    'type' => 'message',
                    'wrapper' => [
                        'class' => 'section-type-message',
                    ],
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'card',
                            ],
                        ],
                    ],
                ],
                [
                    'key' => 'field_global_section_type_pagecover',
                    'message' => __('Create unlimited page header/cover layouts and styles and display them conditionally.', 'unistudio-core'),
                    'name' => 'global_section_type_pagecover',
                    'type' => 'message',
                    'wrapper' => [
                        'class' => 'section-type-message',
                    ],
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'pagecover',
                            ],
                        ],
                    ],
                ],
                // Field Group for Headers
                [
                    'key' => 'field_gs_header_display_rules',
                    'label' => __('Header Display Rules', 'unistudio-core'),
                    'name' => 'gs_header_display_rules',
                    'type' => 'group',
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'header',
                            ],
                        ],
                    ],
                    'layout' => 'block',
                    'sub_fields' => [
                        [
                            'key' => 'field_header_display_conditions',
                            'label' => __('Display Conditions', 'unistudio-core'),
                            'name' => 'display_conditions',
                            'type' => 'repeater',
                            'layout' => 'row',
                            'button_label' => __('Add Condition', 'unistudio-core'),
                            'sub_fields' => [
                                [
                                    'key' => 'field_header_display_type',
                                    'label' => __('Display Type', 'unistudio-core'),
                                    'name' => 'display_type',
                                    'type' => 'radio',
                                    'choices' => [
                                        'include' => __('Include (show on)', 'unistudio-core'),
                                        'exclude' => __('Exclude (hide on)', 'unistudio-core'),
                                    ],
                                    'default_value' => 'include',
                                    'layout' => 'horizontal',
                                ],
                                [
                                    'key' => 'field_header_condition_type',
                                    'label' => __('Condition Type', 'unistudio-core'),
                                    'name' => 'condition_type',
                                    'type' => 'select',
                                    'choices' => $display_rules_choices,
                                    'default_value' => 'entire_site',
                                    'ui' => 1,
                                ],
                                [
                                    'key' => 'field_header_singular_options',
                                    'label' => __('Singular Options', 'unistudio-core'),
                                    'name' => 'singular_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'posts' => __('Posts', 'unistudio-core'),
                                        'pages' => __('Pages', 'unistudio-core'),
                                        'uc_portfolio' => __('Projects', 'unistudio-core'),
                                        // Add other custom post types as needed
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_header_condition_type',
                                                'operator' => '==',
                                                'value' => 'singular',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_header_archive_options',
                                    'label' => __('Archive Options', 'unistudio-core'),
                                    'name' => 'archive_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'post_archive' => __('Blog Pages', 'unistudio-core'),
                                        'author_archive' => __('Author Archive', 'unistudio-core'),
                                        'date_archive' => __('Date Archive', 'unistudio-core'),
                                        'search_results' => __('Search Results', 'unistudio-core'),
                                        'uc_portfolio_archive' => __('Portfolio', 'unistudio-core'),
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_header_condition_type',
                                                'operator' => '==',
                                                'value' => 'archive',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_header_taxonomy_options',
                                    'label' => __('Taxonomy Options', 'unistudio-core'),
                                    'name' => 'taxonomy_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'category' => __('Categories', 'unistudio-core'),
                                        'post_tag' => __('Tags', 'unistudio-core'),
                                        'uc_portfolio_category' => __('Project Categories', 'unistudio-core'),
                                        'uc_portfolio_tag' => __('Project Tags', 'unistudio-core'),
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_header_condition_type',
                                                'operator' => '==',
                                                'value' => 'taxonomies',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_header_specific_pages',
                                    'label' => __('Select Pages', 'unistudio-core'),
                                    'name' => 'specific_pages',
                                    'type' => 'post_object',
                                    'post_type' => ['page'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_header_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_pages',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_header_specific_posts',
                                    'label' => __('Select Posts', 'unistudio-core'),
                                    'name' => 'specific_posts',
                                    'type' => 'post_object',
                                    'post_type' => ['post'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_header_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_posts',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_header_specific_projects',
                                    'label' => __('Select Projects', 'unistudio-core'),
                                    'name' => 'specific_projects',
                                    'type' => 'post_object',
                                    'post_type' => ['uc_portfolio'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_header_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_projects',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_header_post_types',
                                    'label' => __('Select Post Types', 'unistudio-core'),
                                    'name' => 'post_types',
                                    'type' => 'select',
                                    'choices' => [
                                        'post' => __('Posts', 'unistudio-core'),
                                        'page' => __('Pages', 'unistudio-core'),
                                        'uc_portfolio' => __('Projects', 'unistudio-core'),
                                    ],
                                    'multiple' => 1,
                                    'ui' => 1,
                                    'ajax' => 0,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_header_condition_type',
                                                'operator' => '==',
                                                'value' => 'post_types',
                                            ],
                                        ],
                                    ],
                                ],
                            ],
                        ],
                    ],
                ],
                
                // Field Group for Footers
                [
                    'key' => 'field_gs_footer_display_rules',
                    'label' => __('Footer Display Rules', 'unistudio-core'),
                    'name' => 'gs_footer_display_rules',
                    'type' => 'group',
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'footer',
                            ],
                        ],
                    ],
                    'layout' => 'block',
                    'sub_fields' => [
                        [
                            'key' => 'field_footer_display_conditions',
                            'label' => __('Display Conditions', 'unistudio-core'),
                            'name' => 'display_conditions',
                            'type' => 'repeater',
                            'layout' => 'row',
                            'button_label' => __('Add Condition', 'unistudio-core'),
                            'sub_fields' => [
                                [
                                    'key' => 'field_footer_display_type',
                                    'label' => __('Display Type', 'unistudio-core'),
                                    'name' => 'display_type',
                                    'type' => 'radio',
                                    'choices' => [
                                        'include' => __('Include (show on)', 'unistudio-core'),
                                        'exclude' => __('Exclude (hide on)', 'unistudio-core'),
                                    ],
                                    'default_value' => 'include',
                                    'layout' => 'horizontal',
                                ],
                                [
                                    'key' => 'field_footer_condition_type',
                                    'label' => __('Condition Type', 'unistudio-core'),
                                    'name' => 'condition_type',
                                    'type' => 'select',
                                    'choices' => $display_rules_choices,
                                    'default_value' => 'entire_site',
                                    'ui' => 1,
                                ],
                                [
                                    'key' => 'field_footer_singular_options',
                                    'label' => __('Singular Options', 'unistudio-core'),
                                    'name' => 'singular_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'posts' => __('Posts', 'unistudio-core'),
                                        'pages' => __('Pages', 'unistudio-core'),
                                        'uc_portfolio' => __('Projects', 'unistudio-core'),
                                        // Add other custom post types as needed
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_footer_condition_type',
                                                'operator' => '==',
                                                'value' => 'singular',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_footer_archive_options',
                                    'label' => __('Archive Options', 'unistudio-core'),
                                    'name' => 'archive_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'post_archive' => __('Blog Pages', 'unistudio-core'),
                                        'author_archive' => __('Author Archive', 'unistudio-core'),
                                        'date_archive' => __('Date Archive', 'unistudio-core'),
                                        'search_results' => __('Search Results', 'unistudio-core'),
                                        'uc_portfolio_archive' => __('Portfolio', 'unistudio-core'),
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_footer_condition_type',
                                                'operator' => '==',
                                                'value' => 'archive',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_footer_taxonomy_options',
                                    'label' => __('Taxonomy Options', 'unistudio-core'),
                                    'name' => 'taxonomy_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'category' => __('Categories', 'unistudio-core'),
                                        'post_tag' => __('Tags', 'unistudio-core'),
                                        'uc_portfolio_category' => __('Project Categories', 'unistudio-core'),
                                        'uc_portfolio_tag' => __('Project Tags', 'unistudio-core'),
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_footer_condition_type',
                                                'operator' => '==',
                                                'value' => 'taxonomies',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_footer_specific_pages',
                                    'label' => __('Select Pages', 'unistudio-core'),
                                    'name' => 'specific_pages',
                                    'type' => 'post_object',
                                    'post_type' => ['page'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_footer_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_pages',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_footer_specific_posts',
                                    'label' => __('Select Posts', 'unistudio-core'),
                                    'name' => 'specific_posts',
                                    'type' => 'post_object',
                                    'post_type' => ['post'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_footer_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_posts',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_footer_specific_projects',
                                    'label' => __('Select Projects', 'unistudio-core'),
                                    'name' => 'specific_projects',
                                    'type' => 'post_object',
                                    'post_type' => ['uc_portfolio'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_footer_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_projects',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_footer_post_types',
                                    'label' => __('Select Post Types', 'unistudio-core'),
                                    'name' => 'post_types',
                                    'type' => 'select',
                                    'choices' => [
                                        'post' => __('Posts', 'unistudio-core'),
                                        'page' => __('Pages', 'unistudio-core'),
                                        'uc_portfolio' => __('Projects', 'unistudio-core'),
                                    ],
                                    'multiple' => 1,
                                    'ui' => 1,
                                    'ajax' => 0,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_footer_condition_type',
                                                'operator' => '==',
                                                'value' => 'post_types',
                                            ],
                                        ],
                                    ],
                                ],
                            ],
                        ],
                    ],
                ],
                
                // Field Group for Page Covers
                [
                    'key' => 'field_gs_pagecover_display_rules',
                    'label' => __('Page Cover Display Rules', 'unistudio-core'),
                    'name' => 'gs_pagecover_display_rules',
                    'type' => 'group',
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'pagecover',
                            ],
                        ],
                    ],
                    'layout' => 'block',
                    'sub_fields' => [
                        [
                            'key' => 'field_pagecover_display_conditions',
                            'label' => __('Display Conditions', 'unistudio-core'),
                            'name' => 'display_conditions',
                            'type' => 'repeater',
                            'layout' => 'row',
                            'button_label' => __('Add Condition', 'unistudio-core'),
                            'sub_fields' => [
                                [
                                    'key' => 'field_pagecover_display_type',
                                    'label' => __('Display Type', 'unistudio-core'),
                                    'name' => 'display_type',
                                    'type' => 'radio',
                                    'choices' => [
                                        'include' => __('Include (show on)', 'unistudio-core'),
                                        'exclude' => __('Exclude (hide on)', 'unistudio-core'),
                                    ],
                                    'default_value' => 'include',
                                    'layout' => 'horizontal',
                                ],
                                [
                                    'key' => 'field_pagecover_condition_type',
                                    'label' => __('Condition Type', 'unistudio-core'),
                                    'name' => 'condition_type',
                                    'type' => 'select',
                                    'choices' => $display_rules_choices,
                                    'default_value' => 'entire_site',
                                    'ui' => 1,
                                ],
                                [
                                    'key' => 'field_pagecover_singular_options',
                                    'label' => __('Singular Options', 'unistudio-core'),
                                    'name' => 'singular_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'posts' => __('Posts', 'unistudio-core'),
                                        'pages' => __('Pages', 'unistudio-core'),
                                        'uc_portfolio' => __('Projects', 'unistudio-core'),
                                        // Add other custom post types as needed
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_pagecover_condition_type',
                                                'operator' => '==',
                                                'value' => 'singular',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_pagecover_archive_options',
                                    'label' => __('Archive Options', 'unistudio-core'),
                                    'name' => 'archive_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'post_archive' => __('Blog Pages', 'unistudio-core'),
                                        'author_archive' => __('Author Archive', 'unistudio-core'),
                                        'date_archive' => __('Date Archive', 'unistudio-core'),
                                        'search_results' => __('Search Results', 'unistudio-core'),
                                        'uc_portfolio_archive' => __('Portfolio', 'unistudio-core'),
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_pagecover_condition_type',
                                                'operator' => '==',
                                                'value' => 'archive',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_pagecover_taxonomy_options',
                                    'label' => __('Taxonomy Options', 'unistudio-core'),
                                    'name' => 'taxonomy_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'category' => __('Categories', 'unistudio-core'),
                                        'post_tag' => __('Tags', 'unistudio-core'),
                                        'uc_portfolio_category' => __('Project Categories', 'unistudio-core'),
                                        'uc_portfolio_tag' => __('Project Tags', 'unistudio-core'),
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_pagecover_condition_type',
                                                'operator' => '==',
                                                'value' => 'taxonomies',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_pagecover_specific_pages',
                                    'label' => __('Select Pages', 'unistudio-core'),
                                    'name' => 'specific_pages',
                                    'type' => 'post_object',
                                    'post_type' => ['page'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_pagecover_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_pages',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_pagecover_specific_posts',
                                    'label' => __('Select Posts', 'unistudio-core'),
                                    'name' => 'specific_posts',
                                    'type' => 'post_object',
                                    'post_type' => ['post'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_pagecover_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_posts',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_pagecover_specific_projects',
                                    'label' => __('Select Projects', 'unistudio-core'),
                                    'name' => 'specific_projects',
                                    'type' => 'post_object',
                                    'post_type' => ['uc_portfolio'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_pagecover_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_projects',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_pagecover_post_types',
                                    'label' => __('Select Post Types', 'unistudio-core'),
                                    'name' => 'post_types',
                                    'type' => 'select',
                                    'choices' => [
                                        'post' => __('Posts', 'unistudio-core'),
                                        'page' => __('Pages', 'unistudio-core'),
                                        'uc_portfolio' => __('Projects', 'unistudio-core'),
                                    ],
                                    'multiple' => 1,
                                    'ui' => 1,
                                    'ajax' => 0,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_pagecover_condition_type',
                                                'operator' => '==',
                                                'value' => 'post_types',
                                            ],
                                        ],
                                    ],
                                ],
                            ],
                        ],
                    ],
                ],
                
                // Field Group for Off Canvas
                [
                    'key' => 'field_gs_offcanvas_settings',
                    'label' => __('Off-Canvas Settings', 'unistudio-core'),
                    'name' => 'gs_offcanvas_settings',
                    'type' => 'group',
                    'sub_fields' => [
                        [
                            'key' => 'field_offcanvas_panel_width',
                            'label' => __('Panel Width', 'unistudio-core'),
                            'name' => 'panel_width',
                            'type' => 'number',
                            'default_value' => 350,
                            'min' => 250,
                            'max' => 720,
                            'step' => 10,
                        ],
                        [
                            'key' => 'field_offcanvas_full_modifier',
                            'label' => __('Full Modifier', 'unistudio-core'),
                            'name' => 'full_modifier',
                            'type' => 'true_false',
                            'default_value' => false,
                            'ui' => 1,
                        ],
                        [
                            'key' => 'field_offcanvas_flip_position',
                            'label' => __('Flip Position', 'unistudio-core'),
                            'name' => 'flip_position',
                            'type' => 'true_false',
                            'default_value' => false,
                            'ui' => 1,
                        ],
                        [
                            'key' => 'field_offcanvas_animation_mode',
                            'label' => __('Animation Mode', 'unistudio-core'),
                            'name' => 'animation_mode',
                            'type' => 'select',
                            'choices' => [
                                'slide' => __('Slide', 'unistudio-core'),
                                'push' => __('Push', 'unistudio-core'),
                                'reveal' => __('Reveal', 'unistudio-core'),
                                'none' => __('None', 'unistudio-core'),
                            ],
                            'default_value' => 'slide',
                        ],
                        [
                            'key' => 'field_offcanvas_overlay',
                            'label' => __('Overlay?', 'unistudio-core'),
                            'name' => 'overlay',
                            'type' => 'true_false',
                            'default_value' => false,
                            'ui' => 1,
                        ],
                        [
                            'key' => 'field_offcanvas_close_btn',
                            'label' => __('Close Button', 'unistudio-core'),
                            'name' => 'close_btn',
                            'type' => 'true_false',
                            'default_value' => true,
                            'ui' => 1,
                        ],
                        [
                            'key' => 'field_offcanvas_panel_theme',
                            'label' => __('Panel Theme', 'unistudio-core'),
                            'name' => 'panel_theme',
                            'type' => 'true_false',
                            'default_value' => true,
                            'ui' => 1,
                            'ui_on_text' => 'Light',
                            'ui_off_text' => 'Dark',
                        ],
                    ],
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'offcanvas',
                            ],
                        ],
                    ],
                ],
                [
                    'key' => 'field_gs_offcanvas_display_rules',
                    'label' => __('Off Canvas Display Rules', 'unistudio-core'),
                    'name' => 'gs_offcanvas_display_rules',
                    'type' => 'group',
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'offcanvas',
                            ],
                        ],
                    ],
                    'layout' => 'block',
                    'sub_fields' => [
                        [
                            'key' => 'field_offcanvas_display_conditions',
                            'label' => __('Display Conditions', 'unistudio-core'),
                            'name' => 'display_conditions',
                            'type' => 'repeater',
                            'layout' => 'row',
                            'button_label' => __('Add Condition', 'unistudio-core'),
                            'sub_fields' => [
                                [
                                    'key' => 'field_offcanvas_display_type',
                                    'label' => __('Display Type', 'unistudio-core'),
                                    'name' => 'display_type',
                                    'type' => 'radio',
                                    'choices' => [
                                        'include' => __('Include (show on)', 'unistudio-core'),
                                        'exclude' => __('Exclude (hide on)', 'unistudio-core'),
                                    ],
                                    'default_value' => 'include',
                                    'layout' => 'horizontal',
                                ],
                                [
                                    'key' => 'field_offcanvas_condition_type',
                                    'label' => __('Condition Type', 'unistudio-core'),
                                    'name' => 'condition_type',
                                    'type' => 'select',
                                    'choices' => $display_rules_choices,
                                    'default_value' => '',
                                    'ui' => 1,
                                ],
                                [
                                    'key' => 'field_offcanvas_singular_options',
                                    'label' => __('Singular Options', 'unistudio-core'),
                                    'name' => 'singular_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'posts' => __('Posts', 'unistudio-core'),
                                        'pages' => __('Pages', 'unistudio-core'),
                                        'uc_portfolio' => __('Projects', 'unistudio-core'),
                                        // Add other custom post types as needed
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_offcanvas_condition_type',
                                                'operator' => '==',
                                                'value' => 'singular',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_offcanvas_archive_options',
                                    'label' => __('Archive Options', 'unistudio-core'),
                                    'name' => 'archive_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'post_archive' => __('Blog Pages', 'unistudio-core'),
                                        'author_archive' => __('Author Archive', 'unistudio-core'),
                                        'date_archive' => __('Date Archive', 'unistudio-core'),
                                        'search_results' => __('Search Results', 'unistudio-core'),
                                        'uc_portfolio_archive' => __('Portfolio', 'unistudio-core'),
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_offcanvas_condition_type',
                                                'operator' => '==',
                                                'value' => 'archive',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_offcanvas_taxonomy_options',
                                    'label' => __('Taxonomy Options', 'unistudio-core'),
                                    'name' => 'taxonomy_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'category' => __('Categories', 'unistudio-core'),
                                        'post_tag' => __('Tags', 'unistudio-core'),
                                        'uc_portfolio_category' => __('Project Categories', 'unistudio-core'),
                                        'uc_portfolio_tag' => __('Project Tags', 'unistudio-core'),
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_offcanvas_condition_type',
                                                'operator' => '==',
                                                'value' => 'taxonomies',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_offcanvas_specific_pages',
                                    'label' => __('Select Pages', 'unistudio-core'),
                                    'name' => 'specific_pages',
                                    'type' => 'post_object',
                                    'post_type' => ['page'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_offcanvas_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_pages',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_offcanvas_specific_posts',
                                    'label' => __('Select Posts', 'unistudio-core'),
                                    'name' => 'specific_posts',
                                    'type' => 'post_object',
                                    'post_type' => ['post'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_offcanvas_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_posts',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_offcanvas_specific_projects',
                                    'label' => __('Select Projects', 'unistudio-core'),
                                    'name' => 'specific_projects',
                                    'type' => 'post_object',
                                    'post_type' => ['uc_portfolio'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_offcanvas_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_projects',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_offcanvas_post_types',
                                    'label' => __('Select Post Types', 'unistudio-core'),
                                    'name' => 'post_types',
                                    'type' => 'select',
                                    'choices' => [
                                        'post' => __('Posts', 'unistudio-core'),
                                        'page' => __('Pages', 'unistudio-core'),
                                        'uc_portfolio' => __('Projects', 'unistudio-core'),
                                    ],
                                    'multiple' => 1,
                                    'ui' => 1,
                                    'ajax' => 0,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_offcanvas_condition_type',
                                                'operator' => '==',
                                                'value' => 'post_types',
                                            ],
                                        ],
                                    ],
                                ],
                            ],
                        ],
                    ],
                ],
                
                // Field Group for Popup
                [
                    'key' => 'field_gs_popup_settings',
                    'label' => __('Popup Settings', 'unistudio-core'),
                    'name' => 'gs_popup_settings',
                    'type' => 'group',
                    'sub_fields' => [
                        [
                            'key' => 'field_popup_container_width',
                            'label' => __('Container Width', 'unistudio-core'),
                            'name' => 'container_width',
                            'type' => 'number',
                            'default_value' => 600,
                            'min' => 350,
                            'max' => 1360,
                            'step' => 10,
                        ],
                        [
                            'key' => 'field_popup_vertically_center',
                            'label' => __('Vertically Center', 'unistudio-core'),
                            'name' => 'vertically_center',
                            'type' => 'true_false',
                            'default_value' => false,
                            'ui' => 1,
                        ],
                        [
                            'key' => 'field_popup_full_modifier',
                            'label' => __('Full Modifier', 'unistudio-core'),
                            'name' => 'full_modifier',
                            'type' => 'true_false',
                            'default_value' => false,
                            'ui' => 1,
                        ],
                        [
                            'key' => 'field_popup_theme',
                            'label' => __('Popup Theme', 'unistudio-core'),
                            'name' => 'popup_theme',
                            'type' => 'true_false',
                            'default_value' => true,
                            'ui' => 1,
                            'ui_on_text' => 'Light',
                            'ui_off_text' => 'Dark',
                        ],
                    ],
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'popup',
                            ],
                        ],
                    ],
                ],
                [
                    'key' => 'field_gs_popup_display_rules',
                    'label' => __('Popup Display Rules', 'unistudio-core'),
                    'name' => 'gs_popup_display_rules',
                    'type' => 'group',
                    'conditional_logic' => [
                        [
                            [
                                'field' => 'field_global_section_type',
                                'operator' => '==',
                                'value' => 'popup',
                            ],
                        ],
                    ],
                    'layout' => 'block',
                    'sub_fields' => [
                        [
                            'key' => 'field_popup_display_conditions',
                            'label' => __('Display Conditions', 'unistudio-core'),
                            'name' => 'display_conditions',
                            'type' => 'repeater',
                            'layout' => 'row',
                            'button_label' => __('Add Condition', 'unistudio-core'),
                            'sub_fields' => [
                                [
                                    'key' => 'field_popup_display_type',
                                    'label' => __('Display Type', 'unistudio-core'),
                                    'name' => 'display_type',
                                    'type' => 'radio',
                                    'choices' => [
                                        'include' => __('Include (show on)', 'unistudio-core'),
                                        'exclude' => __('Exclude (hide on)', 'unistudio-core'),
                                    ],
                                    'default_value' => 'include',
                                    'layout' => 'horizontal',
                                ],
                                [
                                    'key' => 'field_popup_condition_type',
                                    'label' => __('Condition Type', 'unistudio-core'),
                                    'name' => 'condition_type',
                                    'type' => 'select',
                                    'choices' => $display_rules_choices,
                                    'default_value' => '',
                                    'ui' => 1,
                                ],
                                [
                                    'key' => 'field_popup_singular_options',
                                    'label' => __('Singular Options', 'unistudio-core'),
                                    'name' => 'singular_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'posts' => __('Posts', 'unistudio-core'),
                                        'pages' => __('Pages', 'unistudio-core'),
                                        'uc_portfolio' => __('Projects', 'unistudio-core'),
                                        // Add other custom post types as needed
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_popup_condition_type',
                                                'operator' => '==',
                                                'value' => 'singular',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_popup_archive_options',
                                    'label' => __('Archive Options', 'unistudio-core'),
                                    'name' => 'archive_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'post_archive' => __('Blog Pages', 'unistudio-core'),
                                        'author_archive' => __('Author Archive', 'unistudio-core'),
                                        'date_archive' => __('Date Archive', 'unistudio-core'),
                                        'search_results' => __('Search Results', 'unistudio-core'),
                                        'uc_portfolio_archive' => __('Portfolio', 'unistudio-core'),
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_popup_condition_type',
                                                'operator' => '==',
                                                'value' => 'archive',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_popup_taxonomy_options',
                                    'label' => __('Taxonomy Options', 'unistudio-core'),
                                    'name' => 'taxonomy_options',
                                    'type' => 'checkbox',
                                    'choices' => [
                                        'category' => __('Categories', 'unistudio-core'),
                                        'post_tag' => __('Tags', 'unistudio-core'),
                                        'uc_portfolio_category' => __('Project Categories', 'unistudio-core'),
                                        'uc_portfolio_tag' => __('Project Tags', 'unistudio-core'),
                                    ],
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_popup_condition_type',
                                                'operator' => '==',
                                                'value' => 'taxonomies',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_popup_specific_pages',
                                    'label' => __('Select Pages', 'unistudio-core'),
                                    'name' => 'specific_pages',
                                    'type' => 'post_object',
                                    'post_type' => ['page'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_popup_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_pages',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_popup_specific_posts',
                                    'label' => __('Select Posts', 'unistudio-core'),
                                    'name' => 'specific_posts',
                                    'type' => 'post_object',
                                    'post_type' => ['post'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_popup_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_posts',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_popup_specific_projects',
                                    'label' => __('Select Projects', 'unistudio-core'),
                                    'name' => 'specific_projects',
                                    'type' => 'post_object',
                                    'post_type' => ['uc_portfolio'],
                                    'multiple' => 1,
                                    'return_format' => 'id',
                                    'ui' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_popup_condition_type',
                                                'operator' => '==',
                                                'value' => 'specific_projects',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_popup_post_types',
                                    'label' => __('Select Post Types', 'unistudio-core'),
                                    'name' => 'post_types',
                                    'type' => 'select',
                                    'choices' => [
                                        'post' => __('Posts', 'unistudio-core'),
                                        'page' => __('Pages', 'unistudio-core'),
                                        'uc_portfolio' => __('Projects', 'unistudio-core'),
                                    ],
                                    'multiple' => 1,
                                    'ui' => 1,
                                    'ajax' => 0,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_popup_condition_type',
                                                'operator' => '==',
                                                'value' => 'post_types',
                                            ],
                                        ],
                                    ],
                                ],
                            ],
                        ],
                        [
                            'key' => 'field_popup_trigger_settings',
                            'label' => __('Trigger Settings', 'unistudio-core'),
                            'name' => 'popup_trigger_settings',
                            'type' => 'group',
                            'layout' => 'block',
                            'sub_fields' => [
                                [
                                    'key' => 'field_popup_trigger_type',
                                    'label' => __('Trigger Type', 'unistudio-core'),
                                    'name' => 'trigger_type',
                                    'type' => 'select',
                                    'choices' => [
                                        'on_load' => __('On Page Load', 'unistudio-core'),
                                        'on_scroll' => __('On Scroll', 'unistudio-core'),
                                        'on_click' => __('On Click (Element)', 'unistudio-core'),
                                        'on_exit_intent' => __('On Exit Intent', 'unistudio-core'),
                                        'after_inactivity' => __('After Inactivity', 'unistudio-core'),
                                    ],
                                    'default_value' => 'on_load',
                                ],
                                [
                                    'key' => 'field_popup_load_delay',
                                    'label' => __('Load Delay (s)', 'unistudio-core'),
                                    'name' => 'load_delay',
                                    'type' => 'number',
                                    'default_value' => 0,
                                    'min' => 0,
                                    'max' => 300,
                                    'step' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_popup_trigger_type',
                                                'operator' => '==',
                                                'value' => 'on_load',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_popup_scroll_percentage',
                                    'label' => __('Scroll Percentage', 'unistudio-core'),
                                    'name' => 'scroll_percentage',
                                    'type' => 'range',
                                    'default_value' => 50,
                                    'min' => 1,
                                    'max' => 100,
                                    'step' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_popup_trigger_type',
                                                'operator' => '==',
                                                'value' => 'on_scroll',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_popup_click_selector',
                                    'label' => __('CSS Selector', 'unistudio-core'),
                                    'name' => 'click_selector',
                                    'type' => 'text',
                                    'placeholder' => '.button, #element-id',
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_popup_trigger_type',
                                                'operator' => '==',
                                                'value' => 'on_click',
                                            ],
                                        ],
                                    ],
                                ],
                                [
                                    'key' => 'field_popup_inactivity_time',
                                    'label' => __('Inactivity Time (seconds)', 'unistudio-core'),
                                    'name' => 'inactivity_time',
                                    'type' => 'number',
                                    'default_value' => 30,
                                    'min' => 5,
                                    'max' => 300,
                                    'step' => 1,
                                    'conditional_logic' => [
                                        [
                                            [
                                                'field' => 'field_popup_trigger_type',
                                                'operator' => '==',
                                                'value' => 'after_inactivity',
                                            ],
                                        ],
                                    ],
                                ],
                            ],
                        ],
                        [
                            'key' => 'field_popup_frequency',
                            'label' => __('Display Frequency', 'unistudio-core'),
                            'name' => 'popup_frequency',
                            'type' => 'select',
                            'choices' => [
                                'always' => __('Every Time', 'unistudio-core'),
                                'once_session' => __('Once Per Session', 'unistudio-core'),
                                'once_day' => __('Once Per Day', 'unistudio-core'),
                                'once_week' => __('Once Per Week', 'unistudio-core'),
                                'once_month' => __('Once Per Month', 'unistudio-core'),
                                'once_only' => __('Only Once (uses cookies)', 'unistudio-core'),
                            ],
                            'default_value' => 'always',
                        ],
                    ],
                ],
            ],
            'location' => [
                [
                    [
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'uc_global_sections',
                    ],
                ],
            ],
            'menu_order' => 0,
            'hide_on_screen' => array(
                0 => 'the_content',
                1 => 'excerpt',
                2 => 'discussion',
                3 => 'comments',
                4 => 'revisions',
                5 => 'slug',
                6 => 'author',
                7 => 'format',
                8 => 'page_attributes',
                9 => 'featured_image',
                10 => 'categories',
                11 => 'tags',
                12 => 'send-trackbacks',
            ),
            'position' => 'normal',
            'style' => 'normal',
            'label_placement' => 'none',
            'instruction_placement' => 'field',
            'hide_on_screen' => '',
            'active' => true,
            'description' => __('Configure global layout settings', 'unistudio-core'),
        ]);
    }

    /**
     * Sync the selected section type with the taxonomy
     */
    public function sync_section_type_taxonomy($post_id) {
        // Check if we're dealing with a global section
        if (get_post_type($post_id) !== 'uc_global_sections') {
            return;
        }
    
        // Get the selected section type from ACF
        $section_type = get_field('global_section_type', $post_id);
    
        // If no section type is selected, default to 'generic'
        if (!$section_type) {
            $section_type = 'generic';
        }
    
        // Remove all existing section type terms
        wp_delete_object_term_relationships($post_id, 'uc_section_type');
    
        // Add the new section type term
        wp_set_object_terms($post_id, $section_type, 'uc_section_type');
    
        // Clear the term cache
        clean_object_term_cache($post_id, 'uc_section_type');
    }
}