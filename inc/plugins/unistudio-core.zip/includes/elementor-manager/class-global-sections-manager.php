<?php
namespace UniStudioCore\ElementorManager;

use Elementor\Controls_Manager;
use Elementor\Plugin as ElementorPlugin;

class Global_Sections_Manager {
    private static $instance = null;
    
    public static function getInstance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Register Elementor location
        add_action('elementor/theme/register_locations', [$this, 'register_elementor_locations']);
        
        // Add section type controls
        add_action('elementor/element/after_section_end', [$this, 'add_section_type_controls'], 10, 2);
        
        // Register custom dynamic tags category
        add_action('elementor/dynamic_tags/register', [$this, 'register_dynamic_tags']);
        
        // Register widget category
        add_action('elementor/elements/categories_registered', [$this, 'register_widget_category']);
        
        // Add template library support
        add_action('elementor/init', [$this, 'register_template_source']);
    }

    public function register_elementor_locations($elementor_theme_manager) {
        $elementor_theme_manager->register_location('header');
        $elementor_theme_manager->register_location('footer');
        $elementor_theme_manager->register_location('mega_menu');
        $elementor_theme_manager->register_location('card');
    }

    public function add_section_type_controls($element, $section_id) {
        if ($section_id === 'section_custom_attributes' && get_post_type() === 'uc_global_section') {
            $element->start_controls_section(
                'section_global_settings',
                [
                    'label' => __('Global Section Settings', 'unistudio-core'),
                    'tab' => Controls_Manager::TAB_ADVANCED,
                ]
            );

            $element->add_control(
                'is_container',
                [
                    'label' => __('Enable Container', 'unistudio-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'default' => 'yes',
                    'description' => __('Enable/disable container wrapper for this section.', 'unistudio-core'),
                ]
            );

            $element->add_control(
                'container_width',
                [
                    'label' => __('Container Width', 'unistudio-core'),
                    'type' => Controls_Manager::SELECT,
                    'default' => 'default',
                    'options' => [
                        'default' => __('Default', 'unistudio-core'),
                        'full' => __('Full Width', 'unistudio-core'),
                        'boxed' => __('Boxed', 'unistudio-core'),
                    ],
                    'condition' => [
                        'is_container' => 'yes',
                    ],
                ]
            );

            $element->end_controls_section();
        }
    }

    public function register_dynamic_tags($dynamic_tags) {
        // Register Global Section Tags Category
        ElementorPlugin::$instance->dynamic_tags->register_group('uc-global-section', [
            'title' => __('Global Section', 'unistudio-core')
        ]);

        $tags = [
            'Section_Title' => 'UniStudioCore\ElementorManager\DynamicTags\Section_Title',
            'Section_Content' => 'UniStudioCore\ElementorManager\DynamicTags\Section_Content',
        ];

        foreach ($tags as $tag_class) {
            if (class_exists($tag_class)) {
                $dynamic_tags->register(new $tag_class());
            }
        }

        $dynamic_tags->register(new DynamicTags\Global_Section());
    }

    public function register_widget_category($elements_manager) {
        $elements_manager->add_category(
            'uc-global-sections',
            [
                'title' => __('Global Sections', 'unistudio-core'),
                'icon' => 'fa fa-plug',
            ]
        );
    }

    public function register_document_type($documents_manager) {
        require_once UC_PATH . 'includes/elementor-manager/documents/class-global-section.php';
        $documents_manager->register_document_type(
            'uc_global_section',
            \UniStudioCore\ElementorManager\Documents\Global_Section::class
        );
    }

    public function register_template_source() {
        if (!class_exists('UniStudioCore\ElementorManager\Template_Library\Source_Global_Sections')) {
            require_once UC_PATH . 'includes/elementor-manager/template-library/class-source-global-sections.php';
            \Elementor\Plugin::$instance->templates_manager->register_source(
                'UniStudioCore\ElementorManager\Template_Library\Source_Global_Sections'
            );
        }
    }

    public function get_global_section_content($section_id, $with_css = false) {
        if (!class_exists('\Elementor\Plugin')) {
            return '';
        }

        $elementor = ElementorPlugin::instance();
        
        if ($with_css) {
            $content = $elementor->frontend->get_builder_content_for_display($section_id);
        } else {
            $content = $elementor->frontend->get_builder_content($section_id, false);
        }

        return $content;
    }
}