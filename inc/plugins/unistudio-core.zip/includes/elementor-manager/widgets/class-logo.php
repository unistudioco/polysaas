<?php
namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Logo extends Widget_Base {
    public function get_name() {
        return 'uc_logo';
    }
    
    public function get_title() {
        return __('UC - Logo', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-logo';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    }
    
    public function get_style_depends() {
        return ['uc-logo'];
    }
    
    public function register_widget_styles() {
        Asset_Manager::getInstance()->register_widget_style(
            'uc-logo',
            'assets/css/widgets/logo.min.css',
            ['uc-core']
        );
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
    
        // Logo Image
        $this->add_control(
            'logo_image',
            [
                'label' => __('Choose Logo', 'unistudio-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );
    
        // Image Size
        $this->add_group_control(
            \Elementor\Group_Control_Image_Size::get_type(),
            [
                'name' => 'logo_image_size',
                'default' => 'full',
                'separator' => 'none',
            ]
        );
    
        // Link Type
        $this->add_control(
            'link_type',
            [
                'label' => __('Link Type', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'site_url',
                'options' => [
                    'none' => __('None', 'unistudio-core'),
                    'site_url' => __('Site URL', 'unistudio-core'),
                    'custom' => __('Custom URL', 'unistudio-core'),
                ],
            ]
        );

        // Custom URL
        $this->add_control(
            'custom_url',
            [
                'label' => __('Custom URL', 'unistudio-core'),
                'type' => Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'unistudio-core'),
                'default' => [
                    'url' => '',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'link_type' => 'custom',
                ],
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );
    
        $this->end_controls_section();
    
        // Style Sections
        $this->register_logo_styling_controls();
    }
    
    protected function register_logo_styling_controls() {
        $this->start_controls_section(
            'section_style_logo',
            [
                'label' => __('Logo', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // Logo Alignment
        $this->add_responsive_control(
            'logo_alignment',
            [
                'label' => __('Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Left', 'unistudio-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'unistudio-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => __('Right', 'unistudio-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} .uc-logo' => 'display: flex; justify-content: {{VALUE}};',
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
            ]
        );
    
        // Width
        $this->add_responsive_control(
            'width',
            [
                'label' => __('Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vw'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'vw' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-logo img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    
        // Height
        $this->add_responsive_control(
            'height',
            [
                'label' => __('Height', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                    'vh' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-logo img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
			'image_style_divider',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
    
        // Hover Effects Section
        $this->start_controls_tabs('image_effects');

        // Normal Tab
        $this->start_controls_tab(
            'normal',
            [
                'label' => __('Normal', 'unistudio-core'),
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Css_Filter::get_type(),
            [
                'name' => 'css_filters_normal',
                'selector' => '{{WRAPPER}} .uc-logo img',
            ]
        );

        $this->add_control(
            'normal_opacity',
            [
                'label' => __('Opacity', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 1,
                        'min' => 0.10,
                        'step' => 0.01,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-logo img' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        // Hover Tab
        $this->start_controls_tab(
            'hover',
            [
                'label' => __('Hover', 'unistudio-core'),
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Css_Filter::get_type(),
            [
                'name' => 'css_filters_hover',
                'selector' => '{{WRAPPER}} .uc-logo:hover img',
            ]
        );

        $this->add_control(
            'hover_opacity',
            [
                'label' => __('Opacity', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 1,
                        'min' => 0.10,
                        'step' => 0.01,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-logo:hover img' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'background_hover_transition',
            [
                'label' => __('Transition Duration (s)', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0.3,
                ],
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-logo img' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );
    
        // Hover Animation
        $this->add_control(
            'hover_animation',
            [
                'label' => __('Hover Animation', 'unistudio-core'),
                'type' => Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();
        
        // Border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'selector' => '{{WRAPPER}} .uc-logo img',
                'separator' => 'before',
            ]
        );

        // Border Radius
        $this->add_responsive_control(
            'image_border_radius',
            [
                'label' => __('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-logo img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Box Shadow
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image_box_shadow',
                'exclude' => [
                    'box_shadow_position',
                ],
                'selector' => '{{WRAPPER}} .uc-logo img',
            ]
        );
    
        $this->end_controls_section();
    }
    
    protected function render() {
        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_logo')) {
            return;
        }
    
        $settings = $this->get_settings_for_display();
    
        if (empty($settings['logo_image']['url'])) {
            return;
        }
    
        $this->add_render_attribute('wrapper', 'class', 'uc-logo');
        
        if (!empty($settings['hover_animation'])) {
            $this->add_render_attribute('wrapper', 'class', 'elementor-animation-' . $settings['hover_animation']);
        }
    
        $url = '';
        switch ($settings['link_type']) {
            case 'site_url':
                $url = get_home_url();
                break;
            case 'custom':
                $url = !empty($settings['custom_url']['url']) ? $settings['custom_url']['url'] : '';
                if (!empty($settings['custom_url']['is_external'])) {
                    $this->add_render_attribute('link', 'target', '_blank');
                }
                if (!empty($settings['custom_url']['nofollow'])) {
                    $this->add_render_attribute('link', 'rel', 'nofollow');
                }
                break;
            default:
                $url = '';
        }
    
        if (!empty($url)) {
            $this->add_render_attribute('link', 'href', $url);
        }
        ?>
        
        <div <?php $this->print_render_attribute_string('wrapper'); ?>>
            <?php if (!empty($url)) : ?>
            <a <?php $this->print_render_attribute_string('link'); ?>>
            <?php endif; ?>
            
            <?php echo \Elementor\Group_Control_Image_Size::get_attachment_image_html($settings, 'logo_image_size', 'logo_image'); ?>
            
            <?php if (!empty($url)) : ?>
            </a>
            <?php endif; ?>
        </div>
        <?php
    }
}