<?php
namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;
use UniStudioCore\ElementorManager\Helpers\NavbarWalker;

class Menu extends Widget_Base {
    public function get_name() {
        return 'uc_menu';
    }
    
    public function get_title() {
        return __('UC - Menu', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-nav-menu';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    }
    
    public function get_script_depends() {
        return ['uc-menu'];
    }

    public function get_style_depends() {
        return ['uc-menu'];
    }

    public function register_widget_scripts() {
        Asset_Manager::getInstance()->register_widget_script(
            'uc-menu',
            'assets/js/widgets/menu.min.js',
            ['uc-core']
        );
    }

    public function register_widget_styles() {
        Asset_Manager::getInstance()->register_widget_style(
            'uc-menu',
            'assets/css/widgets/menu.min.css',
            ['uc-core']
        );
    }
    
    
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        // Get all menus
        $menus = wp_get_nav_menus();
        $menu_options = [];
        
        foreach ($menus as $menu) {
            $menu_options[$menu->term_id] = $menu->name;
        }

        $this->add_control(
            'menu_location',
            [
                'label' => esc_html__('Select a menu', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'primary-menu',
                'options' => $menu_options,
            ]
        );

        // Animation
        $this->add_control(
            'navbar_animation',
            [
                'label' => esc_html__('Animation', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'uc-animation-slide-top-small',
                'options' => [
                    'uc-animation-fade' => esc_html__('Fade', 'unistudio-core'),
                    'uc-animation-slide-top-small' => esc_html__('Slide Top Small', 'unistudio-core'),
                    'uc-animation-slide-bottom-small' => esc_html__('Slide Bottom Small', 'unistudio-core'),
                    'uc-animation-slide-left-small' => esc_html__('Slide Left Small', 'unistudio-core'),
                    'uc-animation-slide-right-small' => esc_html__('Slide Right Small', 'unistudio-core'),
                    'uc-animation-scale-up' => esc_html__('Scale Up', 'unistudio-core'),
                    'uc-animation-scale-down' => esc_html__('Scale Down', 'unistudio-core'),
                ],
            ]
        );

        $this->add_control(
            'navbar_duration',
            [
                'label' => esc_html__('Animation Duration (ms)', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 250,
                'min' => 0,
                'max' => 1000,
                'step' => 50,
            ]
        );

        $this->add_control(
            'navbar_delay_hide',
            [
                'label' => esc_html__('Delay Hide (ms)', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 250,
                'min' => 0,
                'max' => 1000,
                'step' => 50,
            ]
        );

        $this->add_control(
            'dropdown_heading',
            [
                'label' => esc_html__('Dropdown', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        // Trigger Mode
        $this->add_control(
            'drop_mode',
            [
                'label' => esc_html__('Trigger Mode', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'hover',
                'options' => [
                    'click' => esc_html__('Click', 'unistudio-core'),
                    'hover' => esc_html__('Hover', 'unistudio-core'),
                ],
            ]
        );

        // Offset
        $this->add_control(
            'drop_offset',
            [
                'label' => esc_html__('Offset', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 0,
                'min' => 0,
                'max' => 48,
                'step' => 1,
            ]
        );

        // Boundary
        $this->add_control(
            'drop_boundary',
            [
                'label' => esc_html__('Boundary Class', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '!.uc-header .e-con-inner',
                'label_block' => true,
                'description' => esc_html__('CSS selector for boundary element. Use "!" prefix to search through parents.', 'unistudio-core'),
            ]
        );

        // Stretch
        $this->add_control(
            'drop_stretch',
            [
                'label' => esc_html__('Stretch', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'x',
                'options' => [
                    '' => esc_html__('None', 'unistudio-core'),
                    'x' => esc_html__('Horizontal', 'unistudio-core'),
                ],
            ]
        );

        // Animation
        $this->add_control(
            'drop_animation',
            [
                'label' => esc_html__('Animation', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'uc-animation-slide-top-small',
                'options' => [
                    'uc-animation-fade' => esc_html__('Fade', 'unistudio-core'),
                    'uc-animation-slide-top-small' => esc_html__('Slide Top Small', 'unistudio-core'),
                    'uc-animation-slide-bottom-small' => esc_html__('Slide Bottom Small', 'unistudio-core'),
                    'uc-animation-slide-left-small' => esc_html__('Slide Left Small', 'unistudio-core'),
                    'uc-animation-slide-right-small' => esc_html__('Slide Right Small', 'unistudio-core'),
                    'uc-animation-scale-up' => esc_html__('Scale Up', 'unistudio-core'),
                    'uc-animation-scale-down' => esc_html__('Scale Down', 'unistudio-core'),
                ],
            ]
        );

        // Animation Out
        $this->add_control(
            'drop_animation_out',
            [
                'label' => esc_html__('Animation Out', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'uc-animation-slide-top-small',
                'options' => [
                    'uc-animation-fade' => esc_html__('Fade', 'unistudio-core'),
                    'uc-animation-slide-top-small' => esc_html__('Slide Top Small', 'unistudio-core'),
                    'uc-animation-slide-bottom-small' => esc_html__('Slide Bottom Small', 'unistudio-core'),
                    'uc-animation-slide-left-small' => esc_html__('Slide Left Small', 'unistudio-core'),
                    'uc-animation-slide-right-small' => esc_html__('Slide Right Small', 'unistudio-core'),
                    'uc-animation-scale-up' => esc_html__('Scale Up', 'unistudio-core'),
                    'uc-animation-scale-down' => esc_html__('Scale Down', 'unistudio-core'),
                ],
            ]
        );

        // Duration
        $this->add_control(
            'drop_duration',
            [
                'label' => esc_html__('Animation Duration (ms)', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 250,
                'min' => 0,
                'max' => 1000,
                'step' => 50,
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->uc_register_main_menu_controls();
        $this->uc_register_drop_controls();
    }

    protected function uc_register_main_menu_controls() {
        // Main Menu Style
        $this->start_controls_section(
            'section_main_menu_style',
            [
                'label' => esc_html__('Main Menu', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
    
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'menu_typography',
                'selector' => '{{WRAPPER}} .uc-navbar-nav > li > a',
            ]
        );
    
        $this->add_responsive_control(
            'menu_item_spacing',
            [
                'label' => esc_html__('Items Spacing', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
				'default' => [
					'unit' => 'px',
					'size' => 32,
				],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-nav' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    
        $this->start_controls_tabs('menu_item_colors');
    
        // Normal State
        $this->start_controls_tab(
            'menu_colors_normal',
            [
                'label' => esc_html__('Normal', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'menu_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-nav > li > a' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_control(
            'menu_bg_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-nav > li > a' => 'background-color: {{VALUE}}',
                ],
            ]
        );
    
        $this->end_controls_tab();
    
        // Hover State
        $this->start_controls_tab(
            'menu_colors_hover',
            [
                'label' => esc_html__('Hover', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'menu_hover_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-nav > li > a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_control(
            'menu_bg_hover_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-nav > li > a:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->end_controls_tab();
    
        // Active State
        $this->start_controls_tab(
            'menu_colors_active',
            [
                'label' => esc_html__('Active', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'menu_active_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-nav > li > a:active' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_control(
            'menu_bg_active_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-nav > li > a:active' => 'background-color: {{VALUE}}',
                ],
            ]
        );
    
        $this->end_controls_tab();
    
        $this->end_controls_tabs();
    
        // Border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'menu_border',
                'selector' => '{{WRAPPER}} .uc-navbar-nav > li > a',
                'separator' => 'before',
            ]
        );
    
        $this->add_responsive_control(
            'menu_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-nav > li > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'menu_padding',
            [
                'label' => esc_html__('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-nav > li > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->end_controls_section();
    }

    // Dropdown Style
    protected function uc_register_drop_controls() {
        
        $this->start_controls_section(
            'drop_settings_section',
            [
                'label' => esc_html__('Dropdown', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        ); 
    
        $this->add_control(
            'dropdown_container_bg',
            [
                'label' => esc_html__('Container Background', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown' => 'background-color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'dropdown_border',
                'selector' => '{{WRAPPER}} .uc-navbar-dropdown',
            ]
        );
    
        $this->add_responsive_control(
            'dropdown_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'dropdown_box_shadow',
                'selector' => '{{WRAPPER}} .uc-navbar-dropdown',
            ]
        );
    
        $this->add_responsive_control(
            'dropdown_padding',
            [
                'label' => esc_html__('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'dropdown_distance',
            [
                'label' => esc_html__('Distance', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'dropdown_typography',
                'selector' => '{{WRAPPER}} .uc-navbar-dropdown-nav > li > a',
                'separator' => 'before',
            ]
        );

        $this->start_controls_tabs('dropdown_items_style');
    
        // Normal State
        $this->start_controls_tab(
            'dropdown_colors_normal',
            [
                'label' => esc_html__('Normal', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'dropdown_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown-nav > li > a' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_control(
            'dropdown_bg_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown-nav > li > a' => 'background-color: {{VALUE}}',
                ],
            ]
        );
    
        $this->end_controls_tab();
    
        // Hover State
        $this->start_controls_tab(
            'dropdown_colors_hover',
            [
                'label' => esc_html__('Hover', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'dropdown_hover_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown-nav > li > a:hover' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_control(
            'dropdown_bg_hover_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown-nav > li > a:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_control(
            'dropdown_hover_border_color',
            [
                'label' => esc_html__('Border Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown-nav > li > a:hover' => 'border-color: {{VALUE}}',
                ],
            ]
        );
    
        $this->end_controls_tab();
    
        // Active State
        $this->start_controls_tab(
            'dropdown_colors_active',
            [
                'label' => esc_html__('Active', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'dropdown_active_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown-nav > li.current-menu-item > a' => 'color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_control(
            'dropdown_bg_active_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown-nav > li.current-menu-item > a' => 'background-color: {{VALUE}}',
                ],
            ]
        );
    
        $this->add_control(
            'dropdown_active_border_color',
            [
                'label' => esc_html__('Border Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown-nav > li.current-menu-item > a' => 'border-color: {{VALUE}}',
                ],
            ]
        );
    
        $this->end_controls_tab();
    
        $this->end_controls_tabs();
    
        $this->add_responsive_control(
            'dropdown_item_padding',
            [
                'label' => esc_html__('Item Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown-nav > li > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );
    
        $this->add_control(
            'dropdown_divider',
            [
                'label' => esc_html__('Divider', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
    
        $this->add_control(
            'dropdown_divider_color',
            [
                'label' => esc_html__('Divider Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-navbar-dropdown-nav > li:not(:last-child)' => 'border-bottom: 1px solid {{VALUE}}',
                ],
                'condition' => [
                    'dropdown_divider' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {

        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_menu')) {
            return;
        }

        $settings = $this->get_settings_for_display();
        $menu_id = $settings['menu_location'];

        if (!$menu_id) {
            return;
        }

        // Add Mega Menu support filters
        add_filter('nav_menu_link_attributes', [$this, 'add_mega_menu_attributes'], 10, 3);
        add_filter('nav_menu_css_class', [$this, 'add_mega_menu_classes'], 10, 3);

        // Get navbar options
        $navbar_options = $this->get_navbar_options();

        // Get drop options
        $drop_options = $this->get_drop_options();

        // Pass drop options to walker
        $walker = new NavbarWalker();
        $walker->set_drop_options($drop_options);

        ?>
        <div class="uc-navbar" data-uc-navbar="<?php echo esc_attr($navbar_options); ?>">
            <?php
            wp_nav_menu(array(
                'menu' => $menu_id,
                'container' => false,
                'menu_class' => 'uc-navbar-nav',
                'fallback_cb' => '__return_false',
                'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
                'depth' => 4,
                'walker' => $walker
            ));
            ?>
        </div>
        <?php

        // Remove filters after rendering
        remove_filter('nav_menu_link_attributes', [$this, 'add_mega_menu_attributes']);
        remove_filter('nav_menu_css_class', [$this, 'add_mega_menu_classes']);
    }

    public function add_mega_menu_attributes($atts, $item, $args) {
        $is_mega_menu = get_post_meta($item->ID, '_uc_mega_menu_enabled', true);
        $mega_menu_id = get_post_meta($item->ID, '_uc_mega_menu_id', true);

        if ($is_mega_menu && $mega_menu_id) {
            $atts['class'] = isset($atts['class']) ? $atts['class'] . ' uc-has-mega-menu' : 'uc-has-mega-menu';
            $atts['data-mega-menu-id'] = $mega_menu_id;
            $atts['role'] = 'button';
            $atts['aria-haspopup'] = 'true';
            $atts['href'] = '#';
        }

        return $atts;
    }

    public function add_mega_menu_classes($classes, $item, $args) {
        if (get_post_meta($item->ID, '_uc_mega_menu_enabled', true)) {
            $classes[] = 'uc-mega-menu-item';
        }
        return $classes;
    }

    private function get_navbar_options() {
        $settings = $this->get_settings_for_display();
        
        $options = [
            'animation' => $settings['navbar_animation'],
            'duration' => $settings['navbar_duration'],
            'delay-hide' => $settings['navbar_delay_hide']
        ];

        // Build the data-uc-navbar attribute string
        $navbar_options = [];
        foreach ($options as $key => $value) {
            $navbar_options[] = "{$key}: {$value}";
        }

        return implode('; ', $navbar_options);
    }

    private function get_drop_options() {
        $settings = $this->get_settings_for_display();
        
        $options = [
            'mode' => $settings['drop_mode'],
            'offset' => $settings['drop_offset'],
            'boundary' => $settings['drop_boundary'],
            'animation' => $settings['drop_animation'],
            'animate-out' => $settings['drop_animation_out'],
            'duration' => $settings['drop_duration']
        ];

        // Add stretch only if it's not empty
        if (!empty($settings['drop_stretch'])) {
            $options['stretch'] = $settings['drop_stretch'];
        }

        // Build the data-uc-drop attribute string
        $drop_options = [];
        foreach ($options as $key => $value) {
            $drop_options[] = "{$key}: {$value}";
        }

        return implode('; ', $drop_options);
    }

    public function start_el_mega_menu($element_id, $drop_options) {
        return sprintf(
            '<div class="uc-dropbar uc-dropbar-top hide-scrollbar uc-drop" data-uc-drop="%s">',
            esc_attr($drop_options)
        );
    }
}