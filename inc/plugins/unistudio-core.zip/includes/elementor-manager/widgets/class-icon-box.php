<?php

namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Icon_Box extends Widget_Base {
    public function get_name() {
        return 'uc_icon_box';
    }
    
    public function get_title() {
        return __('UC - Icon Box', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-icon-box';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    }
    
    public function get_style_depends() {
        return ['uc-icon-box'];
    }

    public function get_script_depends() {
        return ['elementor-icons-manager'];
    }
    
    public function register_widget_styles() {
        Asset_Manager::getInstance()->register_widget_style(
            'uc-icon-box',
            'assets/css/widgets/icon-box.min.css',
            ['uc-core']
        );
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        // Icon
        $this->add_control(
            'selected_icon',
            [
                'label' => __('Icon', 'unistudio-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'unicon-star-filled',
                    'library' => 'unicons',
                ],
                'recommended' => [
                    'unicons' => [
                        'star-filled',
                        'star',
                        'arrow-down',
                        'arrow-up',
                        'arrow-left',
                        'arrow-right',
                        'arrow-up-right',
                        'add',
                        'add-alt',
                        'add-alt-filled',
                        'download-cloud',
                        'upload-cloud',
                        'cart',
                        'bookmark-filled',
                        'view-alt-filled',
                        'location-filled',
                    ],
                ],
                'fa4compatibility' => 'icon',
                'skin' => 'inline',
                'upload' => true,
            ]
        );

        $this->add_control(
            'icon_svg_inherit',
            [
                'label' => esc_html__('SVG Inherit Color?', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('If you upload a custom SVG image you can enable this to enable inherit coloring.', 'unistudio-core'),
                'default' => '',
                'condition' => [
                    'selected_icon!' => '',
                ],
            ]
        );

        // Title
        $this->add_control(
            'title',
            [
                'label' => __('Title', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Fast and Reliable', 'unistudio-core'),
            ]
        );

        // Label
        $this->add_control(
            'label_text',
            [
                'label' => __('Label', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
            ]
        );

        $this->add_responsive_control(
            'label_position',
            [
                'label' => __('Label Position', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'before' => [
                        'title' => __('Before Title', 'unistudio-core'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'after' => [
                        'title' => __('After Title', 'unistudio-core'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'default' => 'after',
                'condition' => [
                    'label_text!' => '',
                ],
            ]
        );

        // Description
        $this->add_control(
            'description',
            [
                'label' => __('Description', 'unistudio-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Whether you have a team of 2 or 200, our shared team inboxes keep everyone on the same page and in the loop.', 'unistudio-core'),
            ]
        );
        
        // Link Cover
        $this->add_control(
            'show_cover_link',
            [
                'label' => __('Cover Link', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'unistudio-core'),
                'label_off' => __('Hide', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'cover_link_url',
            [
                'label' => __('URL', 'unistudio-core'),
                'type' => Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'unistudio-core'),
                'default' => [
                    'url' => '',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'show_cover_link' => 'yes',
                ],
            ]
        );
        
        // CTA
        $this->add_control(
            'show_cta',
            [
                'label' => __('Show CTA?', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'unistudio-core'),
                'label_off' => __('Hide', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'link_text',
            [
                'label' => __('Text', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Learn more', 'unistudio-core'),
                'condition' => [
                    'show_cta' => 'yes',
                ],
            ]
        );
        
        $this->add_control(
            'link_url',
            [
                'label' => __('URL', 'unistudio-core'),
                'type' => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'show_cta' => 'yes',
                ],
            ]
        );

        // Icon Options
        $this->add_control(
            'show_cta_icon',
            [
                'label' => __('Show CTA Icon', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'show_cta' => 'yes',
                ],
            ]
        );
        
        $this->end_controls_section();
        
        // Style Sections...
        $this->register_layout_styling_controls();
        $this->register_container_styling_controls();
        $this->register_icon_styling_controls();
        $this->register_text_styling_controls();
        $this->register_cta_link_styling_controls();
        $this->register_hover_effects_controls();
    }

    protected function register_layout_styling_controls() {
        // Layout Options Section
        $this->start_controls_section(
            'section_layout_options',
            [
                'label' => __('Layout', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'content_wrapper_layout',
            [
                'label' => __('Card Layout', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'wrap-content-cta',
                'options' => [
                    'wrap-content-cta' => __('Wrap Content + CTA', 'unistudio-core'),
                    'wrap-content-icon' => __('Wrap Content + Icon', 'unistudio-core'),
                    'no-wrap' => __('No Wrap', 'unistudio-core'),
                ],
                'prefix_class' => 'uc-layout-',
                'frontend_available' => true,
                'render_type' => 'template',
            ]
        );
        
        $this->add_responsive_control(
            'contnet_wrapper_min_height',
            [
                'label' => esc_html__('Min Height', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vh'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 1000],
                    '%' => ['min' => 0, 'max' => 100],
                    'vh' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'content_match_height',
            [
                'label' => __('Match Height', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'default' => 'no',
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box' => 'height: 100%',
                ],
            ]
        );

        $this->add_control(
            'container_style_heading',
            [
                'label' => __('Container', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'container_direction',
            [
                'label' => __('Direction', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'column' => [
                        'title' => __('Vertical', 'unistudio-core'),
                        'icon' => 'eicon-arrow-down',
                    ],
                    'row' => [
                        'title' => __('Horizontal', 'unistudio-core'),
                        'icon' => 'eicon-arrow-right',
                    ],
                    'column-reverse' => [
                        'title' => __('Vertical Reverse', 'unistudio-core'),
                        'icon' => 'eicon-arrow-up',
                    ],
                    'row-reverse' => [
                        'title' => __('Horizontal Reverse', 'unistudio-core'),
                        'icon' => 'eicon-arrow-left',
                    ],
                ],
                'default' => 'column',
                'toggle' => false,
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box' => 'flex-direction: {{VALUE}};',
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
            ]
        );

        $this->add_responsive_control(
            'container_alignment',
            [
                'label' => __('Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Start', 'unistudio-core'),
                        'icon' => 'eicon-align-start-h',
                    ],
                    'center' => [
                        'title' => __('Center', 'unistudio-core'),
                        'icon' => 'eicon-align-center-h',
                    ],
                    'flex-end' => [
                        'title' => __('End', 'unistudio-core'),
                        'icon' => 'eicon-align-end-h',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box' => 'align-items: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'container_text_alignment',
            [
                'label' => __('Text Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'unistudio-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'unistudio-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'unistudio-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        // Gap
        $this->add_responsive_control(
            'container_gap',
            [
                'label' => __('Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'container_justify',
            [
                'label' => __('Justify', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Start', 'unistudio-core'), 
                        'icon' => 'eicon-flex eicon-justify-start-h',
                    ],
                    'center' => [
                        'title' => __('Center', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-center-h',
                    ],
                    'flex-end' => [
                        'title' => __('End', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-end-h', 
                    ],
                    'space-between' => [
                        'title' => __('Space Between', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-space-between-h',
                    ],
                    'space-around' => [
                        'title' => __('Space Around', 'unistudio-core'), 
                        'icon' => 'eicon-flex eicon-justify-space-around-h',
                    ],
                    'space-evenly' => [
                        'title' => __('Space Evenly', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-space-evenly-h',
                    ],
                ],
                'default' => 'space-between',
                'toggle' => false,
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box' => 'justify-content: {{VALUE}};',
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
            ]
         );

        // Heading
        $this->add_control(
            'content_style_heading',
            [
                'label' => __('Content Wrap', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'content_wrapper_layout!' => 'no-wrap',
                ],
            ]
        );

        // Direction
        $this->add_responsive_control(
            'content_direction',
            [
                'label' => __('Direction', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'column' => [
                        'title' => __('Vertical', 'unistudio-core'),
                        'icon' => 'eicon-arrow-down',
                    ],
                    'row' => [
                        'title' => __('Horizontal', 'unistudio-core'),
                        'icon' => 'eicon-arrow-right',
                    ],
                    'column-reverse' => [
                        'title' => __('Vertical Reverse', 'unistudio-core'),
                        'icon' => 'eicon-arrow-up',
                    ],
                    'row-reverse' => [
                        'title' => __('Horizontal Reverse', 'unistudio-core'),
                        'icon' => 'eicon-arrow-left',
                    ],
                ],
                'default' => 'column',
                'toggle' => false,
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .content-wrap' => 'flex-direction: {{VALUE}};',
                ],
                'condition' => [
                    'content_wrapper_layout!' => 'no-wrap',
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
            ]
        );

        // Alignment
        $this->add_responsive_control(
            'content_alignment',
            [
                'label' => __('Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Start', 'unistudio-core'),
                        'icon' => 'eicon-align-start-h',
                    ],
                    'center' => [
                        'title' => __('Center', 'unistudio-core'),
                        'icon' => 'eicon-align-center-h',
                    ],
                    'flex-end' => [
                        'title' => __('End', 'unistudio-core'),
                        'icon' => 'eicon-align-end-h',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .content-wrap' => 'align-items: {{VALUE}};',
                ],
                'condition' => [
                    'content_wrapper_layout!' => 'no-wrap',
                ],
            ]
        );

        // Gap
        $this->add_responsive_control(
            'content_gap',
            [
                'label' => __('Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 20,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .content-wrap' => 'gap: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'content_wrapper_layout!' => 'no-wrap',
                ],
            ]
        );

        // Justify
        $this->add_responsive_control(
            'content_justify',
            [
                'label' => __('Justify', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Start', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-start-h',
                    ],
                    'center' => [
                        'title' => __('Center', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-center-h',
                    ],
                    'flex-end' => [
                        'title' => __('End', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-end-h',
                    ],
                    'space-between' => [
                        'title' => __('Space Between', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-space-between-h',
                    ],
                    'space-around' => [
                        'title' => __('Space Around', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-space-around-h',
                    ],
                    'space-evenly' => [
                        'title' => __('Space Evenly', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-space-evenly-h',
                    ],
                ],
                'default' => 'space-between',
                'toggle' => false,
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .content-wrap' => 'justify-content: {{VALUE}};',
                ],
                'condition' => [
                    'content_wrapper_layout!' => 'no-wrap',
                ],
                'devices' => ['desktop', 'tablet', 'mobile'],
            ]
        );

        $this->end_controls_section();
    }

    protected function register_container_styling_controls() {
        // Container Style Section
        $this->start_controls_section(
            'section_container_style',
            [
                'label' => __('Container', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // Background
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'container_background',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .uc-icon-box',
                'fields_options' => [
                    'background' => [
                        'default' => 'classic',
                    ],
                    'color' => [
                        'default' => '#f5f5f5',
                    ]
                ],
            ]
        );

        // Padding
        $this->add_responsive_control(
            'container_padding',
            [
                'label' => __('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '48',
                    'right' => '40',
                    'bottom' => '48',
                    'left' => '40',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Margin
        $this->add_responsive_control(
            'container_margin',
            [
                'label' => __('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'container_border',
                'selector' => '{{WRAPPER}} .uc-icon-box',
                'separator' => 'before',
            ]
        );

        // Border Radius
        $this->add_responsive_control(
            'container_border_radius',
            [
                'label' => __('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Box Shadow
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'container_box_shadow',
                'selector' => '{{WRAPPER}} .uc-icon-box',
            ]
        );

        $this->end_controls_section();
    }

    protected function register_icon_styling_controls() {

        // Icon Style Section
        $this->start_controls_section(
            'section_icon_style',
            [
                'label' => __('Icon', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'selected_icon[value]!' => '',
                ]
            ]
        );

        // Position Type
        $this->add_control(
            'icon_position_type',
            [
                'label' => __('Position', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'relative',
                'options' => [
                    'relative' => __('Relative', 'unistudio-core'),
                    'absolute' => __('Absolute', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .icon-wrap' => 'position: {{VALUE}};',
                ],
                'frontend_available' => true,
                'render_type' => 'template',
            ]
        );

        

        // Horizontal Orientation
		$left = esc_html__( 'Left', 'elementor' );
		$right = esc_html__( 'Right', 'elementor' );

		$start = is_rtl() ? $right : $left;
		$end = ! is_rtl() ? $right : $left;

		$this->add_control(
			'icon_offset_orientation_h',
			[
				'label' => esc_html__( 'Horizontal Orientation', 'elementor' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'default' => 'start',
				'options' => [
					'start' => [
						'title' => $start,
						'icon' => 'eicon-h-align-left',
					],
					'end' => [
						'title' => $end,
						'icon' => 'eicon-h-align-right',
					],
				],
				'classes' => 'elementor-control-start-end',
				'render_type' => 'ui',
				'condition' => [
					'icon_position_type' => 'absolute',
				],
			]
		);

		$this->add_responsive_control(
			'icon_offset_x',
			[
				'label' => esc_html__( 'Offset X', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => 0,
				],
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'vh', 'custom' ],
				'selectors' => [
					'body:not(.rtl) {{WRAPPER}} .uc-icon-box .icon-wrap' => 'left: {{SIZE}}{{UNIT}}',
					'body.rtl {{WRAPPER}} .uc-icon-box .icon-wrap' => 'right: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'icon_offset_orientation_h!' => 'end',
					'icon_position_type' => 'absolute',
				],
			]
		);

		$this->add_responsive_control(
			'icon_offset_x_end',
			[
				'label' => esc_html__( 'Offset X', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'default' => [
					'size' => 0,
				],
				'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'vh', 'custom' ],
				'selectors' => [
					'body:not(.rtl) {{WRAPPER}} .uc-icon-box .icon-wrap' => 'right: {{SIZE}}{{UNIT}}',
					'body.rtl {{WRAPPER}} .uc-icon-box .icon-wrap' => 'left: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'icon_offset_orientation_h' => 'end',
					'icon_position_type' => 'absolute',
				],
			]
		);

		$this->add_control(
			'icon_offset_orientation_v',
			[
				'label' => esc_html__( 'Vertical Orientation', 'elementor' ),
				'type' => Controls_Manager::CHOOSE,
				'toggle' => false,
				'default' => 'start',
				'options' => [
					'start' => [
						'title' => esc_html__( 'Top', 'elementor' ),
						'icon' => 'eicon-v-align-top',
					],
					'end' => [
						'title' => esc_html__( 'Bottom', 'elementor' ),
						'icon' => 'eicon-v-align-bottom',
					],
				],
				'render_type' => 'ui',
				'condition' => [
					'icon_position_type' => 'absolute',
				],
			]
		);

		$this->add_responsive_control(
			'icon_offset_y',
			[
				'label' => esc_html__( 'Offset Y', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'em', 'rem', 'vh', 'vw', 'custom' ],
				'default' => [
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .uc-icon-box .icon-wrap' => 'top: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'icon_offset_orientation_v!' => 'end',
					'icon_position_type' => 'absolute',
				],
			]
		);

		$this->add_responsive_control(
			'icon_offset_y_end',
			[
				'label' => esc_html__( 'Offset Y', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -1000,
						'max' => 1000,
					],
					'%' => [
						'min' => -200,
						'max' => 200,
					],
					'vh' => [
						'min' => -200,
						'max' => 200,
					],
					'vw' => [
						'min' => -200,
						'max' => 200,
					],
				],
				'size_units' => [ 'px', '%', 'em', 'rem', 'vh', 'vw', 'custom' ],
				'default' => [
					'size' => 0,
				],
				'selectors' => [
					'{{WRAPPER}} .uc-icon-box .icon-wrap' => 'bottom: {{SIZE}}{{UNIT}}',
				],
				'condition' => [
					'icon_offset_orientation_v' => 'end',
					'icon_position_type' => 'absolute',
				],
			]
		);

        $this->add_control(
            'icon_translate_middle',
            [
                'label' => __('Translate Middle', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => __('None', 'unistudio-core'),
                    'translate-middle' => __('All', 'unistudio-core'),
                    'translate-middle-y' => __('Vertical', 'unistudio-core'),
                    'translate-middle-x' => __('Horizontal', 'unistudio-core'),
                ],
                'condition' => [
                    'icon_position_type' => 'absolute',
                ],
                'frontend_available' => true,
                'render_type' => 'template',
            ]
        );

        // Z-Index
        $this->add_control(
            'icon_z_index',
            [
                'label' => __('Z-Index', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 1,
                'min' => -999,
                'max' => 999,
                'step' => 1,
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .icon-wrap' => 'z-index: {{VALUE}};',
                ],
                'condition' => [
                    'icon_position_type' => 'absolute',
                ],
            ]
        );

        $this->add_control(
			'icon_style_divider',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => __('Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 16,
                        'max' => 100,
                    ],
                    'rem' => [
                        'min' => 1,
                        'max' => 10,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
                'selectors' => [
                    '{{WRAPPER}} .icon-box i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .icon-box svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Icon Size Controls
        $this->add_responsive_control(
            'icon_width',
            [
                'label' => __('Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 48,
                ],
                'selectors' => [
                    '{{WRAPPER}} .icon-wrap, {{WRAPPER}} .icon-box' => 'width: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_height',
            [
                'label' => __('Height', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 20,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 48,
                ],
                'selectors' => [
                    '{{WRAPPER}} .icon-wrap, {{WRAPPER}} .icon-box' => 'height: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .icon-box i' => 'color: {{VALUE}} !important;',
                    '{{WRAPPER}} .icon-box svg' => 'fill: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_control(
            'icon_background_color',
            [
                'label' => __('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => 'var(--color-primary)',
                'selectors' => [
                    '{{WRAPPER}} .icon-box' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // Border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'icon_border',
                'label' => __('Border', 'unistudio-core'),
                'selector' => '{{WRAPPER}} .icon-box',
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'icon_border_radius',
            [
                'label' => __('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '12',
                    'right' => '12',
                    'bottom' => '12',
                    'left' => '12',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .icon-box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Box Shadow
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'icon_box_shadow',
                'label' => __('Box Shadow', 'unistudio-core'),
                'selector' => '{{WRAPPER}} .icon-box',
            ]
        );

        $this->end_controls_section();
    }
    
    protected function register_text_styling_controls() {
        // Text Style Section
        $this->start_controls_section(
            'section_text_style',
            [
                'label' => __('Text', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // Title Style
        $this->add_control(
            'title_style_heading',
            [
                'label' => __('Title', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __('Typography', 'unistudio-core'),
                'selector' => '{{WRAPPER}} .title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => __('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '8',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
            ]
        );

        // Label Text Style
        $this->add_control(
            'label_style_heading',
            [
                'label' => __('Label', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'label_text!' => ''
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'label_typography',
                'label' => __('Typography', 'unistudio-core'),
                'selector' => '{{WRAPPER}} .label-text',
                'condition' => [
                    'label_text!' => ''
                ],
            ]
        );

        $this->add_control(
            'label_color',
            [
                'label' => __('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .label-text' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'label_text!' => ''
                ],
            ]
        );

        $this->add_responsive_control(
            'label_margin',
            [
                'label' => __('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .label-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'condition' => [
                    'label_text!' => ''
                ]
            ]
        );

        // Description Style
        $this->add_control(
            'description_style_heading',
            [
                'label' => __('Description', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'description!' => ''
                ]
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'label' => __('Typography', 'unistudio-core'),
                'selector' => '{{WRAPPER}} .desc',
                'condition' => [
                    'description!' => ''
                ]
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .desc' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'description!' => ''
                ]
            ]
        );

        $this->add_responsive_control(
            'description_margin',
            [
                'label' => __('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'description!' => ''
                ]
            ]
        );

        $this->end_controls_section();
    }

    protected function register_cta_link_styling_controls() {
        // Button Style Section
        $this->start_controls_section(
            'section_button_style',
            [
                'label' => __('CTA', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_cta' => 'yes',
                ],
            ]
        );

        // Position Type
        $this->add_control(
            'cta_position_type',
            [
                'label' => __('Position', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'relative',
                'options' => [
                    'relative' => __('Relative', 'unistudio-core'),
                    'absolute' => __('Absolute', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .cta' => 'position: {{VALUE}};',
                ],
                'frontend_available' => true,
                'render_type' => 'template',
                'condition' => [
                    'show_cta' => 'yes',
                ],
            ]
        );

        // Horizontal Orientation
        $left = esc_html__('Left', 'elementor');
        $right = esc_html__('Right', 'elementor');

        $start = is_rtl() ? $right : $left;
        $end = !is_rtl() ? $right : $left;

        $this->add_control(
            'cta_offset_orientation_h',
            [
                'label' => esc_html__('Horizontal Orientation', 'elementor'),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => false,
                'default' => 'start',
                'options' => [
                    'start' => [
                        'title' => $start,
                        'icon' => 'eicon-h-align-left',
                    ],
                    'end' => [
                        'title' => $end,
                        'icon' => 'eicon-h-align-right',
                    ],
                ],
                'classes' => 'elementor-control-start-end',
                'render_type' => 'ui',
                'condition' => [
                    'show_cta' => 'yes',
                    'cta_position_type' => 'absolute',
                ],
            ]
        );

        // Offset X
        $this->add_responsive_control(
            'cta_offset_x',
            [
                'label' => esc_html__('Offset X', 'elementor'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                    'vw' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                    'vh' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'size_units' => ['px', '%', 'em', 'rem', 'vw', 'vh', 'custom'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .uc-icon-box .cta' => 'left: {{SIZE}}{{UNIT}}',
                    'body.rtl {{WRAPPER}} .uc-icon-box .cta' => 'right: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'show_cta' => 'yes',
                    'cta_offset_orientation_h!' => 'end',
                    'cta_position_type' => 'absolute',
                ],
            ]
        );

        // Offset X End
        $this->add_responsive_control(
            'cta_offset_x_end',
            [
                'label' => esc_html__('Offset X', 'elementor'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                    'vw' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                    'vh' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'size_units' => ['px', '%', 'em', 'rem', 'vw', 'vh', 'custom'],
                'selectors' => [
                    'body:not(.rtl) {{WRAPPER}} .uc-icon-box .cta' => 'right: {{SIZE}}{{UNIT}}',
                    'body.rtl {{WRAPPER}} .uc-icon-box .cta' => 'left: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'show_cta' => 'yes',
                    'cta_offset_orientation_h' => 'end',
                    'cta_position_type' => 'absolute',
                ],
            ]
        );

        // Vertical Orientation
        $this->add_control(
            'cta_offset_orientation_v',
            [
                'label' => esc_html__('Vertical Orientation', 'elementor'),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => false,
                'default' => 'start',
                'options' => [
                    'start' => [
                        'title' => esc_html__('Top', 'elementor'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'end' => [
                        'title' => esc_html__('Bottom', 'elementor'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'render_type' => 'ui',
                'condition' => [
                    'show_cta' => 'yes',
                    'cta_position_type' => 'absolute',
                ],
            ]
        );

        // Offset Y
        $this->add_responsive_control(
            'cta_offset_y',
            [
                'label' => esc_html__('Offset Y', 'elementor'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                    'vh' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                    'vw' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'size_units' => ['px', '%', 'em', 'rem', 'vh', 'vw', 'custom'],
                'default' => [
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .cta' => 'top: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'show_cta' => 'yes',
                    'cta_offset_orientation_v!' => 'end',
                    'cta_position_type' => 'absolute',
                ],
            ]
        );

        // Offset Y End
        $this->add_responsive_control(
            'cta_offset_y_end',
            [
                'label' => esc_html__('Offset Y', 'elementor'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -1000,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                    'vh' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                    'vw' => [
                        'min' => -200,
                        'max' => 200,
                    ],
                ],
                'size_units' => ['px', '%', 'em', 'rem', 'vh', 'vw', 'custom'],
                'default' => [
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .cta' => 'bottom: {{SIZE}}{{UNIT}}',
                ],
                'condition' => [
                    'show_cta' => 'yes',
                    'cta_offset_orientation_v' => 'end',
                    'cta_position_type' => 'absolute',
                ],
            ]
        );

        // Translate Middle
        $this->add_control(
            'cta_translate_middle',
            [
                'label' => __('Translate Middle', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => __('None', 'unistudio-core'),
                    'translate-middle' => __('All', 'unistudio-core'),
                    'translate-middle-y' => __('Vertical', 'unistudio-core'),
                    'translate-middle-x' => __('Horizontal', 'unistudio-core'),
                ],
                'condition' => [
                    'show_cta' => 'yes',
                    'cta_position_type' => 'absolute',
                ],
                'frontend_available' => true,
                'render_type' => 'template',
            ]
        );

        // Z-Index
        $this->add_control(
            'cta_z_index',
            [
                'label' => __('Z-Index', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 1,
                'min' => -999,
                'max' => 999,
                'step' => 1,
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .cta' => 'z-index: {{VALUE}};',
                ],
                'condition' => [
                    'show_cta' => 'yes',
                    'cta_position_type' => 'absolute',
                ],
            ]
        );

        // Divider
        $this->add_control(
            'cta_position_divider',
            [
                'type' => Controls_Manager::DIVIDER,
                'condition' => [
                    'show_cta' => 'yes',
                ],
            ]
        );
        
        // Button colors
        $this->start_controls_tabs('button_colors');
        
        // Normal state
        $this->start_controls_tab(
            'button_colors_normal',
            ['label' => __('Normal', 'unistudio-core')]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'label' => __('Typography', 'unistudio-core'),
                'selector' => '{{WRAPPER}} .uc-button',
            ]
        );
        
        $this->add_control(
            'button_text_color',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => 'var(--color-primary)',
                'selectors' => [
                    '{{WRAPPER}} .uc-button' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'button_background_color',
            [
                'label' => __('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => 'transparent',
                'selectors' => [
                    '{{WRAPPER}} .uc-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        // Hover state
        $this->start_controls_tab(
            'button_colors_hover',
            ['label' => __('Hover', 'unistudio-core')]
        );
        
        $this->add_control(
            'button_text_color_hover',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'button_background_color_hover',
            [
                'label' => __('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-button:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_tab();
        
        $this->end_controls_tabs();

        $this->add_control(
			'button_style_divider',
			[
				'type' => Controls_Manager::DIVIDER,
			]
		);
        
        // Button padding
        $this->add_responsive_control(
            'button_padding',
            [
                'label' => __('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        // Button margin
        $this->add_responsive_control(
            'button_margin',
            [
                'label' => __('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'selector' => '{{WRAPPER}} .uc-button',
                'separator' => 'before',
                'fields_options' => [
                    'border' => [
                        'default' => 'solid',
                    ],
                    'width' => [
                        'default' => [
                            'top' => '0',
                            'right' => '0',
                            'bottom' => '0',
                            'left' => '0',
                            'unit' => 'px',
                            'isLinked' => true,
                        ],
                    ],
                ],
            ]
        );

        // Border Radius
        $this->add_control(
            'border_radius',
            [
                'label' => __('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Button Shadow
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow',
                'selector' => '{{WRAPPER}} .uc-button',
            ]
        );

        $this->add_control(
            'cta_icon_heading',
            [
                'label' => esc_html__('CTA Icon', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_cta' => 'yes',
                    'show_cta_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'cta_icon',
            [
                'label' => __('Icon', 'unistudio-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'unicon-arrow-right',
                    'library' => 'unicons',
                ],
                'recommended' => [
                    'unicons' => [
                        'star-filled',
                        'star',
                        'arrow-down',
                        'arrow-up',
                        'arrow-left',
                        'arrow-right',
                        'arrow-up-right',
                        'add',
                        'add-alt',
                        'add-alt-filled',
                        'download-cloud',
                        'upload-cloud',
                        'cart',
                        'bookmark-filled',
                        'view-alt-filled',
                        'location-filled',
                    ],
                ],
                'condition' => [
                    'show_cta' => 'yes',
                    'show_cta_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'cta_icon_position',
            [
                'label' => __('Position', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'after',
                'options' => [
                    'before' => __('Before', 'unistudio-core'),
                    'after' => __('After', 'unistudio-core'),
                ],
                'condition' => [
                    'show_cta' => 'yes',
                    'show_cta_icon' => 'yes',
                    'link_text!' => '',
                ],
            ]
        );

        $this->add_responsive_control(
            'cta_icon_size',
            [
                'label' => __('Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 12,
                        'max' => 48,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-button i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_cta' => 'yes',
                    'show_cta_icon' => 'yes',
                ],
            ]
        );
        
        $this->end_controls_section();
    }

    protected function register_hover_effects_controls() {

        $this->start_controls_section(
            'section_hover_effects',
            [
                'label' => __('Hover Effects', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
    
        // Container Hover Effects
        $this->start_controls_tabs(
            'container_hover_effects'
        );
    
        // Normal State
        $this->start_controls_tab(
            'container_normal_state',
            [
                'label' => __('Normal', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'icon_heading',
            [
                'label' => esc_html__('Icon', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'selected_icon[value]!' => '',
                ],
            ]
        );
    
        // Transform Scale
        $this->add_control(
            'icon_scale',
            [
                'label' => __('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.8,
                        'max' => 1.5,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'condition' => [
                    'selected_icon[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .icon-box' => 'transform: scale({{SIZE}}) translateX({{icon_translate_x.SIZE}}px) translateY({{icon_translate_y.SIZE}}px);',
                ],
            ]
        );
    
        // Transform TranslateY
        $this->add_control(
            'icon_translate_y',
            [
                'label' => __('Translate Y', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'selected_icon[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .icon-box' => 'transform: scale({{icon_scale.SIZE}}) translateY({{SIZE}}px) translateX({{icon_translate_x.SIZE}}px);',
                ],
            ]
        );
    
        // Transform TranslateX
        $this->add_control(
            'icon_translate_x',
            [
                'label' => __('Translate X', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'selected_icon[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .icon-box' => 'transform: scale({{icon_scale.SIZE}}) translateX({{SIZE}}px) translateY({{icon_translate_y.SIZE}}px);',
                ],
            ]
        );
    
        // Opacity
        $this->add_control(
            'icon_opacity',
            [
                'label' => __('Opacity', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.01,
                    ],
                ],
                'condition' => [
                    'selected_icon[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .icon-box' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'title_heading',
            [
                'label' => esc_html__('Title', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'title!' => '',
                ]
            ]
        );
    
        // Transform Scale
        $this->add_control(
            'title_scale',
            [
                'label' => __('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.8,
                        'max' => 1.5,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'condition' => [
                    'title!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .title' => 'transform: scale({{SIZE}}) translateX({{title_translate_x.SIZE}}px) translateY({{title_translate_y.SIZE}}px);',
                ],
            ]
        );

        // Transform TranslateY
        $this->add_control(
            'title_translate_y',
            [
                'label' => __('Translate Y', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'title!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .title' => 'transform: scale({{title_scale.SIZE}}) translateY({{SIZE}}px) translateX({{title_translate_x.SIZE}}px);',
                ],
            ]
        );

        // Transform TranslateX
        $this->add_control(
            'title_translate_x',
            [
                'label' => __('Translate X', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'title!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .title' => 'transform: scale({{title_scale.SIZE}}) translateX({{SIZE}}px) translateY({{title_translate_y.SIZE}}px);',
                ],
            ]
        );
    
        // Opacity
        $this->add_control(
            'title_opacity',
            [
                'label' => __('Opacity', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.01,
                    ],
                ],
                'condition' => [
                    'title!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .title' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'label_heading',
            [
                'label' => esc_html__('Label', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'label_text!' => '',
                ]
            ]
        );
        
        // Transform Scale
        $this->add_control(
            'label_scale',
            [
                'label' => __('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.8,
                        'max' => 1.5,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'condition' => [
                    'label_text!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .label-text' => 'transform: scale({{SIZE}}) translateX({{label_translate_x.SIZE}}px) translateY({{label_translate_y.SIZE}}px);',
                ],
            ]
        );
        
        // Transform TranslateY
        $this->add_control(
            'label_translate_y',
            [
                'label' => __('Translate Y', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'label_text!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .label-text' => 'transform: scale({{label_scale.SIZE}}) translateY({{SIZE}}px) translateX({{label_translate_x.SIZE}}px);',
                ],
            ]
        );
        
        // Transform TranslateX
        $this->add_control(
            'label_translate_x',
            [
                'label' => __('Translate X', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'label_text!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .label-text' => 'transform: scale({{label_scale.SIZE}}) translateX({{SIZE}}px) translateY({{label_translate_y.SIZE}}px);',
                ],
            ]
        );
        
        // Opacity
        $this->add_control(
            'label_opacity',
            [
                'label' => __('Opacity', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.01,
                    ],
                ],
                'condition' => [
                    'label_text!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .label-text' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'desc_heading',
            [
                'label' => esc_html__('Description', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'description!' => '',
                ],
            ]
        );
    
        // Transform Scale
        $this->add_control(
            'desc_scale',
            [
                'label' => __('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.8,
                        'max' => 1.5,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'condition' => [
                    'description!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .desc' => 'transform: scale({{SIZE}}) translateX({{desc_translate_x.SIZE}}px) translateY({{desc_translate_y.SIZE}}px);',
                ],
            ]
        );

        // Transform TranslateY
        $this->add_control(
            'desc_translate_y',
            [
                'label' => __('Translate Y', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'description!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .desc' => 'transform: scale({{desc_scale.SIZE}}) translateY({{SIZE}}px) translateX({{desc_translate_x.SIZE}}px);',
                ],
            ]
        );

        // Transform TranslateX
        $this->add_control(
            'desc_translate_x',
            [
                'label' => __('Translate X', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'description!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .desc' => 'transform: scale({{desc_scale.SIZE}}) translateX({{SIZE}}px) translateY({{desc_translate_y.SIZE}}px);',
                ],
            ]
        );
    
        // Opacity
        $this->add_control(
            'desc_opacity',
            [
                'label' => __('Opacity', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.01,
                    ],
                ],
                'condition' => [
                    'description!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .desc' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'cta_heading',
            [
                'label' => esc_html__('CTA', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_cta' => 'yes',
                ],
            ]
        );
    
        // Transform Scale
        $this->add_control(
            'cta_scale',
            [
                'label' => __('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.8,
                        'max' => 1.5,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'condition' => [
                    'show_cta' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .cta' => 'transform: scale({{SIZE}}) rotate({{cta_rotate.SIZE}}deg) translateX({{cta_translate_x.SIZE}}px) translateY({{cta_translate_y.SIZE}}px);',
                ],
            ]
        );

        // Transform TranslateY
        $this->add_control(
            'cta_translate_y',
            [
                'label' => __('Translate Y', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'show_cta' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .cta' => 'transform: scale({{cta_scale.SIZE}}) rotate({{cta_rotate.SIZE}}deg) translateY({{SIZE}}px) translateX({{cta_translate_x.SIZE}}px);',
                ],
            ]
        );

        // Transform TranslateX
        $this->add_control(
            'cta_translate_x',
            [
                'label' => __('Translate X', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'show_cta' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .cta' => 'transform: scale({{cta_scale.SIZE}}) rotate({{cta_rotate.SIZE}}deg) translateX({{SIZE}}px) translateY({{cta_translate_y.SIZE}}px);',
                ],
            ]
        );

        // Transform Rotate
        $this->add_control(
            'cta_rotate',
            [
                'label' => __('Rotate', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -360,
                        'max' => 360,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'show_cta' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .cta' => 'transform: scale({{cta_scale.SIZE}}) rotate({{SIZE}}deg) translateX({{cta_translate_x.SIZE}}px) translateY({{cta_translate_y.SIZE}}px);',
                ],
            ]
        );
    
        // Opacity
        $this->add_control(
            'cta_opacity',
            [
                'label' => __('Opacity', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.01,
                    ],
                ],
                'condition' => [
                    'show_cta' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box .cta' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'transition_heading',
            [
                'label' => esc_html__('Transitions', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
    
        // Transition Duration
        $this->add_control(
            'container_transition_duration',
            [
                'label' => __('Duration', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'size' => 0.3,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box, {{WRAPPER}} .uc-icon-box .icon-box, {{WRAPPER}} .uc-icon-box .title, {{WRAPPER}} .uc-icon-box .label-text, {{WRAPPER}} .uc-icon-box .desc, {{WRAPPER}} .uc-icon-box .cta' => 'transition-duration: {{SIZE}}s;',
                ],
            ]
        );

        // Timing Function
        $this->add_control(
            'container_transition_timing',
            [
                'label' => __('Timing Function', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'ease',
                'options' => [
                    'linear' => __('Linear', 'unistudio-core'),
                    'ease' => __('Ease', 'unistudio-core'),
                    'ease-in' => __('Ease In', 'unistudio-core'),
                    'ease-out' => __('Ease Out', 'unistudio-core'),
                    'ease-in-out' => __('Ease In Out', 'unistudio-core'),
                    'custom' => __('Custom', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box, {{WRAPPER}} .uc-icon-box .icon-box, {{WRAPPER}} .uc-icon-box .title, {{WRAPPER}} .uc-icon-box .label-text, {{WRAPPER}} .uc-icon-box .desc, {{WRAPPER}} .uc-icon-box .cta' => 'transition-timing-function: {{VALUE}};',
                ],
            ]
        );

        // Custom Timing Function (cubic-bezier)
        $this->add_control(
            'container_transition_custom_timing',
            [
                'label' => __('Custom Timing', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'cubic-bezier(0.4, 0, 0.2, 1)',
                'description' => __('Enter cubic-bezier values cubic-bezier(0.4, 0, 0.2, 1).', 'unistudio-core'),
                'condition' => [
                    'container_transition_timing' => 'custom',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box, {{WRAPPER}} .uc-icon-box .icon-box, {{WRAPPER}} .uc-icon-box .title, {{WRAPPER}} .uc-icon-box .label-text, {{WRAPPER}} .uc-icon-box .desc, {{WRAPPER}} .uc-icon-box .cta' => 'transition-timing-function: {{VALUE}};',
                ],
            ]
        );
    
        // Transition Properties
        $this->add_control(
            'container_transition_property',
            [
                'label' => __('Property', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'all',
                'options' => [
                    'all' => __('All', 'unistudio-core'),
                    'transform' => __('Transform', 'unistudio-core'),
                    'background' => __('Background', 'unistudio-core'),
                    'border' => __('Border', 'unistudio-core'),
                    'box-shadow' => __('Box Shadow', 'unistudio-core'),
                    'opacity' => __('Opacity', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box, {{WRAPPER}} .uc-icon-box .icon-box, {{WRAPPER}} .uc-icon-box .title, {{WRAPPER}} .uc-icon-box .label-text, {{WRAPPER}} .uc-icon-box .desc, {{WRAPPER}} .uc-icon-box .cta' => 'transition-property: {{VALUE}};',
                ],
            ]
        );
            
        $this->end_controls_tab();
    
        // Hover State
        $this->start_controls_tab(
            'container_hover_state',
            [
                'label' => __('Hover', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'card_hover_heading',
            [
                'label' => esc_html__('Card', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
    
        // Background on hover
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'label' => __('Background', 'unistudio-core'),
                'name' => 'container_background_hover',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .uc-icon-box:hover',
            ]
        );
    
        // Box Shadow on hover
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'label' => __('Shadow', 'unistudio-core'),
                'name' => 'container_box_shadow_hover',
                'selector' => '{{WRAPPER}} .uc-icon-box:hover',
            ]
        );
    
        // Border Color on hover
        $this->add_control(
            'container_border_color_hover',
            [
                'label' => __('Border Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'container_border_border!' => '',
                ],
            ]
        );

        // Border Radius
        $this->add_responsive_control(
            'container_border_radius_hover',
            [
                'label' => __('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        // Transform Scale
        $this->add_control(
            'container_scale_hover',
            [
                'label' => __('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.8,
                        'max' => 1.5,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover' => 'transform: scale({{SIZE}}) translateX({{container_translate_x_hover.SIZE}}px) translateY({{container_translate_y_hover.SIZE}}px);',
                ],
            ]
        );
    
        // Transform TranslateY
        $this->add_control(
            'container_translate_y_hover',
            [
                'label' => __('Translate Y', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover' => 'transform: scale({{container_scale_hover.SIZE}}) translateY({{SIZE}}px) translateX({{container_translate_x_hover.SIZE}}px);',
                ],
            ]
        );
    
        // Transform TranslateX
        $this->add_control(
            'container_translate_x_hover',
            [
                'label' => __('Translate X', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover' => 'transform: scale({{container_scale_hover.SIZE}}) translateX({{SIZE}}px) translateY({{container_translate_y_hover.SIZE}}px);',
                ],
            ]
        );

        $this->add_control(
            'icon_hover_heading',
            [
                'label' => esc_html__('Icon', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'selected_icon[value]!' => '',
                ]
            ]
        );

        $this->add_control(
            'icon_hover_color',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'selected_icon[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .icon-box i' => 'color: {{VALUE}} !important;',
                    '{{WRAPPER}} .uc-icon-box:hover .icon-box svg' => 'fill: {{VALUE}} !important;',
                ],
            ]
        );
    
        // Transform Scale
        $this->add_control(
            'icon_scale_hover',
            [
                'label' => __('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.8,
                        'max' => 1.5,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'condition' => [
                    'selected_icon[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .icon-box' => 'transform: scale({{SIZE}}) translateX({{icon_translate_x_hover.SIZE}}px) translateY({{icon_translate_y_hover.SIZE}}px);',
                ],
            ]
        );
    
        // Transform TranslateY
        $this->add_control(
            'icon_translate_y_hover',
            [
                'label' => __('Translate Y', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'selected_icon[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .icon-box' => 'transform: scale({{icon_scale_hover.SIZE}}) translateY({{SIZE}}px) translateX({{icon_translate_x_hover.SIZE}}px);',
                ],
            ]
        );
    
        // Transform TranslateX
        $this->add_control(
            'icon_translate_x_hover',
            [
                'label' => __('Translate X', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'selected_icon[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .icon-box' => 'transform: scale({{icon_scale_hover.SIZE}}) translateX({{SIZE}}px) translateY({{icon_translate_y_hover.SIZE}}px);',
                ],
            ]
        );
    
        // Opacity
        $this->add_control(
            'icon_opacity_hover',
            [
                'label' => __('Opacity', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.01,
                    ],
                ],
                'condition' => [
                    'selected_icon[value]!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .icon-box' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'title_hover_heading',
            [
                'label' => esc_html__('Title', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'title!' => '',
                ],
            ]
        );

        $this->add_control(
            'title_hover_color',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'title!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .title' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        // Transform Scale
        $this->add_control(
            'title_scale_hover',
            [
                'label' => __('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.8,
                        'max' => 1.5,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'condition' => [
                    'title!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .title' => 'transform: scale({{SIZE}}) translateX({{title_translate_x_hover.SIZE}}px) translateY({{title_translate_y_hover.SIZE}}px);',
                ],
            ]
        );

        // Transform TranslateY
        $this->add_control(
            'title_translate_y_hover',
            [
                'label' => __('Translate Y', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'title!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .title' => 'transform: scale({{title_scale_hover.SIZE}}) translateY({{SIZE}}px) translateX({{title_translate_x_hover.SIZE}}px);',
                ],
            ]
        );

        // Transform TranslateX Hover
        $this->add_control(
            'title_translate_x_hover',
            [
                'label' => __('Translate X', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'title!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .title' => 'transform: scale({{title_scale_hover.SIZE}}) translateX({{SIZE}}px) translateY({{title_translate_y_hover.SIZE}}px);',
                ],
            ]
        );
    
        // Opacity
        $this->add_control(
            'title_opacity_hover',
            [
                'label' => __('Opacity', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.01,
                    ],
                ],
                'condition' => [
                    'title!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .title' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'label_hover_heading',
            [
                'label' => esc_html__('Label', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'label_text!' => '',
                ],
            ]
        );
        
        $this->add_control(
            'label_hover_color',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'label_text!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .label-text' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        // Transform Scale
        $this->add_control(
            'label_scale_hover',
            [
                'label' => __('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.8,
                        'max' => 1.5,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'condition' => [
                    'label_text!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .label-text' => 'transform: scale({{SIZE}}) translateX({{label_translate_x_hover.SIZE}}px) translateY({{label_translate_y_hover.SIZE}}px);',
                ],
            ]
        );
        
        // Transform TranslateY
        $this->add_control(
            'label_translate_y_hover',
            [
                'label' => __('Translate Y', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'label_text!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .label-text' => 'transform: scale({{label_scale_hover.SIZE}}) translateY({{SIZE}}px) translateX({{label_translate_x_hover.SIZE}}px);',
                ],
            ]
        );
        
        // Transform TranslateX
        $this->add_control(
            'label_translate_x_hover',
            [
                'label' => __('Translate X', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'label_text!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .label-text' => 'transform: scale({{label_scale_hover.SIZE}}) translateX({{SIZE}}px) translateY({{label_translate_y_hover.SIZE}}px);',
                ],
            ]
        );
        
        // Opacity
        $this->add_control(
            'label_opacity_hover',
            [
                'label' => __('Opacity', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.01,
                    ],
                ],
                'condition' => [
                    'label_text!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .label-text' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'desc_hover_heading',
            [
                'label' => esc_html__('Description', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'description!' => '',
                ],
            ]
        );

        $this->add_control(
            'desc_hover_color',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'description!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .desc' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        // Transform Scale
        $this->add_control(
            'desc_scale_hover',
            [
                'label' => __('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.8,
                        'max' => 1.5,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'condition' => [
                    'description!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .desc' => 'transform: scale({{SIZE}}) translateX({{desc_translate_x_hover.SIZE}}px) translateY({{desc_translate_y_hover.SIZE}}px);',
                ],
            ]
        );

        // Transform TranslateY
        $this->add_control(
            'desc_translate_y_hover',
            [
                'label' => __('Translate Y', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'description!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .desc' => 'transform: scale({{desc_scale_hover.SIZE}}) translateY({{SIZE}}px) translateX({{desc_translate_x_hover.SIZE}}px);',
                ],
            ]
        );

        // Transform TranslateX Hover
        $this->add_control(
            'desc_translate_x_hover',
            [
                'label' => __('Translate X', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'description!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .desc' => 'transform: scale({{desc_scale_hover.SIZE}}) translateX({{SIZE}}px) translateY({{desc_translate_y_hover.SIZE}}px);',
                ],
            ]
        );
    
        // Opacity
        $this->add_control(
            'desc_opacity_hover',
            [
                'label' => __('Description Opacity', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.01,
                    ],
                ],
                'condition' => [
                    'description!' => '',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .desc' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'cta_hover_heading',
            [
                'label' => esc_html__('CTA', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_cta' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'cta_hover_color',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'show_cta' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .cta a' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        // Transform Scale
        $this->add_control(
            'cta_scale_hover',
            [
                'label' => __('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.8,
                        'max' => 1.5,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'condition' => [
                    'show_cta' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .cta' => 'transform: scale({{SIZE}}) rotate({{cta_rotate_hover.SIZE}}deg) translateX({{cta_translate_x_hover.SIZE}}px) translateY({{cta_translate_y_hover.SIZE}}px);',
                ],
            ]
        );

        // Transform TranslateY
        $this->add_control(
            'cta_translate_y_hover',
            [
                'label' => __('Translate Y', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'show_cta' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .cta' => 'transform: scale({{cta_scale_hover.SIZE}}) rotate({{cta_rotate_hover.SIZE}}deg) translateY({{SIZE}}px) translateX({{cta_translate_x_hover.SIZE}}px);',
                ],
            ]
        );

        // Transform TranslateX Hover
        $this->add_control(
            'cta_translate_x_hover',
            [
                'label' => __('Translate X', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'show_cta' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .cta' => 'transform: scale({{cta_scale_hover.SIZE}}) rotate({{cta_rotate_hover.SIZE}}deg) translateX({{SIZE}}px) translateY({{cta_translate_y_hover.SIZE}}px);',
                ],
            ]
        );

        // Transform Rotate Hover
        $this->add_control(
            'cta_rotate_hover',
            [
                'label' => __('Rotate', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -360,
                        'max' => 360,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'condition' => [
                    'show_cta' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .cta' => 'transform: scale({{cta_scale_hover.SIZE}}) rotate({{SIZE}}deg) translateX({{cta_translate_x_hover.SIZE}}px) translateY({{cta_translate_y_hover.SIZE}}px);',
                ],
            ]
        );
    
        // Opacity
        $this->add_control(
            'cta_opacity_hover',
            [
                'label' => __('Opacity', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.01,
                    ],
                ],
                'condition' => [
                    'show_cta' => 'yes',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-icon-box:hover .cta' => 'opacity: {{SIZE}};',
                ],
            ]
        );
    
        $this->end_controls_tab();
    
        $this->end_controls_tabs();
    
        $this->end_controls_section();
    }

    protected function render() {

        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_icon_box')) {
            return;
        }

        $settings = $this->get_settings_for_display();
        $layout_class = 'uc-layout-' . $settings['content_wrapper_layout'];
        
        // Add layout class to wrapper
        $this->add_render_attribute('wrapper', 'class', [
            'uc-icon-box',
            $layout_class
        ]);
        
        ?>
        <div <?php $this->print_render_attribute_string('wrapper'); ?>>
            <?php
            if ($settings['show_cover_link'] === 'yes' && !empty($settings['cover_link_url']['url'])) {
                $this->add_link_attributes('cover_link', $settings['cover_link_url']);
                $this->add_render_attribute('cover_link', 'class', 'cover-link');
                ?>
                <a <?php $this->print_render_attribute_string('cover_link'); ?>></a>
            <?php }
            switch($settings['content_wrapper_layout']) {
                case 'wrap-content-cta':
                    $this->render_icon_box_icon();
                    ?>
                    <div class="content-wrap panel">
                        <?php 
                        $this->render_icon_box_content();
                        $this->render_icon_box_cta(); 
                        ?>
                    </div>
                    <?php
                    break;
                    
                case 'wrap-content-icon':
                    ?>
                    <div class="content-wrap panel">
                        <?php 
                        $this->render_icon_box_icon();
                        $this->render_icon_box_content(); 
                        ?>
                    </div>
                    <?php
                    $this->render_icon_box_cta();
                    break;
                    
                case 'no-wrap':
                    $this->render_icon_box_icon();
                    ?>
                    <div class="content-wrap panel">
                        <?php $this->render_icon_box_content(); ?>
                    </div>
                    <?php
                    $this->render_icon_box_cta();
                    break;
            }
            ?>
        </div>
        <?php
    }

    protected function render_icon_box_icon() {
        $settings = $this->get_settings_for_display();
        
        if (!empty($settings['selected_icon']['value'])) {
            $this->add_render_attribute('icon-box', 'class', 'icon-box');
            
            // Add positioning class
            if ($settings['icon_position_type'] === 'absolute') {
                $this->add_render_attribute('icon-wrap', 'class', [
                    'icon-wrap',
                    $settings['icon_translate_middle']
                ]);
            }
            
            ?>
            <div <?php echo $this->get_render_attribute_string('icon-wrap'); ?>>
                <div <?php echo $this->get_render_attribute_string('icon-box'); ?>>
                    <?php
                        if (isset($settings['selected_icon']['library']) && $settings['selected_icon']['library'] === 'svg') {
                            echo '<img class="uc-custom-icon" src="' . esc_url($settings['selected_icon']['value']['url']) . '" alt="svg-icon" ' . ($settings['icon_svg_inherit'] === "yes" ? "data-uc-svg" : "") . '>';
                        } else {
                            \Elementor\Icons_Manager::render_icon($settings['selected_icon'], ['aria-hidden' => 'true']);
                        }
                    ?>
                </div>
            </div>
            <?php
        }
    }

    protected function render_icon_box_content() {
        $settings = $this->get_settings_for_display(); ?>

        <div class="content">
            <?php if (!empty($settings['label_text']) && $settings['label_position'] === 'before') : ?>
            <span class="label-text"><?php echo esc_html($settings['label_text']); ?></span>
            <?php endif; ?>

            <?php if (!empty($settings['title'])) : ?>
            <h5 class="title"><?php echo esc_html($settings['title']); ?></h5>
            <?php endif; ?>

            <?php if (!empty($settings['label_text']) && $settings['label_position'] === 'after') : ?>
            <span class="label-text"><?php echo esc_html($settings['label_text']); ?></span>
            <?php endif; ?>
            
            <?php if (!empty($settings['description'])) : ?>
            <p class="desc"><?php echo esc_html($settings['description']); ?></p>
            <?php endif; ?>
        </div>
        
        <?php
    }

    protected function render_icon_box_cta() {
        $settings = $this->get_settings_for_display();

        if ($settings['show_cta'] === 'yes') : 
            $this->add_link_attributes('link', $settings['link_url']);
            $class_name = 'uc-button btn';

            // Add positioning class
            $wrapper_classes = ['cta'];
            if ($settings['cta_position_type'] === 'absolute' && !empty($settings['cta_translate_middle'])) {
                $wrapper_classes[] = $settings['cta_translate_middle'];
            }

            ?>
            <div class="<?php echo esc_attr(implode(' ', $wrapper_classes)); ?>">
                <a class="<?php echo esc_attr($class_name); ?>" 
                <?php $this->print_render_attribute_string('link'); ?>>
                    <?php 
                    $has_text = !empty($settings['link_text']);
                    
                    if ($settings['show_cta_icon'] === 'yes' && $has_text && isset($settings['cta_icon_position']) && $settings['cta_icon_position'] === 'before') {
                        \Elementor\Icons_Manager::render_icon($settings['cta_icon'], [
                            'aria-hidden' => 'true',
                            'class' => 'btn-icon-before position-relative fw-bold translate-y-px'
                        ]);
                    }
                    
                    if ($has_text) : ?>
                        <span><?php echo esc_html($settings['link_text']); ?></span>
                    <?php endif;
                    
                    if ($settings['show_cta_icon'] === 'yes' && (!isset($settings['cta_icon_position']) || $settings['cta_icon_position'] === 'after')) {
                        \Elementor\Icons_Manager::render_icon($settings['cta_icon'], [
                            'aria-hidden' => 'true',
                            'class' => 'btn-icon-after position-relative fw-bold translate-y-px'
                        ]);
                    }
                    ?>
                </a>
            </div>
        <?php endif;

    }
}