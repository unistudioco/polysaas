<?php
namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Testimonials extends Slider {
    public function get_name() {
        return 'uc_testimonials';
    }
    
    public function get_title() {
        return __('UC - Testimonial Slider', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-testimonial-carousel';
    }
    
    public function get_style_depends() {
        return ['swiper', 'uc-slider', 'uc-testimonials'];
    }
    
    public function register_widget_styles() {
        Asset_Manager::getInstance()->register_widget_style(
            'uc-testimonials',
            'assets/css/widgets/testimonials.min.css',
            ['uc-core']
        );
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_testimonials',
            [
                'label' => esc_html__('Testimonials', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
            'author_name',
            [
                'label' => esc_html__('Client Name', 'unistudio-core'),
                'default' => esc_html__('John Doe', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
            ]
        );
        
        $repeater->add_control(
            'author_position',
            [
                'label' => esc_html__('Client Position', 'unistudio-core'),
                'default' => esc_html__('CEO at UniStudio', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'feedback_content',
            [
                'label' => esc_html__('Feedback', 'unistudio-core'),
                'default' => esc_html__('“Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur fuga, voluptatem magni autem repellendus neque dolorum est illo ut, quasi dolor.”', 'unistudio-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $repeater->add_control(
            'author_image',
            [
                'label' => esc_html__('Client Image', 'unistudio-core'),
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'author_brand',
            [
                'label' => esc_html__('Client Brand', 'unistudio-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );
      
        $this->add_control(
            'testimonials',
            [
                'label' => esc_html__('Testimonials', 'unistudio-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => $this->get_repeater_defaults(),
                'title_field' => '{{{ author_name }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_testimonials_settings',
            [
                'label' => esc_html__('Settings', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'testimonials_layout',
            [
                'label' => esc_html__('Pre-defined Layouts', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '1',
                'label_block' => 'yes',
                'options' => [
                    '1' => esc_html__('Layout 01', 'unistudio-core'),
                    '2' => esc_html__('Layout 02', 'unistudio-core'),
                    '3' => esc_html__('Layout 03', 'unistudio-core'),
                    '4' => esc_html__('Layout 04', 'unistudio-core'),
                ],
            ]
        );

        $this->add_control(
            'show_image',
            [
                'label' => __('Show Image', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_position',
            [
                'label' => __('Show Position', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_brand',
            [
                'label' => __('Show Brand', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->end_controls_section();

        // Add Testimonial Style Controls
        $this->register_testimonial_style_controls();

        parent::register_controls();

        $this->remove_control('section_slides');
        $this->remove_control('slides');
        $this->remove_control('section_style_image');

    }

    protected function register_testimonial_style_controls() {
        $this->start_controls_section(
            'section_testimonial_style',
            [
                'label' => esc_html__('Testimonial Styling', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
         
        // Testimonial Content Styling
        $this->add_control(
            'style_content_heading',
            [
                'label' => esc_html__('Content', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'style_content_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .testimonial-content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'style_content_typography',
                'selector' => '{{WRAPPER}} .testimonial-content',
            ]
        );
         
        // Testimonial Author Name Styling
        $this->add_control(
            'style_author_name_heading',
            [
                'label' => esc_html__('Author Name', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'style_author_name_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .author-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'style_author_name_typography',
                'selector' => '{{WRAPPER}} .author-name',
            ]
        );
         
        // Testimonial Author Position Styling
        $this->add_control(
            'style_author_position_heading',
            [
                'label' => esc_html__('Author Position', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'show_position' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'style_author_position_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .author-position' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'show_position' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'style_author_position_typography',
                'selector' => '{{WRAPPER}} .author-position',
                'condition' => [
                    'show_position' => 'yes',
                ],
            ]
        );
         
        // Testimonial Author Brand Styling
        $this->add_control(
            'style_author_brand_heading',
            [
                'label' => esc_html__('Author Brand', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'show_brand' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'style_author_brand_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .author-brand .image' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'show_brand' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_testimonial_layout',
            [
                'label' => esc_html__('Testimonial Layout', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
         
        // Testimonial Wrap
        $this->add_control(
            'testimonial_wrap_heading',
            [
                'label' => esc_html__('Testimonial Wrap', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_responsive_control(
            'testimonial_wrap_text_align',
            [
                'label' => __('Text Align', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'unistudio-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'unistudio-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'unistudio-core'),
                        'icon' => 'eicon-text-align-right',
                    ]
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}} .testimonial-content-wrap' => 'text-align: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'testimonial_wrap_width',
            [
                'label' => esc_html__('Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px', 'vh'],
                'range' => [
                    '%' => ['min' => 0, 'max' => 100],
                    'px' => ['min' => 0, 'max' => 1440],
                    'vh' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-content-wrap' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'testimonial_min_height',
            [
                'label' => esc_html__('Min Height', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 1000],
                    'vh' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-slide' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_control(
            'testimonial_direction',
            [
                'label' => esc_html__('Direction', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'column',
                'options' => [
                    'row' => esc_html__('Row', 'unistudio-core'),
                    'column' => esc_html__('Column', 'unistudio-core'),
                    'row-reverse' => esc_html__('Row Reverse', 'unistudio-core'),
                    'column-reverse' => esc_html__('Column Reverse', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-slide' => 'display: flex; flex-direction: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'testimonial_gap',
            [
                'label' => esc_html__('Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 32,
                    'unit' => 'px',
                ],
                'size_units' => ['px', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 128,
                        'step' => 8,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-slide' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'testimonial_vertical_align',
            [
                'label' => esc_html__('Y Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Start', 'unistudio-core'),
                        'icon' => 'eicon-align-start-v',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'unistudio-core'),
                        'icon' => 'eicon-align-center-v',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('End', 'unistudio-core'),
                        'icon' => 'eicon-align-end-v',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-slide' => 'align-items: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'testimonial_horizontal_align',
            [
                'label' => esc_html__('X Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Start', 'unistudio-core'),
                        'icon' => 'eicon-align-start-h',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'unistudio-core'),
                        'icon' => 'eicon-align-center-h',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('End', 'unistudio-core'),
                        'icon' => 'eicon-align-end-h',
                    ],
                    'space-between' => [
                        'title' => esc_html__('Space Between', 'unistudio-core'),
                        'icon' => 'eicon-justify-space-between-h',
                    ],
                    'space-around' => [
                        'title' => esc_html__('Space around', 'unistudio-core'),
                        'icon' => 'eicon-justify-space-around-h',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-slide' => 'justify-content: {{VALUE}};',
                ],
            ]
        );
        
        // Testimonial Author
        $this->add_control(
            'testimonial_author_wrap',
            [
                'label' => esc_html__('Author Wrap', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->add_responsive_control(
            'testimonial_author_wrap_width',
            [
                'label' => esc_html__('Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px', 'vh'],
                'range' => [
                    '%' => ['min' => 0, 'max' => 100],
                    'px' => ['min' => 0, 'max' => 1440],
                    'vh' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-author' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_control(
            'author_direction',
            [
                'label' => esc_html__('Direction', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'row',
                'options' => [
                    'row' => esc_html__('Row', 'unistudio-core'),
                    'column' => esc_html__('Column', 'unistudio-core'),
                    'row-reverse' => esc_html__('Row Reverse', 'unistudio-core'),
                    'column-reverse' => esc_html__('Column Reverse', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-author' => 'display: flex; flex-direction: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'author_vertical_align',
            [
                'label' => esc_html__('Vertical Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Start', 'unistudio-core'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'unistudio-core'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('End', 'unistudio-core'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-author' => 'align-items: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'author_gap',
            [
                'label' => esc_html__('Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 16,
                    'unit' => 'px',
                ],
                'size_units' => ['px', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 128,
                        'step' => 8,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-author' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Testimonial Author Image
        $this->add_control(
            'testimonial_author_image',
            [
                'label' => esc_html__('Author Image', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'author_image_size',
            [
                'label' => esc_html__('Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 56,
                    'unit' => 'px',
                ],
                'size_units' => ['px', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 128,
                        'step' => 8,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-author .author-image .image' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'author_image_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '100',
                    'right' => '100', 
                    'bottom' => '100',
                    'left' => '100',
                    'unit' => '%',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-author .author-image .image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );

        // Testimonial Author Info
        $this->add_control(
            'testimonial_author_info',
            [
                'label' => esc_html__('Author Info', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_position' => 'yes',
                ],
            ]
        );
        
        $this->add_control(
            'author_info_direction',
            [
                'label' => esc_html__('Direction', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'column',
                'options' => [
                    'row' => esc_html__('Row', 'unistudio-core'),
                    'column' => esc_html__('Column', 'unistudio-core'),
                    'row-reverse' => esc_html__('Row Reverse', 'unistudio-core'),
                    'column-reverse' => esc_html__('Column Reverse', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-author .author-info' => 'display: flex; flex-direction: {{VALUE}};',
                ],
                'condition' => [
                    'show_position' => 'yes',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'author_info_vertical_align',
            [
                'label' => esc_html__('Vertical Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Start', 'unistudio-core'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'unistudio-core'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('End', 'unistudio-core'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-author .author-info' => 'align-items: {{VALUE}};',
                ],
                'condition' => [
                    'show_position' => 'yes',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'author_info_gap',
            [
                'label' => esc_html__('Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0,
                    'unit' => 'px',
                ],
                'size_units' => ['px', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonial-author .author-info' => 'gap: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_position' => 'yes',
                ],
            ]
        );

        // Testimonial Author Brand
        $this->add_control(
            'testimonial_author_brand',
            [
                'label' => esc_html__('Author Brand', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_brand' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'testimonial_author_brand_svg',
            [
                'label' => esc_html__('SVG Coloring?', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'description' => esc_html__('If you upload an SVG image you can enable this to inherit coloring.', 'unistudio-core'),
                'default' => '',
                'condition' => [
                    'show_brand' => 'yes',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'testimonial_author_brand_size',
            [
                'label' => esc_html__('Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 128,
                    'unit' => 'px',
                ],
                'size_units' => ['px', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 64,
                        'max' => 256,
                        'step' => 8,
                    ],
                    'rem' => [
                        'min' => 5,
                        'max' => 20,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .author-brand .image' => 'width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_brand' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'testimonial_author_brand_margin',
            [
                'label' => esc_html__('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '24',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .author-brand' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {

        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_testimonials')) {
            return;
        }

        $settings = $this->get_settings_for_display();

        if (empty($settings['testimonials'])) {
            return;
        }

        $this->add_render_attribute('wrapper', [
            'class' => 'elementor-widget-' . $this->get_name(),
            'data-widget' => $this->get_name(),
        ]);

        // Build Swiper options
        $swiper_options = $this->get_slider_options($settings);

        $this->render_slider_wrapper($settings, $swiper_options);

    }

    protected function render_slider_wrapper($settings, $swiper_options) {
        ?>
        <div <?php $this->print_render_attribute_string('wrapper'); ?>>
            <div class="swiper" data-uc-swiper="<?php echo esc_attr(implode('; ', $swiper_options)); ?>" <?php echo $this->get_render_attribute_string('slider'); ?>>
                <div class="swiper-wrapper">
                    <?php $this->render_slides($settings); ?>
                </div>
                <?php 
                $this->render_pagination($settings);
                $this->render_navigation($settings);
                ?>
            </div>
        </div>
        <?php
    }

    protected function render_slides($settings) {
        foreach ($settings['testimonials'] as $testimonial) {
            ?>
            <div class="swiper-slide">
                <?php $this->render_slide_content($settings, $testimonial); ?>
            </div>
            <?php
        }
    }

    protected function render_slide_content($settings, $testimonial) { ?>
       <div class="testimonial-slide">

            <div class="testimonial-content-wrap">
            <?php if ($settings['show_brand'] === 'yes' && !empty($testimonial['author_brand']['url'])): ?>
                <div class="author-brand">
                    <img class="image" src="<?php echo esc_url($testimonial['author_brand']['url']); ?>" 
                            alt="<?php echo esc_attr($testimonial['author_name']); ?>"
                            <?php echo $settings['testimonial_author_brand_svg'] === 'yes' ? 'data-uc-svg' : ''; ?>>
                </div>
            <?php endif; ?>

            <?php if (!empty($testimonial['feedback_content'])): ?>
                <div class="testimonial-content">
                    <?php echo wp_kses_post($testimonial['feedback_content']); ?>
                </div>
            <?php endif; ?>
            </div>

            <div class="testimonial-author">
                <?php if ($settings['show_image'] === 'yes' && !empty($testimonial['author_image']['url'])): ?>
                    <div class="author-image">
                        <img class="image" src="<?php echo esc_url($testimonial['author_image']['url']); ?>" 
                                alt="<?php echo esc_attr($testimonial['author_name']); ?>">
                    </div>
                <?php endif; ?>

                <div class="author-info">
                    <?php if (!empty($testimonial['author_name'])): ?>
                        <h6 class="author-name"><?php echo esc_html($testimonial['author_name']); ?></h6>
                    <?php endif; ?>

                    <?php if ($settings['show_position'] === 'yes' && !empty($testimonial['author_position'])): ?>
                        <div class="author-position">
                            <?php echo esc_html($testimonial['author_position']); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
       <?php
    }

    protected function get_repeater_defaults() {
        return [
            [
                'author_name' => 'Mark Zellers',
                'author_position' => 'CEO, Co-Founder',
                'feedback_content' => '“We’re looking for people who share our vision! most of our time used to be taken up by most of alternate administrative work whereas now we can focus on building out to help our employees.”',
                'author_image' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ],
            [
                'author_name' => 'Natalia Larsson',
                'author_position' => 'Director of Sales',
                'feedback_content' => '“This powerfull tool eliminates the need to leave Salesforce to get things done as I can create a custom proposal with dynamic pricing tables, and get approval from my boss all within 36 minutes.”',
                'author_image' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ],
            [
                'author_name' => 'Sarah Edrissi',
                'author_position' => 'Lead Marketing',
                'feedback_content' => '“We are based in Europe and the latest Data Protection Regulation forces us to look for service suppliers than comply with this regulation and as we look to create our website and this builder just outstanding!”',
                'author_image' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ],
        ];
    }
}