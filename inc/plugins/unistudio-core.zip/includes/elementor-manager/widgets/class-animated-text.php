<?php

namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Animated_Text extends Widget_Base {
    public function get_name() {
        return 'uc_animated_text';
    }
    
    public function get_title() {
        return __('UC - Animated Text', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-animated-headline';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    }
    
    public function get_script_depends() {
        return ['uc-animated-text'];
    }

    public function get_style_depends() {
        return ['uc-animated-text'];
    }

    public function register_widget_scripts() {
        Asset_Manager::getInstance()->register_widget_script(
            'uc-animated-text',
            'assets/js/widgets/animated-text.min.js',
            ['uc-core']
        );
    }

    public function register_widget_styles() {
        Asset_Manager::getInstance()->register_widget_style(
            'uc-animated-text',
            'assets/css/widgets/animated-text.min.css',
            ['uc-core']
        );
    }
    
    protected function register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'state',
            [
                'label' => __('State', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'primary',
                'options' => [
                    'primary' => 'Primary',
                    'secondary' => 'Secondary',
                    'success' => 'Success',
                    'warning' => 'Warning',
                    'danger' => 'Danger',
                ],
            ]
        );
        
        $this->add_control(
            'show_icon',
            [
                'label' => __('Show Icon', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
            ]
        );
        
        $this->end_controls_section();
                
        // Style Sections...
        $this->register_style_controls();
    }
    
    protected function register_style_controls() {

        $this->start_controls_section(
            'section_animated_text_style',
            [
                'label' => __('Animated Text', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_responsive_control(
            'min_width',
            [
                'label' => __('Min width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 150,
                ],
                'range' => [
                    'px' => [
                        'min' => 48,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-animated-text' => 'min-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {

        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_animated_text')) {
            return;
        }

        $settings = $this->get_settings_for_display(); ?>

        <p>Animated Text - Widget</p>

        <?php
    }
}