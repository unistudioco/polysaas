<?php
namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Team_Slider extends Slider {
    public function get_name() {
        return 'uc_team_slider';
    }
    
    public function get_title() {
        return __('UC - Team Slider', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-person';
    }
    
    public function get_style_depends() {
        return ['swiper', 'uc-slider', 'uc-team-slider'];
    }
    
    public function register_widget_styles() {
        Asset_Manager::getInstance()->register_widget_style(
            'uc-team-slider',
            'assets/css/widgets/team-slider.min.css',
            ['uc-core']
        );
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_team_members',
            [
                'label' => esc_html__('Members', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();
        
        $repeater->add_control(
            'member_name',
            [
                'label' => esc_html__('Name', 'unistudio-core'),
                'default' => esc_html__('John Doe', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
            ]
        );
        
        $repeater->add_control(
            'member_position',
            [
                'label' => esc_html__('Position', 'unistudio-core'),
                'default' => esc_html__('CEO at UniStudio', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'member_bio',
            [
                'label' => esc_html__('Bio', 'unistudio-core'),
                'default' => esc_html__('Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur fuga, voluptatem magni autem repellendus neque dolorum est.', 'unistudio-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $repeater->add_control(
            'member_image',
            [
                'label' => esc_html__('Photo', 'unistudio-core'),
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'type' => Controls_Manager::MEDIA,
            ]
        );

        // LinkedIn
        $repeater->add_control(
            'linkedin_url',
            [
                'label' => esc_html__('LinkedIn Profile', 'unistudio-core'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_html__('https://linkedin.com/in/username', 'unistudio-core'),
                'label_block' => true,
            ]
        );

        // Twitter/X
        $repeater->add_control(
            'twitter_url',
            [
                'label' => esc_html__('Twitter/X Profile', 'unistudio-core'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_html__('https://twitter.com/username', 'unistudio-core'),
                'label_block' => true,
            ]
        );

        // Facebook
        $repeater->add_control(
            'facebook_url',
            [
                'label' => esc_html__('Facebook Profile', 'unistudio-core'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_html__('https://facebook.com/username', 'unistudio-core'),
                'label_block' => true,
            ]
        );

        // Instagram
        $repeater->add_control(
            'instagram_url',
            [
                'label' => esc_html__('Instagram Profile', 'unistudio-core'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_html__('https://instagram.com/username', 'unistudio-core'),
                'label_block' => true,
            ]
        );
      
        $this->add_control(
            'team_members',
            [
                'label' => esc_html__('Team Members', 'unistudio-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => $this->get_repeater_defaults(),
                'title_field' => '{{{ member_name }}}',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_team_settings',
            [
                'label' => esc_html__('Settings', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'team_layout',
            [
                'label' => esc_html__('Pre-defined Layouts', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '1',
                'label_block' => 'yes',
                'options' => [
                    '1' => esc_html__('Layout 01', 'unistudio-core'),
                    '2' => esc_html__('Layout 02', 'unistudio-core'),
                    '3' => esc_html__('Layout 03', 'unistudio-core'),
                    '4' => esc_html__('Layout 04', 'unistudio-core'),
                ],
            ]
        );

        $this->add_control(
            'show_photo',
            [
                'label' => __('Show Photo', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_position',
            [
                'label' => __('Show Position', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_bio',
            [
                'label' => __('Show Bio', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'show_social',
            [
                'label' => __('Show Social Links', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Add Team Style Controls
        $this->register_team_layout_controls();
        $this->register_team_style_controls();

        parent::register_controls();

        $this->remove_control('section_slides');
        $this->remove_control('slides');
        $this->remove_control('section_style_image');
    }

    protected function register_team_style_controls() {
        $this->start_controls_section(
            'section_team_style',
            [
                'label' => esc_html__('Text Styling', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
         
        // Team Member Bio Styling
        $this->add_control(
            'style_bio_heading',
            [
                'label' => esc_html__('Member Bio', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'show_bio' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'style_bio_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .member-bio' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'show_bio' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'style_bio_typography',
                'selector' => '{{WRAPPER}} .member-bio',
                'condition' => [
                    'show_bio' => 'yes',
                ],
            ]
        );
         
        // Team Member Name Styling
        $this->add_control(
            'style_member_name_heading',
            [
                'label' => esc_html__('Member Name', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'style_member_name_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .member-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'style_member_name_typography',
                'selector' => '{{WRAPPER}} .member-name',
            ]
        );
         
        // Team Member Position Styling
        $this->add_control(
            'style_member_position_heading',
            [
                'label' => esc_html__('Member Position', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'show_position' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'style_member_position_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .member-position' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'show_position' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'style_member_position_typography',
                'selector' => '{{WRAPPER}} .member-position',
                'condition' => [
                    'show_position' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        $this->register_team_social_styling_controls();
    }

    protected function register_team_layout_controls() {

        // Layout Controls Section
        $this->start_controls_section(
            'section_team_layout',
            [
                'label' => esc_html__('Layout', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
         
        // Team Member Card
        $this->add_control(
            'team_card_heading',
            [
                'label' => esc_html__('Member Card', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
            ]
        );
        
        $this->add_responsive_control(
            'team_card_width',
            [
                'label' => esc_html__('Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px', 'vh'],
                'range' => [
                    '%' => ['min' => 0, 'max' => 100],
                    'px' => ['min' => 0, 'max' => 1440],
                    'vh' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-slide' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'team_card_min_height',
            [
                'label' => esc_html__('Min Height', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 1000],
                    'vh' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-slide' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_control(
            'team_card_direction',
            [
                'label' => esc_html__('Direction', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'column',
                'options' => [
                    'row' => esc_html__('Row', 'unistudio-core'),
                    'row-reverse' => esc_html__('Row Reverse', 'unistudio-core'),
                    'column' => esc_html__('Column', 'unistudio-core'),
                    'column-reverse' => esc_html__('Column Reverse', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-slide' => 'flex-direction: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'team_card_gap',
            [
                'label' => esc_html__('Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 24,
                    'unit' => 'px',
                ],
                'size_units' => ['px', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 128,
                        'step' => 8,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-slide' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'team_card_vertical_align',
            [
                'label' => esc_html__('Y Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Start', 'unistudio-core'),
                        'icon' => 'eicon-align-start-v',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'unistudio-core'),
                        'icon' => 'eicon-align-center-v',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('End', 'unistudio-core'),
                        'icon' => 'eicon-align-end-v',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-slide' => 'align-items: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'team_card_horizontal_align',
            [
                'label' => esc_html__('X Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Start', 'unistudio-core'),
                        'icon' => 'eicon-align-start-h',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'unistudio-core'),
                        'icon' => 'eicon-align-center-h',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('End', 'unistudio-core'),
                        'icon' => 'eicon-align-end-h',
                    ],
                    'space-between' => [
                        'title' => esc_html__('Space Between', 'unistudio-core'),
                        'icon' => 'eicon-justify-space-between-h',
                    ],
                    'space-around' => [
                        'title' => esc_html__('Space around', 'unistudio-core'),
                        'icon' => 'eicon-justify-space-around-h',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-slide' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'team_card_text_align',
            [
                'label' => __('Text Align', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'unistudio-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'unistudio-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'unistudio-core'),
                        'icon' => 'eicon-text-align-right',
                    ]
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .uc-team-slide' => 'text-align: {{VALUE}};',
                ],
            ]
        );
        
        // Member Info Container
        $this->add_control(
            'member_info_container_heading',
            [
                'label' => esc_html__('Info Container', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->add_responsive_control(
            'member_info_container_width',
            [
                'label' => esc_html__('Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px', 'vh'],
                'range' => [
                    '%' => ['min' => 0, 'max' => 100],
                    'px' => ['min' => 0, 'max' => 1440],
                    'vh' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-info' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_control(
            'member_info_direction',
            [
                'label' => esc_html__('Direction', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'column',
                'options' => [
                    'row' => esc_html__('Row', 'unistudio-core'),
                    'row-reverse' => esc_html__('Row Reverse', 'unistudio-core'),
                    'column' => esc_html__('Column', 'unistudio-core'),
                    'column-reverse' => esc_html__('Column Reverse', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-info' => 'flex-direction: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'member_info_vertical_align',
            [
                'label' => esc_html__('Vertical Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Start', 'unistudio-core'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'unistudio-core'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('End', 'unistudio-core'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-info' => 'align-items: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'member_info_gap',
            [
                'label' => esc_html__('Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 8,
                    'unit' => 'px',
                ],
                'size_units' => ['px', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 128,
                        'step' => 8,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-info' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Member Photo
        $this->add_control(
            'member_photo_heading',
            [
                'label' => esc_html__('Member Photo', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_photo' => 'yes',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'member_photo_size',
            [
                'label' => esc_html__('Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 120,
                    'unit' => 'px',
                ],
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 48,
                        'max' => 256,
                        'step' => 8,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                        'step' => 10,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-photo .image' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_photo' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'member_photo_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '100',
                    'right' => '100', 
                    'bottom' => '100',
                    'left' => '100',
                    'unit' => '%',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-photo .image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_photo' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'member_bio_heading',
            [
                'label' => esc_html__('Bio', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'member_bio_margin',
            [
                'label' => esc_html__('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '16',
                    'right' => '0',
                    'bottom' => '16',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-bio' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function register_team_social_styling_controls() {

        // Layout Controls Section
        $this->start_controls_section(
            'section_social_styling',
            [
                'label' => esc_html__('Social Icons', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'social_icons_container_margin',
            [
                'label' => esc_html__('Container Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '16',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-social' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'social_icons_container_padding',
            [
                'label' => esc_html__('Container Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .member-social' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'social_icons_spacing',
            [
                'label' => esc_html__('Icons Spacing', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 12,
                    'unit' => 'px',
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-social' => 'gap: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'social_icons_align',
            [
                'label' => esc_html__('Icons Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Start', 'unistudio-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'unistudio-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('End', 'unistudio-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .member-social' => 'justify-content: {{VALUE}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        // Individual Social Icons
        $this->add_control(
            'social_icons_style_heading',
            [
                'label' => esc_html__('Social Icons Style', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'social_icon_size',
            [
                'label' => esc_html__('Icon Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 18,
                    'unit' => 'px',
                ],
                'range' => [
                    'px' => [
                        'min' => 12,
                        'max' => 48,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'social_icon_style',
            [
                'label' => esc_html__('Icon Style', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => esc_html__('Default', 'unistudio-core'),
                    'boxed' => esc_html__('Boxed', 'unistudio-core'),
                    'rounded' => esc_html__('Rounded', 'unistudio-core'),
                    'circle' => esc_html__('Circle', 'unistudio-core'),
                ],
                'prefix_class' => 'social-icons-style-',
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'social_icon_padding',
            [
                'label' => esc_html__('Icon Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                    'social_icon_style!' => 'default',
                ],
            ]
        );

        $this->add_control(
            'social_icon_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '3',
                    'right' => '3',
                    'bottom' => '3',
                    'left' => '3',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                    'social_icon_style!' => ['default', 'circle'],
                ],
            ]
        );

        // Social Icons Colors
        $this->start_controls_tabs(
            'social_icons_colors_tabs',
            [
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        // Normal State
        $this->start_controls_tab(
            'social_icons_colors_normal',
            [
                'label' => esc_html__('Normal', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'social_icon_color',
            [
                'label' => esc_html__('Icon Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'social_icon_bg_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#F0ABFC',
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'social_icon_style!' => 'default',
                ],
            ]
        );

        $this->end_controls_tab();

        // Hover State
        $this->start_controls_tab(
            'social_icons_colors_hover',
            [
                'label' => esc_html__('Hover', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'social_icon_hover_color',
            [
                'label' => esc_html__('Icon Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'social_icon_hover_bg_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon:hover' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'social_icon_style!' => 'default',
                ],
            ]
        );

        $this->add_control(
            'social_icon_hover_transition',
            [
                'label' => esc_html__('Hover Transition', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0.3,
                ],
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render() {
        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_team_slider')) {
            return;
        }

        $settings = $this->get_settings_for_display();

        if (empty($settings['team_members'])) {
            return;
        }

        $this->add_render_attribute('wrapper', [
            'class' => 'elementor-widget-' . $this->get_name(),
            'data-widget' => $this->get_name(),
        ]);

        // Build Swiper options
        $swiper_options = $this->get_slider_options($settings);

        $this->render_slider_wrapper($settings, $swiper_options);
    }

    protected function render_slider_wrapper($settings, $swiper_options) {
        ?>
        <div <?php $this->print_render_attribute_string('wrapper'); ?>>
            <div class="swiper" data-uc-swiper="<?php echo esc_attr(implode('; ', $swiper_options)); ?>" <?php echo $this->get_render_attribute_string('slider'); ?>>
                <div class="swiper-wrapper">
                    <?php $this->render_slides($settings); ?>
                </div>
                <?php 
                $this->render_pagination($settings);
                $this->render_navigation($settings);
                ?>
            </div>
        </div>
        <?php
    }

    protected function render_slides($settings) {
        foreach ($settings['team_members'] as $member) {
            ?>
            <div class="swiper-slide">
                <?php $this->render_slide_content($settings, $member); ?>
            </div>
            <?php
        }
    }

    protected function render_slide_content($settings, $member) { ?>
        <div class="uc-team-slide">
            <?php if ($settings['show_photo'] === 'yes' && !empty($member['member_image']['url'])): ?>
                <div class="member-photo">
                    <img class="image" src="<?php echo esc_url($member['member_image']['url']); ?>" 
                            alt="<?php echo esc_attr($member['member_name']); ?>">
                </div>
            <?php endif; ?>
            <div class="team-content-wrap">
                <div class="member-info">
                    <?php if (!empty($member['member_name'])): ?>
                        <h6 class="member-name"><?php echo esc_html($member['member_name']); ?></h6>
                    <?php endif; ?>

                    <?php if ($settings['show_position'] === 'yes' && !empty($member['member_position'])): ?>
                        <div class="member-position">
                            <?php echo esc_html($member['member_position']); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if ($settings['show_bio'] === 'yes' && !empty($member['member_bio'])): ?>
                    <div class="member-bio">
                        <?php echo wp_kses_post($member['member_bio']); ?>
                    </div>
                <?php endif; ?>

                <?php if ($settings['show_social'] === 'yes'): ?>
                    <div class="member-social">
                        <?php
                        $social_platforms = [
                            'linkedin' => $member['linkedin_url'],
                            'twitter' => $member['twitter_url'],
                            'facebook' => $member['facebook_url'],
                            'instagram' => $member['instagram_url']
                        ];
                        
                        foreach ($social_platforms as $platform => $url) {
                            if (!empty($url['url'])) {
                                ?>
                                <a href="<?php echo esc_url($url['url']); ?>"
                                class="social-icon <?php echo esc_attr($platform); ?>"
                                <?php echo $url['is_external'] ? 'target="_blank"' : ''; ?>
                                <?php echo $url['nofollow'] ? 'rel="nofollow"' : ''; ?>>
                                    <i class="unicons unicon-logo-<?php echo esc_attr($platform); ?>"></i>
                                </a>
                                <?php
                            }
                        }
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php
    }

    protected function get_repeater_defaults() {
        return [
            [
                'member_name' => 'John Anderson',
                'member_position' => 'CEO & Founder',
                'member_bio' => 'John has over 15 years of experience in software development and team leadership. He founded our company with a vision to create innovative solutions for modern businesses.',
                'member_image' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'linkedin_url' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'twitter_url' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'facebook_url' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                ],
                'instagram_url' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                ],
            ],
            [
                'member_name' => 'Sarah Martinez',
                'member_position' => 'Lead Designer',
                'member_bio' => 'Sarah brings creativity and user-centered design thinking to every project. Her expertise in UI/UX has shaped our product\'s distinctive visual identity.',
                'member_image' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'member_social' => [
                    [
                        'social_platform' => 'linkedin',
                        'social_link' => [
                            'url' => '#',
                            'is_external' => true,
                            'nofollow' => true,
                        ],
                        'instagram_url' => [
                            'url' => '#',
                            'is_external' => true,
                            'nofollow' => true,
                        ],
                    ],
                ],
            ],
            [
                'member_name' => 'Michael Chen',
                'member_position' => 'Technical Director',
                'member_bio' => 'Michael oversees our technical architecture and ensures we stay at the forefront of technology. His background in cloud computing has been instrumental in our growth.',
                'member_image' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'member_social' => [
                    [
                        'social_platform' => 'linkedin',
                        'social_link' => [
                            'url' => '#',
                            'is_external' => true,
                            'nofollow' => true,
                        ],
                        'twitter_url' => [
                            'url' => '#',
                            'is_external' => true,
                            'nofollow' => true,
                        ],
                    ],
                ],
            ],
        ];
    }
}