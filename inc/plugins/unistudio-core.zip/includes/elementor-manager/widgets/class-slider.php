<?php
namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Slider extends Widget_Base {
    public function get_name() {
        return 'uc_slider';
    }
    
    public function get_title() {
        return __('UC - Swiper Slider', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-nested-carousel';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    } 
    
    public function get_script_depends() {
        return ['swiper', 'uc-data-attr-helper', 'uc-swiper-helper', 'uc-slider'];
    }
    
    public function get_style_depends() {
        return ['swiper', 'uc-slider'];
    }
    
    public function register_widget_scripts() {
        // Register Swiper library
        Asset_Manager::getInstance()->register_widget_script(
            'uc-data-attr-helper',
            'assets/js/widgets/data-attr-helper.min.js',
            ['jquery']
        );
    
        // Register Swiper library
        Asset_Manager::getInstance()->register_widget_script(
            'swiper',
            'assets/js/widgets/swiper-bundle.min.js',
            ['uc-data-attr-helper'],
            '11.2.1'
        );
    
        // Register Swiper helper
        Asset_Manager::getInstance()->register_widget_script(
            'uc-swiper-helper',
            'assets/js/widgets/swiper-helper.min.js',
            ['swiper', 'jquery'],
            UC_VERSION
        );
    
        // Register widget specific script
        Asset_Manager::getInstance()->register_widget_script(
            'uc-slider',
            'assets/js/widgets/slider.min.js',
            ['swiper', 'uc-swiper-helper', 'uc-data-attr-helper']
        );
    }
    
    public function register_widget_styles() {
        // Register Swiper styles
        Asset_Manager::getInstance()->register_widget_style(
            'swiper',
            'assets/css/widgets/swiper-bundle.min.css',
            [],
            '11.2.1'
        );
    
        // Register widget specific styles
        Asset_Manager::getInstance()->register_widget_style(
            'uc-slider',
            'assets/css/widgets/slider.min.css',
            ['swiper']
        );
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'section_slides',
            [
                'label' => esc_html__('Slides', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
    
        $repeater = new \Elementor\Repeater();
    
        $repeater->add_control(
            'slide_type',
            [
                'label' => esc_html__('Content Type', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'image',
                'options' => [
                    'image' => esc_html__('Image', 'unistudio-core'),
                    'template' => esc_html__('Template', 'unistudio-core'),
                ],
            ]
        );
    
        $repeater->add_control(
            'image',
            [
                'label' => esc_html__('Image', 'unistudio-core'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'slide_type' => 'image',
                ],
            ]
        );
    
        $repeater->add_control(
            'template_id',
            [
                'label' => esc_html__('Choose Template', 'unistudio-core'),
                'type' => Controls_Manager::SELECT2,
                'options' => $this->get_elementor_templates(),
                'condition' => [
                    'slide_type' => 'template',
                ],
            ]
        );
    
        $repeater->add_control(
            'link',
            [
                'label' => esc_html__('Link', 'unistudio-core'),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_html__('https://your-link.com', 'unistudio-core'),
                'condition' => [
                    'slide_type' => 'image',
                ],
            ]
        );
    
        $this->add_control(
            'slides',
            [
                'label' => esc_html__('Slides', 'unistudio-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => $this->get_repeater_defaults(),
                'title_field' => '{{{ slide_type }}}',
            ]
        );
    
        $this->end_controls_section();
    
        // Slider Options Section
        $this->start_controls_section(
            'section_slider_options',
            [
                'label' => esc_html__('Slider Options', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'active_index',
            [
                'label' => esc_html__('Active', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 0,
            ]
        );

        $this->add_control(
            'slides_per_view',
            [
                'label' => esc_html__('Slides Per View', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '3',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6',
                    'auto' => esc_html__('Auto', 'unistudio-core'),
                ],
            ]
        );

        $this->add_control(
            'space_between',
            [
                'label' => esc_html__('Space Between', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 16,
            ]
        );
    
        $this->add_control(
            'centered_slides',
            [
                'label' => esc_html__('Centered Slides', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => '',
                'label_on' => esc_html__('Yes', 'unistudio-core'),
                'label_off' => esc_html__('No', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'center_bounds',
            [
                'label' => esc_html__('Center Bounds', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => '',
                'label_on' => esc_html__('Yes', 'unistudio-core'),
                'label_off' => esc_html__('No', 'unistudio-core'),
                'condition' => [
                    'centered_slides' => 'yes',
                ],
            ]
        );
    
        $this->add_control(
            'loop',
            [
                'label' => esc_html__('Infinite Loop', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'label_on' => esc_html__('Yes', 'unistudio-core'),
                'label_off' => esc_html__('No', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'autoplay',
            [
                'label' => esc_html__('Autoplay', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => '',
                'label_on' => esc_html__('Yes', 'unistudio-core'),
                'label_off' => esc_html__('No', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'autoplay_delay',
            [
                'label' => esc_html__('Autoplay Delay', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 3000,
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );
    
        $this->add_control(
            'pause_on_hover',
            [
                'label' => esc_html__('Pause on Hover', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );
    
        $this->add_control(
            'navigation',
            [
                'label' => esc_html__('Navigation', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
    
        $this->add_control(
            'pagination',
            [
                'label' => esc_html__('Pagination', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'bullets',
                'options' => [
                    'none' => esc_html__('None', 'unistudio-core'),
                    'bullets' => esc_html__('Bullets', 'unistudio-core'),
                    'fraction' => esc_html__('Fraction', 'unistudio-core'),
                    'progressbar' => esc_html__('Progress', 'unistudio-core'),
                ],
            ]
        );
    
        $this->add_control(
            'clickable',
            [
                'label' => esc_html__('Clickable Pagination', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [
                    'pagination' => 'bullets',
                ],
            ]
        );
    
        $this->end_controls_section();

        // Slider effects section
        $this->start_controls_section(
            'section_slider_effects',
            [
                'label' => esc_html__('Slider Effects', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'slider_effect',
            [
                'label' => esc_html__('Choose Effect', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'slide',
                'options' => [
                    'slide' => esc_html__('Slide', 'unistudio-core'),
                    'fade' => esc_html__('Fade', 'unistudio-core'),
                    'cube' => esc_html__('Cube', 'unistudio-core'),
                    'coverflow' => esc_html__('Coverflow', 'unistudio-core'),
                    'flip' => esc_html__('Flip', 'unistudio-core'),
                    'cards' => esc_html__('Cards', 'unistudio-core'),
                    'creative' => esc_html__('Creative', 'unistudio-core'),
                ],
            ]
        );

        // Effect specific controls
        $this->add_control(
            'fade_crossfade',
            [
                'label' => esc_html__('Crossfade', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [
                    'slider_effect' => 'fade',
                ],
            ]
        );

        $this->add_control(
            'flip_rotationLimit',
            [
                'label' => esc_html__('Rotation Limit', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [
                    'slider_effect' => 'flip',
                ],
            ]
        );

        $this->add_control(
            'flip_slideShadows',
            [
                'label' => esc_html__('Slide Shadows', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [
                    'slider_effect' => 'flip',
                ],
            ]
        );

        $this->add_control(
            'coverflow_rotate',
            [
                'label' => esc_html__('Rotate', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 50,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 360,
                    ],
                ],
                'condition' => [
                    'slider_effect' => 'coverflow',
                ],
            ]
        );

        $this->add_control(
            'coverflow_scale',
            [
                'label' => esc_html__('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 1,
                ],
                'range' => [
                    'px' => [
                        'min' => 0.3,
                        'max' => 1,
                        'step' => 0.1,
                    ],
                ],
                'condition' => [
                    'slider_effect' => 'coverflow',
                ],
            ]
        );

        $this->add_control(
            'coverflow_depth',
            [
                'label' => esc_html__('Depth', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 100,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1000,
                    ],
                ],
                'condition' => [
                    'slider_effect' => 'coverflow',
                ],
            ]
        );

        $this->add_control(
            'coverflow_stretch',
            [
                'label' => esc_html__('Stretch', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'condition' => [
                    'slider_effect' => 'coverflow',
                ],
            ]
        );

        $this->add_control(
            'coverflow_modifier',
            [
                'label' => esc_html__('Modifier', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 1,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 10,
                    ],
                ],
                'condition' => [
                    'slider_effect' => 'coverflow',
                ],
            ]
        );

        $this->add_control(
            'coverflow_slideShadows',
            [
                'label' => esc_html__('Slide Shadows', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [
                    'slider_effect' => 'coverflow',
                ],
            ]
        );

        $this->add_control(
            'cube_shadow',
            [
                'label' => esc_html__('Shadow', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [
                    'slider_effect' => 'cube',
                ],
            ]
        );

        $this->add_control(
            'cube_shadowOffset',
            [
                'label' => esc_html__('Shadow Offset', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 20,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'condition' => [
                    'slider_effect' => 'cube',
                ],
            ]
        );

        $this->add_control(
            'cube_shadowScale',
            [
                'label' => esc_html__('Shadow Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0.94,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1,
                        'step' => 0.1,
                    ],
                ],
                'condition' => [
                    'slider_effect' => 'cube',
                ],
            ]
        );

        $this->add_control(
            'cube_slideShadows',
            [
                'label' => esc_html__('Slide Shadows', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [
                    'slider_effect' => 'cube',
                ],
            ]
        );



        $this->add_control(
            'cards_perSlideOffset',
            [
                'label' => esc_html__('Per Slide Offset', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 8,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 1,
                    ],
                ],
                'condition' => [
                    'slider_effect' => 'cards',
                ],
            ]
        );

        $this->add_control(
            'cards_perSlideRotate',
            [
                'label' => esc_html__('Per Slide Rotate', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 2,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 1,
                    ],
                ],
                'condition' => [
                    'slider_effect' => 'cards',
                ],
            ]
        );

        $this->add_control(
            'cards_slideShadows',
            [
                'label' => esc_html__('Slide Shadows', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [
                    'slider_effect' => 'cards',
                ],
            ]
        );

        $this->add_control(
            'creative_effect_perspective',
            [
                'label' => esc_html__('3D Perspective', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        $this->add_control(
            'creative_effect_limit_progress',
            [
                'label' => esc_html__('Limit Progress', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 1,
                'max' => 5,
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        $this->add_control(
            'creative_effect_multiply',
            [
                'label' => esc_html__('Progress Multiplier', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 0.1,
                'max' => 5,
                'step' => 0.1,
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        $this->add_control(
            'creative_effect_shadow',
            [
                'label' => esc_html__('Shadow', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        $this->add_control(
            'creative_effect_shadow_progress',
            [
                'label' => esc_html__('Shadow Per Progress', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => '',
                'condition' => [
                    'slider_effect' => 'creative',
                    'creative_effect_shadow' => 'yes',
                ],
            ]
        );
        
        // Previous Slide Transform
        $this->add_control(
            'creative_prev_heading',
            [
                'label' => esc_html__('Previous Slide', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        $this->add_control(
            'creative_prev_translate',
            [
                'label' => esc_html__('Translate', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '0, -100%, 0',
                'description' => esc_html__('X, Y, Z values (e.g., "0, -100%, 0")', 'unistudio-core'),
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        $this->add_control(
            'creative_prev_rotate',
            [
                'label' => esc_html__('Rotate', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '0, 0, 0',
                'description' => esc_html__('X, Y, Z values in degrees (e.g., "0, 0, 45")', 'unistudio-core'),
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        $this->add_control(
            'creative_prev_scale',
            [
                'label' => esc_html__('Scale', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 2,
                'step' => 0.1,
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        $this->add_control(
            'creative_prev_opacity',
            [
                'label' => esc_html__('Opacity', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 1,
                'step' => 0.1,
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );

        $this->add_control(
            'creative_prev_origin',
            [
                'label' => esc_html__('Previous Origin', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    'left top' => esc_html__('Left Top', 'unistudio-core'),
                    'left center' => esc_html__('Left Center', 'unistudio-core'),
                    'left bottom' => esc_html__('Left Bottom', 'unistudio-core'),
                    'center top' => esc_html__('Center Top', 'unistudio-core'),
                    '' => esc_html__('Center Center', 'unistudio-core'),
                    'center bottom' => esc_html__('Center Bottom', 'unistudio-core'),
                    'right top' => esc_html__('Right Top', 'unistudio-core'),
                    'right center' => esc_html__('Right Center', 'unistudio-core'),
                    'right bottom' => esc_html__('Right Bottom', 'unistudio-core'),
                ],
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        // Next Slide Transform
        $this->add_control(
            'creative_next_heading',
            [
                'label' => esc_html__('Next Slide', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        $this->add_control(
            'creative_next_translate',
            [
                'label' => esc_html__('Translate', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '0, 100%, 0',
                'description' => esc_html__('X, Y, Z values (e.g., "0, 100%, 0")', 'unistudio-core'),
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        $this->add_control(
            'creative_next_rotate',
            [
                'label' => esc_html__('Rotate', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '0, 0, 0',
                'description' => esc_html__('X, Y, Z values in degrees (e.g., "0, 0, -45")', 'unistudio-core'),
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        $this->add_control(
            'creative_next_scale',
            [
                'label' => esc_html__('Scale', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 2,
                'step' => 0.1,
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        $this->add_control(
            'creative_next_opacity',
            [
                'label' => esc_html__('Opacity', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 1,
                'step' => 0.1,
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );
        
        $this->add_control(
            'creative_next_origin',
            [
                'label' => esc_html__('Next Origin', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    'left top' => esc_html__('Left Top', 'unistudio-core'),
                    'left center' => esc_html__('Left Center', 'unistudio-core'),
                    'left bottom' => esc_html__('Left Bottom', 'unistudio-core'),
                    'center top' => esc_html__('Center Top', 'unistudio-core'),
                    '' => esc_html__('Center Center', 'unistudio-core'),
                    'center bottom' => esc_html__('Center Bottom', 'unistudio-core'),
                    'right top' => esc_html__('Right Top', 'unistudio-core'),
                    'right center' => esc_html__('Right Center', 'unistudio-core'),
                    'right bottom' => esc_html__('Right Bottom', 'unistudio-core'),
                ],
                'condition' => [
                    'slider_effect' => 'creative',
                ],
            ]
        );

        $this->end_controls_section();

        // Breakpoints Section
        $this->start_controls_section(
            'section_breakpoints_options',
            [
                'label' => esc_html__('Responsive Breakpoints', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        // Add breakpoint controls
        $breakpoints = [
            's' => esc_html__('Small (640px)', 'unistudio-core'),
            'm' => esc_html__('Medium (960px)', 'unistudio-core'),
            'l' => esc_html__('Large (1200px)', 'unistudio-core'),
            'xl' => esc_html__('Extra Large (1600px)', 'unistudio-core'),
        ];

        foreach ($breakpoints as $breakpoint => $label) {
            $this->add_control(
                'breakpoint_' . $breakpoint . '_heading',
                [
                    'label' => $label,
                    'type' => Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                $breakpoint . '_slides_per_view',
                [
                    'label' => esc_html__('Slides Per View', 'unistudio-core'),
                    'type' => Controls_Manager::SELECT,
                    'default' => '',
                    'options' => [
                        '' => esc_html__('Default', 'unistudio-core'),
                        '1' => '1',
                        '2' => '2',
                        '3' => '3',
                        '4' => '4',
                        '5' => '5',
                        '6' => '6',
                        'auto' => esc_html__('Auto', 'unistudio-core'),
                    ],
                ]
            );

            $this->add_control(
                $breakpoint . '_space_between',
                [
                    'label' => esc_html__('Space Between', 'unistudio-core'),
                    'type' => Controls_Manager::NUMBER,
                    'placeholder' => esc_html__('Default', 'unistudio-core'),
                ]
            );

            $this->add_control(
                $breakpoint . '_center',
                [
                    'label' => esc_html__('Center Slides', 'unistudio-core'),
                    'type' => Controls_Manager::SELECT,
                    'default' => '',
                    'options' => [
                        '' => esc_html__('Default', 'unistudio-core'),
                        'true' => esc_html__('Yes', 'unistudio-core'),
                        'false' => esc_html__('No', 'unistudio-core'),
                    ],
                ]
            );
        }
    
        $this->end_controls_section();

        $this->register_style_controls();
    }

    protected function register_style_controls() {
        // Slider Style Section
        $this->start_controls_section(
            'section_style_slider',
            [
                'label' => esc_html__('Item Slide', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
    
        $this->add_responsive_control(
            'slider_width',
            [
                'label' => esc_html__('Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'vh' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'slider_height',
            [
                'label' => esc_html__('Height', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 1000,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'vh' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_control(
            'slides_background_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#f5f5f5',
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        // Padding
        $this->add_responsive_control(
            'slides_padding',
            [
                'label' => __('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '32',
                    'right' => '32',
                    'bottom' => '32',
                    'left' => '32',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide > *' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'slides_border',
                'selector' => '{{WRAPPER}} .swiper-slide',
            ]
        );
    
        $this->add_responsive_control(
            'slides_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'slides_box_shadow',
                'selector' => '{{WRAPPER}} .swiper-slide',
            ]
        );
    
        $this->end_controls_section();
    
        // Navigation Style Section
        $this->start_controls_section(
            'section_style_navigation',
            [
                'label' => esc_html__('Navigation', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'navigation' => 'yes',
                ],
            ]
        );
        
        $this->add_control(
            'navigation_prev_icon',
            [
                'label' => esc_html__('Previous Icon', 'unistudio-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'unicon-chevron-left',
                    'library' => 'unicons',
                ],
                'recommended' => [
                    'unicons' => [
                        'chevron-left',
                        'arrow-left',
                        'caret-left',
                        'arrow-circle-left',
                        'arrow-square-left',
                    ],
                ],
            ]
        );
        
        $this->add_control(
            'navigation_next_icon',
            [
                'label' => esc_html__('Next Icon', 'unistudio-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'unicon-chevron-right',
                    'library' => 'unicons',
                ],
                'recommended' => [
                    'unicons' => [
                        'chevron-right',
                        'arrow-right',
                        'caret-right',
                        'arrow-circle-right',
                        'arrow-square-right',
                    ],
                ],
            ]
        );
    
        $this->add_control(
            'arrows_size',
            [
                'label' => esc_html__('Icon Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 24,
                    'unit' => 'px',
                ],
                'range' => [
                    'px' => [
                        'min' => 16,
                        'max' => 128,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-nav' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'navigation_icon_width',
            [
                'label' => esc_html__('Icon Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 40,
                    'unit' => 'px',
                ],
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 16,
                        'max' => 128,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 10,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-nav' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'navigation_icon_height',
            [
                'label' => esc_html__('Icon Height', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 40,
                    'unit' => 'px',
                ],
                'size_units' => ['px', 'em', '%'],
                'range' => [
                    'px' => [
                        'min' => 16,
                        'max' => 128,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 10,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-nav' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'icon_border',
                'selector' => '{{WRAPPER}} .swiper-nav',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'icon_border_radius',
            [
                'label' => __('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '100',
                    'right' => '100',
                    'bottom' => '100',
                    'left' => '100',
                    'unit' => '%',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-nav' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Icon Shadow
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'icon_shadow',
                'selector' => '{{WRAPPER}} .swiper-nav',
            ]
        );
    
        $this->start_controls_tabs('arrows_colors');
    
        $this->start_controls_tab(
            'arrows_normal',
            [
                'label' => esc_html__('Normal', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'arrows_color',
            [
                'label' => esc_html__('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .swiper-nav' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_control(
            'arrows_background_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => 'var(--color-primary)',
                'selectors' => [
                    '{{WRAPPER}} .swiper-nav' => 'background-color: {{VALUE}};',
                ],
            ]
        );
    
        $this->end_controls_tab();
    
        $this->start_controls_tab(
            'arrows_hover',
            [
                'label' => esc_html__('Hover', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'arrows_hover_color',
            [
                'label' => esc_html__('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .swiper-nav:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_control(
            'arrows_hover_background_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .swiper-nav:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );
    
        $this->end_controls_tab();
    
        $this->end_controls_tabs();
    
        $this->end_controls_section();
    
        // Pagination Style Section
        $this->start_controls_section(
            'section_style_pagination',
            [
                'label' => esc_html__('Pagination', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'pagination!' => 'none',
                ],
            ]
        );
    
        $this->add_control(
            'pagination_size',
            [
                'label' => esc_html__('Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 8,
                    'unit' => 'px',
                ],
                'range' => [
                    'px' => [
                        'min' => 4,
                        'max' => 24,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper .swiper-pagination-bullet, .swiper-pagination-bullet' => 'width: {{SIZE}}{{UNIT}} !important; height: {{SIZE}}{{UNIT}} !important; border-radius: {{SIZE}}{{UNIT}} !important;',
                ],
                'condition' => [
                    'pagination' => 'bullets',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'pagination_spacing',
            [
                'label' => esc_html__('Spacing', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 8,
                    'unit' => 'px',
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination' => 'gap: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'pagination' => 'bullets',
                ],
            ]
        );
    
        $this->start_controls_tabs('pagination_colors');
    
        $this->start_controls_tab(
            'pagination_normal',
            [
                'label' => esc_html__('Normal', 'unistudio-core'),
                'condition' => [
                    'pagination' => 'bullets',
                ],
            ]
        );
    
        $this->add_control(
            'pagination_color',
            [
                'label' => esc_html__('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#d5d5d5',
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'pagination' => 'bullets',
                ],
            ]
        );
    
        $this->end_controls_tab();
    
        $this->start_controls_tab(
            'pagination_active',
            [
                'label' => esc_html__('Active', 'unistudio-core'),
                'condition' => [
                    'pagination' => 'bullets',
                ],
            ]
        );
    
        $this->add_control(
            'pagination_active_color',
            [
                'label' => esc_html__('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => 'var(--color-primary)',
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-bullet-active' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'pagination' => 'bullets',
                ],
            ]
        );
    
        $this->end_controls_tab();
    
        $this->end_controls_tabs();
    
        // Progressbar Style
        $this->add_control(
            'progressbar_heading',
            [
                'label' => esc_html__('Progressbar', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'pagination' => 'progressbar',
                ],
            ]
        );
    
        $this->add_control(
            'progressbar_height',
            [
                'label' => esc_html__('Height', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 10,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-progressbar' => 'height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'pagination' => 'progressbar',
                ],
            ]
        );
    
        $this->add_control(
            'progressbar_color',
            [
                'label' => esc_html__('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-progressbar-fill' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'pagination' => 'progressbar',
                ],
            ]
        );
    
        $this->add_control(
            'progressbar_background_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-progressbar' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'pagination' => 'progressbar',
                ],
            ]
        );
    
        // Fraction Style
        $this->add_control(
            'fraction_heading',
            [
                'label' => esc_html__('Fraction', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'pagination' => 'fraction',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'fraction_typography',
                'selector' => '{{WRAPPER}} .swiper-pagination-fraction',
                'condition' => [
                    'pagination' => 'fraction',
                ],
            ]
        );
    
        $this->add_control(
            'fraction_color',
            [
                'label' => esc_html__('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .swiper-pagination-fraction' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'pagination' => 'fraction',
                ],
            ]
        );
    
        $this->end_controls_section();
    
        // Image Style Section
        $this->start_controls_section(
            'section_style_image',
            [
                'label' => esc_html__('Image', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
    
        $this->add_control(
            'image_fit',
            [
                'label' => esc_html__('Object Fit', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'cover',
                'options' => [
                    'cover' => esc_html__('Cover', 'unistudio-core'),
                    'contain' => esc_html__('Contain', 'unistudio-core'),
                    'fill' => esc_html__('Fill', 'unistudio-core'),
                    'none' => esc_html__('None', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide img' => 'width: 100%; height: 100%; object-fit: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_control(
            'image_position',
            [
                'label' => esc_html__('Object Position', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'center center',
                'options' => [
                    'center center' => esc_html__('Center Center', 'unistudio-core'),
                    'center left' => esc_html__('Center Left', 'unistudio-core'),
                    'center right' => esc_html__('Center Right', 'unistudio-core'),
                    'top center' => esc_html__('Top Center', 'unistudio-core'),
                    'top left' => esc_html__('Top Left', 'unistudio-core'),
                    'top right' => esc_html__('Top Right', 'unistudio-core'),
                    'bottom center' => esc_html__('Bottom Center', 'unistudio-core'),
                    'bottom left' => esc_html__('Bottom Left', 'unistudio-core'),
                    'bottom right' => esc_html__('Bottom Right', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide img' => 'object-position: {{VALUE}};',
                ],
                'condition' => [
                    'image_fit!' => 'fill',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'selector' => '{{WRAPPER}} .swiper-slide img',
            ]
        );
    
        $this->add_responsive_control(
            'image_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .swiper-slide img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->end_controls_section();
    }

    protected function render() {

        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_slider')) {
            return;
        }

        $settings = $this->get_settings_for_display();
        if (empty($settings['slides'])) {
            return;
        }

        $this->add_render_attribute('wrapper', [
            'class' => 'elementor-widget-' . $this->get_name(),
            'data-widget' => $this->get_name(),
        ]);

        $swiper_options = $this->get_slider_options($settings);
        $this->add_breakpoint_attributes($settings);

        $this->render_slider_wrapper($settings, $swiper_options);
    }

    protected function get_slider_options($settings) {
        $swiper_options = [];
        
        // Basic options
        if (isset($settings['active_index'])) {
            $swiper_options[] = 'active: ' . $settings['active_index'];
        }
        if (isset($settings['slides_per_view'])) {
            $swiper_options[] = 'items: ' . $settings['slides_per_view'];
        }
        if (isset($settings['space_between'])) {
            $swiper_options[] = 'gap: ' . $settings['space_between'];
        }
        
        // Optional features
        if (isset($settings['centered_slides']) && $settings['centered_slides'] === 'yes') {
            $swiper_options[] = 'center: true';
        }
        if (isset($settings['center_bounds']) && $settings['center_bounds'] === 'yes') {
            $swiper_options[] = 'center-bounds: true';
        }
        if (isset($settings['loop']) && $settings['loop'] === 'yes') {
            $swiper_options[] = 'loop: true';
        }
        
        // Autoplay options
        if (isset($settings['autoplay']) && $settings['autoplay'] === 'yes') {
            $swiper_options[] = 'autoplay: ' . $settings['autoplay_delay'];
            if (isset($settings['pause_on_hover']) && $settings['pause_on_hover'] === 'yes') {
                $swiper_options[] = 'pause-mouse: true';
            }
        }
    
        // Navigation
        if (isset($settings['navigation']) && $settings['navigation'] === 'yes') {
            $swiper_options[] = 'next: .swiper-button-next-' . $this->get_id();
            $swiper_options[] = 'prev: .swiper-button-prev-' . $this->get_id();
        }
    
        // Pagination
        if (isset($settings['pagination']) && $settings['pagination'] !== 'none') {
            $swiper_options[] = 'dots: .swiper-pagination-' . $this->get_id();
            $swiper_options[] = 'dots-type: ' . $settings['pagination'];
            if ($settings['pagination'] === 'bullets' && isset($settings['clickable']) && $settings['clickable'] === 'yes') {
                $swiper_options[] = 'dots-click: true';
            }
        }

        // Add effect
        if (!empty($settings['slider_effect']) && $settings['slider_effect'] !== 'slide') {
            $swiper_options[] = 'effect: ' . $settings['slider_effect'];

            // Effect specific options
            switch ($settings['slider_effect']) {
                case 'fade':
                    if ($settings['fade_crossfade'] === 'yes') {
                        $swiper_options[] = 'fade: true';
                    } else {
                        $swiper_options[] = 'fade: false';
                    }
                    break;

                case 'coverflow':
                    if (!empty($settings['coverflow_rotate'])) {
                        $swiper_options[] = 'coverflow-rotate: ' . $settings['coverflow_rotate']['size'];
                    }
                    if (!empty($settings['coverflow_scale'])) {
                        $swiper_options[] = 'coverflow-scale: ' . $settings['coverflow_scale']['size'];
                    }
                    if (!empty($settings['coverflow_depth'])) {
                        $swiper_options[] = 'coverflow-depth: ' . $settings['coverflow_depth']['size'];
                    }
                    if (!empty($settings['coverflow_stretch'])) {
                        $swiper_options[] = 'coverflow-stretch: ' . $settings['coverflow_stretch']['size'];
                    }
                    if (!empty($settings['coverflow_modifier'])) {
                        $swiper_options[] = 'coverflow-modifier: ' . $settings['coverflow_modifier']['size'];
                    }
                    if ($settings['coverflow_slideShadows'] === 'yes') {
                        $swiper_options[] = 'coverflow-slide-shadows: true';
                    }
                    break;

                case 'flip':
                    if ($settings['flip_rotationLimit'] === 'yes') {
                        $swiper_options[] = 'flip-rotation-limit: true';
                    }
                    if ($settings['flip_slideShadows'] === 'yes') {
                        $swiper_options[] = 'flip-slide-shadows: true';
                    }
                    break;

                case 'cube':
                    if ($settings['cube_shadow'] === 'yes') {
                        $swiper_options[] = 'cube-shadow: true';
                    } else {
                        $swiper_options[] = 'cube-shadow: false';
                    }
                    if (!empty($settings['cube_shadowOffset'])) {
                        $swiper_options[] = 'cube-shadow-offset: ' . $settings['cube_shadowOffset']['size'];
                    }
                    if (!empty($settings['cube_shadowScale'])) {
                        $swiper_options[] = 'cube-shadow-scale: ' . $settings['cube_shadowScale']['size'];
                    }
                    if ($settings['cube_slideShadows'] === 'yes') {
                        $swiper_options[] = 'coverflow-slide-shadows: true';
                    }
                    break;

                case 'cards':
                    if (!empty($settings['cards_perSlideOffset'])) {
                        $swiper_options[] = 'cards-slide-offset: ' . $settings['cards_perSlideOffset']['size'];
                    }
                    if (!empty($settings['cards_perSlideRotate'])) {
                        $swiper_options[] = 'cards-slide-rotate: ' . $settings['cards_perSlideRotate']['size'];
                    }
                    if ($settings['cards_slideShadows'] === 'yes') {
                        $swiper_options[] = 'cards-slide-shadows: true';
                    }
                    break;

                case 'creative':
                    if ($settings['slider_effect'] === 'creative') {
                        // Basic options

                        if (!empty($settings['creative_effect_limit_progress'])) {
                            $swiper_options[] = 'creative-limit: ' . $settings['creative_effect_limit_progress'];
                        }

                        if (!empty($settings['creative_effect_perspective'])) {
                            $swiper_options[] = 'creative-perspective: ' . ($settings['creative_effect_perspective'] === 'yes' ? 'true' : 'false');
                        }

                        if (!empty($settings['creative_effect_multiply'])) {
                            $swiper_options[] = 'creative-multiplier: ' . $settings['creative_effect_multiply'];
                        }

                        if (!empty($settings['creative_effect_shadow_progress'])) {
                            $swiper_options[] = 'creative-shadow-progress: ' . ($settings['creative_effect_shadow_progress'] === 'yes' ? 'true' : 'false');
                        }

                        // Next slide transform
                        if (!empty($settings['creative_next_translate'])) {
                            $swiper_options[] = 'creative-next-translate: [' . $settings['creative_next_translate'] . ']';
                        }

                        if (!empty($settings['creative_next_rotate'])) {
                            $swiper_options[] = 'creative-next-rotate: [' . $settings['creative_next_rotate'] . ']';
                        }
                            
                        if (!empty($settings['creative_next_opacity'])) {
                            $swiper_options[] = 'creative-next-opacity: ' . $settings['creative_next_opacity'];
                        }
                        
                        if (!empty($settings['creative_next_scale'])) {
                            $swiper_options[] = 'creative-next-scale: ' . $settings['creative_next_scale'];
                        }
                        
                        if (!empty($settings['creative_effect_shadow'])) {
                            $swiper_options[] = 'creative-next-shadow: ' . ($settings['creative_effect_shadow'] === 'yes' ? 'true' : 'false');
                        }

                        if ($settings['creative_next_origin'] !== '') {
                            $swiper_options[] = 'creative-next-origin: ' . $settings['creative_next_origin'];
                        }
                    
                        // Previous slide transform
                        if (!empty($settings['creative_prev_translate'])) {
                            $swiper_options[] = 'creative-prev-translate: [' . $settings['creative_prev_translate'] . ']';
                        }

                        if (!empty($settings['creative_prev_rotate'])) {
                            $swiper_options[] = 'creative-prev-rotate: [' . $settings['creative_prev_rotate'] . ']';
                        }

                        if (!empty($settings['creative_prev_opacity'])) {
                            $swiper_options[] = 'creative-prev-opacity: ' . $settings['creative_prev_opacity'];
                        }

                        if (!empty($settings['creative_prev_scale'])) {
                            $swiper_options[] = 'creative-prev-scale: ' . $settings['creative_prev_scale'];
                        }

                        if (!empty($settings['creative_effect_shadow'])) {
                            $swiper_options[] = 'creative-prev-shadow: ' . ($settings['creative_effect_shadow'] === 'yes' ? 'true' : 'false');
                        }

                        if ($settings['creative_prev_origin'] !== '') {
                            $swiper_options[] = 'creative-prev-origin: ' . $settings['creative_prev_origin'];
                        }
                    }  
                    break;
            }
        }
    
        return $swiper_options;
    }

    protected function add_breakpoint_attributes($settings) {
        $breakpoints = ['s', 'm', 'l', 'xl'];
        
        foreach ($breakpoints as $breakpoint) {
            $breakpoint_options = [];
    
            if (!empty($settings[$breakpoint . '_slides_per_view'])) {
                $breakpoint_options[] = 'items: ' . $settings[$breakpoint . '_slides_per_view'];
            }
    
            if (isset($settings[$breakpoint . '_space_between']) && $settings[$breakpoint . '_space_between'] !== '') {
                $breakpoint_options[] = 'gap: ' . $settings[$breakpoint . '_space_between'];
            }
    
            if (!empty($settings[$breakpoint . '_center'])) {
                $breakpoint_options[] = 'center: ' . $settings[$breakpoint . '_center'];
            }
    
            if (!empty($breakpoint_options)) {
                $this->add_render_attribute(
                    'slider',
                    'data-uc-swiper-' . $breakpoint,
                    implode('; ', $breakpoint_options)
                );
            }
        }
    }

    protected function render_slider_wrapper($settings, $swiper_options) {
        ?>
        <div <?php $this->print_render_attribute_string('wrapper'); ?>>
            <div class="swiper" data-uc-swiper="<?php echo esc_attr(implode('; ', $swiper_options)); ?>" <?php echo $this->get_render_attribute_string('slider'); ?>>
                <div class="swiper-wrapper">
                    <?php $this->render_slides($settings); ?>
                </div>
                <?php 
                $this->render_pagination($settings);
                $this->render_navigation($settings);
                ?>
            </div>
        </div>
        <?php
    }
    
    protected function render_slides($settings) {
        foreach ($settings['slides'] as $slide) {
            ?>
            <div class="swiper-slide">
                <?php $this->render_slide_content($settings, $slide); ?>
            </div>
            <?php
        }
    }
    
    protected function render_slide_content($settings, $slide) {
        if ($slide['slide_type'] === 'image') {
            $this->render_image_slide($slide);
        } else {
            $this->render_template_slide($slide);
        }
    }
    
    protected function render_image_slide($slide) {
        if (!empty($slide['link']['url'])) {
            ?>
            <a href="<?php echo esc_url($slide['link']['url']); ?>"
               <?php echo $slide['link']['is_external'] ? ' target="_blank"' : ''; ?>
               <?php echo $slide['link']['nofollow'] ? ' rel="nofollow"' : ''; ?>>
            <?php
        }
    
        echo \Elementor\Group_Control_Image_Size::get_attachment_image_html($slide);
    
        if (!empty($slide['link']['url'])) {
            echo '</a>';
        }
    }
    
    protected function render_template_slide($slide) {
        if (!empty($slide['template_id'])) {
            echo \Elementor\Plugin::$instance->frontend->get_builder_content($slide['template_id'], true);
        }
    }
    
    protected function render_navigation($settings) {
        if (!isset($settings['navigation']) || $settings['navigation'] !== 'yes') {
            return;
        }
        ?>
        <div class="swiper-nav swiper-button-prev swiper-button-prev-<?php echo esc_attr($this->get_id()); ?>">
            <?php \Elementor\Icons_Manager::render_icon($settings['navigation_prev_icon'], ['aria-hidden' => 'true']); ?>
        </div>
        <div class="swiper-nav swiper-button-next swiper-button-next-<?php echo esc_attr($this->get_id()); ?>">
            <?php \Elementor\Icons_Manager::render_icon($settings['navigation_next_icon'], ['aria-hidden' => 'true']); ?>
        </div>
        <?php
    }
    
    protected function render_pagination($settings) {
        if (!isset($settings['pagination']) || $settings['pagination'] === 'none') {
            return;
        }
        ?>
        <div class="swiper-pagination swiper-pagination-<?php echo esc_attr($this->get_id()); ?>"></div>
        <?php
    }

    private function get_elementor_templates() {
        $templates = [];
    
        $args = [
            'post_type' => 'elementor_library',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
        ];
    
        $query = new \WP_Query($args);
    
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $templates[get_the_ID()] = get_the_title();
            }
        }
    
        wp_reset_postdata();
    
        return $templates;
    }

    protected function get_repeater_defaults() {
        return [
            [
                'slide_type' => 'image',
                'image' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ],
            [
                'slide_type' => 'image',
                'image' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ],
            [
                'slide_type' => 'image',
                'image' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ],
        ];
    }
}