<?php

namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Accordion extends Widget_Base {
    public function get_name() {
        return 'uc_accordion';
    }
    
    public function get_title() {
        return __('UC - Accordion', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-accordion';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    } 
    
    public function get_script_depends() {
        return ['uc-accordion'];
    }

    public function get_style_depends() {
        return ['uc-accordion'];
    }

    public function register_widget_scripts() {
        Asset_Manager::getInstance()->register_widget_script(
            'uc-accordion',
            'assets/js/widgets/accordion.min.js',
            ['uc-core']
        );
    }

    public function register_widget_styles() {
        Asset_Manager::getInstance()->register_widget_style(
            'uc-accordion',
            'assets/css/widgets/accordion.min.css',
            ['uc-core']
        );
    }
    
    protected function register_controls() {

        $this->start_controls_section(
            'accordion_content_section',
            [
                'label' => esc_html__('Content', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'accordion_list',
            [
                'label' => esc_html__('Accordion Items', 'unistudio-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'tab_title',
                        'label' => esc_html__('Title', 'unistudio-core'),
                        'type' => Controls_Manager::TEXT,
                        'default' => esc_html__('Accordion title', 'unistudio-core'),
                        'label_block' => true,
                    ],
                    [
                        'name' => 'tab_content',
                        'label' => esc_html__('Content', 'unistudio-core'),
                        'type' => Controls_Manager::WYSIWYG,
                        'default' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'unistudio-core'),
                        'show_label' => false,
                    ],
                ],
                'default' => [
                    [
                        'tab_title' => esc_html__('Accordion title', 'unistudio-core'),
                        'tab_content' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'unistudio-core'),
                    ],
                    [
                        'tab_title' => esc_html__('Accordion  title', 'unistudio-core'),
                        'tab_content' => esc_html__('Dolor sit amet, consectetur adipiscing elit.', 'unistudio-core'),
                    ],
                    [
                        'tab_title' => esc_html__('Accordion title', 'unistudio-core'),
                        'tab_content' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'unistudio-core'),
                    ],
                ],
                'title_field' => '{{{ tab_title }}}',
            ]
        );
        
        $this->end_controls_section();
                
        // Style Sections...
        $this->register_style_controls();
    }
    
    protected function register_style_controls() {
        $this->start_controls_section(
            'section_icon',
            [
                'label' => esc_html__('Icon', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
    
        $this->add_control(
            'selected_icon',
            [
                'label' => esc_html__('Icon', 'unistudio-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'unicon-add-alt-filled',
                    'library' => 'unicons',
                ],
                'recommended' => [
                    'unicons' => [
                        'chevron-down',
                        'chevron-up',
                        'chevron-left',
                        'chevron-right',
                        'chevron-right',
                        'add',
                        'add-alt',
                        'add-alt-filled',
                        'close',
                        'close-outline',
                    ],
                ],
            ]
        );
    
        $this->add_control(
            'selected_active_icon',
            [
                'label' => esc_html__('Active Icon', 'unistudio-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'unicon-add-alt-filled',
                    'library' => 'unicons',
                ],
                'recommended' => [
                    'unicons' => [
                        'chevron-down',
                        'chevron-up',
                        'chevron-left',
                        'chevron-right',
                        'chevron-right',
                        'add',
                        'add-alt',
                        'add-alt-filled',
                        'close',
                        'close-outline',
                    ],
                ],
            ]
        );
    
        $this->add_control(
            'icon_align',
            [
                'label' => esc_html__('Icon Alignment', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'right',
                'options' => [
                    'left' => esc_html__('Before', 'unistudio-core'),
                    'right' => esc_html__('After', 'unistudio-core'),
                ],
            ]
        );
    
        $this->add_control(
            'icon_size',
            [
                'label' => esc_html__('Icon Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 14,
                        'max' => 48,
                    ],
                ],
                'default' => [
                    'size' => 24,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-icon' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .uc-accordion-icon i' => 'font-size: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_control(
            'icon_spacing',
            [
                'label' => esc_html__('Icon Spacing', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 10,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-icon.uc-icon-left' => 'margin-right: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .uc-accordion-icon.uc-icon-right' => 'margin-left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_control(
            'icon_rotate',
            [
                'label' => esc_html__('Icon Rotate', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['deg'],
                'range' => [
                    'deg' => [
                        'min' => -180,
                        'max' => 180,
                        'step' => 1,  // Add step size
                    ],
                ],
                'default' => [
                    'unit' => 'deg',
                    'size' => 45,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-item.uc-open .uc-accordion-icon' => 'transform: rotate({{SIZE}}deg);',
                ],
            ]
        );
    
        $this->end_controls_section();

        $this->start_controls_section(
            'options_section',
            [
                'label' => esc_html__('Options', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
    
        // Accordion Settings
        $this->add_control(
            'active_item',
            [
                'label' => esc_html__('Active Item', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => -1,
                'max' => 99,
                'step' => 1,
                'default' => -1,
                'description' => esc_html__('-1 means all closed, 0 means first item opened', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'duration',
            [
                'label' => esc_html__('Animation Duration', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 1000,
                'step' => 50,
                'default' => 200,
            ]
        );
    
        $this->add_control(
            'multiple',
            [
                'label' => esc_html__('Multiple Open Items', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'unistudio-core'),
                'label_off' => esc_html__('No', 'unistudio-core'),
                'default' => 'no',
            ]
        );
    
        $this->add_control(
            'collapsible',
            [
                'label' => esc_html__('Collapsible All', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'unistudio-core'),
                'label_off' => esc_html__('No', 'unistudio-core'),
                'default' => 'yes',
                'description' => esc_html__('Allow all items to be closed', 'unistudio-core'),
            ]
        );
    
        $this->end_controls_section();
    
        // Style Section - Accordion Item
        $this->start_controls_section(
            'section_accordion_style',
            [
                'label' => esc_html__('Accordion Item', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
    
        $this->add_responsive_control(
            'gap',
            [
                'label' => esc_html__('Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 128,
                    ],
                ],
                'default' => [
                    'size' => 16,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'accordion_background',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .uc-accordion-item',
                'fields_options' => [
                    'background' => [
                        'default' => 'classic',
                    ],
                    'color' => [
                        'default' => '#f5f5f5',
                    ]
                ],
            ]
        );

        $this->add_responsive_control(
            'accordion_padding',
            [
                'label' => esc_html__('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '24',
                    'right' => '24',
                    'bottom' => '24',
                    'left' => '24',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'selector' => '{{WRAPPER}} .uc-accordion-item',
            ]
        );
    
        $this->add_responsive_control(
            'border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'accordion_box_shadow',
                'selector' => '{{WRAPPER}} .uc-accordion-item',
            ]
        );
    
        $this->end_controls_section();
    
        // Style Section - Title
        $this->start_controls_section(
            'section_title_style',
            [
                'label' => esc_html__('Title', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
    
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .uc-accordion-title',
            ]
        );
    
        $this->start_controls_tabs('title_style_tabs');
    
        $this->start_controls_tab(
            'title_style_normal',
            [
                'label' => esc_html__('Normal', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'title_color',
            [
                'label' => esc_html__('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-title' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_control(
            'title_background',
            [
                'label' => esc_html__('Background', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-title' => 'background-color: {{VALUE}};',
                ],
            ]
        );
    
        $this->end_controls_tab();
    
        $this->start_controls_tab(
            'title_style_active',
            [
                'label' => esc_html__('Active', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'title_active_color',
            [
                'label' => esc_html__('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-item.uc-open .uc-accordion-title' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_control(
            'title_active_background',
            [
                'label' => esc_html__('Background', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-item.uc-open .uc-accordion-title' => 'background-color: {{VALUE}};',
                ],
            ]
        );
    
        $this->end_controls_tab();
    
        $this->end_controls_tabs();
    
        $this->add_responsive_control(
            'title_padding',
            [
                'label' => esc_html__('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'title_border',
                'selector' => '{{WRAPPER}} .uc-accordion-title',
            ]
        );
    
        $this->add_responsive_control(
            'title_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-title' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->end_controls_section();
    
        // Style Section - Content
        $this->start_controls_section(
            'section_content_style',
            [
                'label' => esc_html__('Content', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
    
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .uc-accordion-content',
            ]
        );
    
        $this->add_control(
            'content_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-content' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_control(
            'content_background',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-content' => 'background-color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'content_gap',
            [
                'label' => esc_html__('Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 128,
                    ],
                ],
                'default' => [
                    'size' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-item' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'content_padding',
            [
                'label' => esc_html__('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '16',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'content_border',
                'selector' => '{{WRAPPER}} .uc-accordion-content',
            ]
        );
    
        $this->add_responsive_control(
            'content_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->end_controls_section();
    
        // Style Section - Icon
        $this->start_controls_section(
            'section_icon_style',
            [
                'label' => esc_html__('Icon', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
    
        $this->add_control(
            'icon_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-icon' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_control(
            'icon_background',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'icon_box_shadow',
                'selector' => '{{WRAPPER}} .uc-accordion-icon',
            ]
        );
    
        $this->add_responsive_control(
            'icon_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-accordion-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->end_controls_section();
    }
    
    protected function render() {

        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_accordion')) {
            return;
        }

        $settings = $this->get_settings_for_display(); 

        $accordion_options = [
            'multiple' => $settings['multiple'] === 'yes' ? 'true' : 'false',
            'collapsible' => $settings['collapsible'] === 'yes' ? 'true' : 'false',
            'duration' => $settings['duration'],
        ];
        
        if ($settings['active_item'] >= 0) {
            $accordion_options['active'] = $settings['active_item'];
        }
        
        $options_string = implode('; ', array_map(
            function($key, $value) { return "$key: $value"; },
            array_keys($accordion_options),
            $accordion_options
        ));
        
        ?>

        <div class="uc-accordion" data-uc-accordion="<?php echo esc_attr($options_string); ?>">
            <?php foreach ($settings['accordion_list'] as $index => $item) : ?>
                <div class="uc-accordion-item">
                    <div class="uc-accordion-title">
                        <?php if ($settings['icon_align'] === 'left' && !empty($settings['selected_icon']['value'])) : ?>
                            <span class="uc-accordion-icon uc-icon-left">
                                <span class="uc-accordion-icon-closed"><?php \Elementor\Icons_Manager::render_icon($settings['selected_icon'], ['aria-hidden' => 'true']); ?></span>
                                <span class="uc-accordion-icon-opened"><?php \Elementor\Icons_Manager::render_icon($settings['selected_active_icon'], ['aria-hidden' => 'true']); ?></span>
                            </span>
                        <?php endif; ?>
                            <h5 class="title m-0"><?php echo wp_kses_post($item['tab_title']); ?></h5>
                        <?php if ($settings['icon_align'] === 'right' && !empty($settings['selected_icon']['value'])) : ?>
                            <span class="uc-accordion-icon uc-icon-right">
                                <span class="uc-accordion-icon-closed"><?php \Elementor\Icons_Manager::render_icon($settings['selected_icon'], ['aria-hidden' => 'true']); ?></span>
                                <span class="uc-accordion-icon-opened"><?php \Elementor\Icons_Manager::render_icon($settings['selected_active_icon'], ['aria-hidden' => 'true']); ?></span>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="uc-accordion-content">
                        <?php echo wp_kses_post($item['tab_content']); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <?php
    }
}