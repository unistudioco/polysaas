<?php
namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Price_Table extends Widget_Base {
    public function get_name() {
        return 'uc_price_table';
    }
    
    public function get_title() {
        return __('UC - Price Table', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-price-table';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    }

    public function get_style_depends() {
        return ['uc-price-table'];
    }
    
    public function register_widget_styles() {
        Asset_Manager::getInstance()->register_widget_style(
            'uc-price-table',
            'assets/css/widgets/price-table.min.css',
            ['uc-core']
        );
    }
    
    public function get_script_depends() {
        return ['elementor-frontend', 'uc-price-table-editor'];
    }

    public function uc_enqueue_editor_scripts() {
        wp_enqueue_script(
            'uc-price-table-editor',
            UC_URL . 'assets/js/widgets/price-table-editor.min.js',
            ['jquery', 'elementor-editor'],
            UC_VERSION,
            true
        );
    }

    protected function register_controls() {

        // Content Controls
        $this->register_content_controls();
        $this->register_layout_controls();
        
        // Style Controls
        $this->register_container_style_controls();
        $this->register_layout_style_controls();
        $this->register_header_style_controls();
        $this->register_pricing_style_controls();
        $this->register_features_style_controls();
        $this->register_cta_style_controls();
        $this->register_featured_style_controls();
        $this->register_hover_effects_controls();
    }

    protected function register_content_controls() {
        
        // Content Section
        $this->start_controls_section(
            'section_header',
            [
                'label' => __('Header', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'plan_title',
            [
                'label' => __('Plan Title', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Basic Plan', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'plan_description',
            [
                'label' => __('Description', 'unistudio-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Perfect for small businesses', 'unistudio-core'),
                'rows' => 3,
            ]
        );

        $this->end_controls_section();

        // Pricing Section
        $this->start_controls_section(
            'section_pricing',
            [
                'label' => __('Pricing', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'currency_symbol',
            [
                'label' => __('Currency Symbol', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '$',
            ]
        );

        $this->add_control(
            'currency_position',
            [
                'label' => __('Currency Position', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'before',
                'options' => [
                    'before' => __('Before', 'unistudio-core'),
                    'after' => __('After', 'unistudio-core'),
                ],
            ]
        );

        $this->add_control(
            'price',
            [
                'label' => __('Price', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '39.99',
            ]
        );

        $this->add_control(
            'price_format',
            [
                'label' => __('Price Format', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'normal',
                'options' => [
                    'normal' => __('Normal', 'unistudio-core'),  // e.g., $39
                    'fractional' => __('Fractional', 'unistudio-core'), // e.g., $39.99
                ],
                'frontend_available' => true,
                'render_type' => 'template',
            ]
        );

        $this->add_control(
            'show_original_price',
            [
                'label' => __('On Sale?', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => '',
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'original_price',
            [
                'label' => __('Original Price', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => '59.00',
                'condition' => [
                    'show_original_price' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'period',
            [
                'label' => __('Period', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Monthly', 'unistudio-core'),
            ]
        );

        $this->end_controls_section();
        
        // Featured Animation
        $this->start_controls_section(
            'section_featured_badge',
            [
                'label' => __('Featured Badge', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
    
        $this->add_control(
            'show_featured_badge',
            [
                'label' => __('Show Featured Badge', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
                'return_value' => 'yes',
            ]
        );
    
        $this->add_control(
            'featured_badge_text',
            [
                'label' => __('Badge Text', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Popular', 'unistudio-core'),
                'condition' => [
                    'show_featured_badge' => 'yes',
                ],
            ]
        );

        // Icon
        $this->add_control(
            'featured_badge_icon',
            [
                'label' => __('Badge Icon', 'unistudio-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'unicon-star-filled',
                    'library' => 'unicons',
                ],
                'recommended' => [
                    'unicons' => [
                        'star-filled',
                        'star',
                        'bookmark-filled',
                    ],
                ],
                'fa4compatibility' => 'icon',
                'skin' => 'inline',
                'upload' => true,
                'condition' => [
                    'show_featured_badge' => 'yes',
                ],
            ]
        );
    
        $this->end_controls_section();

        // Features Section
        $this->start_controls_section(
            'section_features',
            [
                'label' => __('Features', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'feature_icon',
            [
                'label' => __('Icon', 'unistudio-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'unicon-checkmark-outline-filled',
                    'library' => 'unicons',
                ],
                'recommended' => [
                    'unicons' => [
                        'checkmark',
                        'checkmark-outline',
                        'checkmark-outline-filled',
                        'checkbox-checked',
                        'checkbox-checked-filled',
                        'close',
                        'close-outline',
                    ],
                ],
                'skin' => 'inline',
            ]
        );

        $repeater->add_control(
            'feature_text',
            [
                'label' => __('Text', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Feature Item', 'unistudio-core'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'feature_active',
            [
                'label' => __('Active', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'features_list',
            [
                'label' => __('Features', 'unistudio-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'feature_text' => __('10 Projects', 'unistudio-core'),
                        'feature_active' => 'yes',
                    ],
                    [
                        'feature_text' => __('5GB Storage', 'unistudio-core'),
                        'feature_active' => 'yes',
                    ],
                    [
                        'feature_text' => __('Export Reports', 'unistudio-core'),
                        'feature_active' => 'no',
                    ],
                    [
                        'feature_text' => __('Analytics Dashboard', 'unistudio-core'),
                        'feature_active' => 'no',
                    ],
                    [
                        'feature_text' => __('Premium Support', 'unistudio-core'),
                        'feature_active' => 'no',
                    ],
                ],
                'title_field' => '{{{ feature_text }}}',
            ]
        );

        $this->end_controls_section();

        // CTA Section
        $this->start_controls_section(
            'section_cta',
            [
                'label' => __('Call to Action', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __('Button Text', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Get Started', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label' => __('Button Link', 'unistudio-core'),
                'type' => Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'unistudio-core'),
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
            ]
        );

        $this->add_control(
            'additional_info',
            [
                'label' => __('Additional Info', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('No credit card required', 'unistudio-core'),
            ]
        );

        $this->end_controls_section();
    }

    protected function register_layout_controls() {
        $this->start_controls_section(
            'section_layout',
            [
                'label' => __('Layout', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
    
        // Section Order
        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'section_type',
            [
                'label' => __('Section', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'header',
                'options' => [
                    'header' => __('Header', 'unistudio-core'),
                    'pricing' => __('Pricing', 'unistudio-core'),
                    'features' => __('Features', 'unistudio-core'),
                    'cta' => __('Call to Action', 'unistudio-core'),
                    'header_pricing' => __('Header + Pricing', 'unistudio-core'),
                    'pricing_cta' => __('Pricing + CTA', 'unistudio-core'),
                ],
                'frontend_available' => true,
                'render_type' => 'template',
            ]
        );

        $this->add_control(
            'section_order',
            [
                'label' => __('Add, Remove or Re-order', 'unistudio-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'section_type' => 'header',
                    ],
                    [
                        'section_type' => 'pricing',
                    ],
                    [
                        'section_type' => 'cta',
                    ],
                    [
                        'section_type' => 'features',
                    ],
                ],
                'title_field' => '{{{ section_type }}}',
                'frontend_available' => true,
                'render_type' => 'template',
            ]
        );

        $this->add_control(
            'section_order_changed',
            [
                'label' => 'Section Order Changed',
                'type' => Controls_Manager::HIDDEN,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}}' => '--section-order-changed: "{{VALUE}}";',
                ],
                'frontend_available' => true,
                'render_type' => 'template',
            ]
        );
    
        $this->end_controls_section();
    }

    protected function register_layout_style_controls() {
        $this->start_controls_section(
            'section_layout_style',
            [
                'label' => __('Layout', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // Hidden control for active sections (array format)
        $this->add_control(
            'active_sections',
            [
                'type' => Controls_Manager::HIDDEN,
                'default' => ['header', 'pricing', 'cta', 'features'],
                'frontend_available' => true,
            ]
        );
    
        // Hidden control for active sections string (for heading controls)
        $this->add_control(
            'active_sections_string',
            [
                'type' => Controls_Manager::HIDDEN,
                'default' => '',
                'frontend_available' => true,
            ]
        );
    
        // Layout Direction
        $this->add_responsive_control(
            'layout_direction',
            [
                'label' => __('Layout Direction', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'column',
                'options' => [
                    'column' => __('Vertical', 'unistudio-core'),
                    'row' => __('Horizontal', 'unistudio-core'),
                    'column-reverse' => __('Vertical Reverse', 'unistudio-core'),
                    'row-reverse' => __('Horizontal Reverse', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-price-table' => 'display: flex; flex-direction: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'layout_alignement',
            [
                'label' => __('Justify', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Start', 'unistudio-core'), 
                        'icon' => 'eicon-flex eicon-justify-start-h',
                    ],
                    'center' => [
                        'title' => __('Center', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-center-h',
                    ],
                    'flex-end' => [
                        'title' => __('End', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-end-h', 
                    ],
                    'space-between' => [
                        'title' => __('Space Between', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-space-between-h',
                    ],
                    'space-around' => [
                        'title' => __('Space Around', 'unistudio-core'), 
                        'icon' => 'eicon-flex eicon-justify-space-around-h',
                    ],
                    'space-evenly' => [
                        'title' => __('Space Evenly', 'unistudio-core'),
                        'icon' => 'eicon-flex eicon-justify-space-evenly-h',
                    ],
                ],
                'default' => 'space-between',
                'toggle' => false,
                'selectors' => [
                    '{{WRAPPER}} .uc-price-table' => 'justify-content: {{VALUE}};',
                ],
            ]
        );
    
        // Section Spacing
        $this->add_responsive_control(
            'sections_gap',
            [
                'label' => __('Sections Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 10,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 10,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-price-table' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $sections = [
            'header' => __('Header', 'unistudio-core'),
            'pricing' => __('Pricing', 'unistudio-core'),
            'cta' => __('Call to Action', 'unistudio-core'),
            'features' => __('Features', 'unistudio-core'),
            'header_pricing' => __('Header + Pricing', 'unistudio-core'),
            'pricing_cta' => __('Pricing + CTA', 'unistudio-core'),
        ];
    
        foreach ($sections as $section_key => $section_label) {

            $this->add_control(
                'section_' . $section_key . '_style_heading',
                [
                    'label' => sprintf(__('%s Section', 'unistudio-core'), $section_label),
                    'type' => Controls_Manager::HEADING,
                    'separator' => 'before',
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'active_sections_string',
                                'operator' => 'contains',
                                'value' => $section_key,
                            ],
                        ],
                    ],
                ]
            );
    
            $this->add_responsive_control(
                $section_key . '_alignment',
                [
                    'label' => __('Alignment', 'unistudio-core'),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        'flex-start' => [
                            'title' => __('Start', 'unistudio-core'),
                            'icon' => 'eicon-align-start-h',
                        ],
                        'center' => [
                            'title' => __('Center', 'unistudio-core'),
                            'icon' => 'eicon-align-center-h',
                        ],
                        'flex-end' => [
                            'title' => __('End', 'unistudio-core'),
                            'icon' => 'eicon-align-end-h',
                        ],
                        'stretch' => [
                            'title' => __('Stretch', 'unistudio-core'),
                            'icon' => 'eicon-align-stretch-h',
                        ],
                    ],
                    'default' => 'stretch',
                    'selectors' => [
                        '{{WRAPPER}} .price-table-' . $section_key => 'align-self: {{VALUE}};',
                    ],
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'active_sections',
                                'operator' => 'contains',
                                'value' => $section_key,
                            ],
                        ],
                    ],
                ]
            );

            if($section_key === 'features') {
                $this->add_responsive_control(
                    'features_text_alignment',
                    [
                        'label' => __('Text Alignment', 'unistudio-core'),
                        'type' => Controls_Manager::CHOOSE,
                        'options' => [
                            'left' => [
                                'title' => __('Left', 'unistudio-core'),
                                'icon' => 'eicon-text-align-left',
                            ],
                            'center' => [
                                'title' => __('Center', 'unistudio-core'),
                                'icon' => 'eicon-text-align-center',
                            ],
                            'right' => [
                                'title' => __('Right', 'unistudio-core'),
                                'icon' => 'eicon-text-align-right',
                            ],
                        ],
                        'default' => 'left',
                        'selectors' => [
                            '{{WRAPPER}} .price-table-features .feature-item' => 'justify-content: {{VALUE}};',
                        ],
                        'conditions' => [
                            'terms' => [
                                [
                                    'name' => 'active_sections',
                                    'operator' => 'contains',
                                    'value' => 'features',
                                ],
                            ],
                        ],
                    ]
                );
            } else {
                $this->add_responsive_control(
                    $section_key . '_text_alignment',
                    [
                        'label' => __('Text Alignment', 'unistudio-core'),
                        'type' => Controls_Manager::CHOOSE,
                        'options' => [
                            'left' => [
                                'title' => __('Left', 'unistudio-core'),
                                'icon' => 'eicon-text-align-left',
                            ],
                            'center' => [
                                'title' => __('Center', 'unistudio-core'),
                                'icon' => 'eicon-text-align-center',
                            ],
                            'right' => [
                                'title' => __('Right', 'unistudio-core'),
                                'icon' => 'eicon-text-align-right',
                            ],
                        ],
                        'default' => 'center',
                        'selectors' => [
                            '{{WRAPPER}} .price-table-' . $section_key => 'text-align: {{VALUE}};',
                        ],
                        'conditions' => [
                            'terms' => [
                                [
                                    'name' => 'active_sections',
                                    'operator' => 'contains',
                                    'value' => $section_key,
                                ],
                            ],
                        ],
                    ]
                );
            }
    
            $this->add_responsive_control(
                $section_key . '_padding',
                [
                    'label' => __('Padding', 'unistudio-core'),
                    'type' => Controls_Manager::DIMENSIONS,
                    'size_units' => ['px', 'em', 'rem', '%'],
                    'selectors' => [
                        '{{WRAPPER}} .price-table-' . $section_key => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'conditions' => [
                        'terms' => [
                            [
                                'name' => 'active_sections',
                                'operator' => 'contains',
                                'value' => $section_key,
                            ],
                        ],
                    ],
                ]
            );

        }
    
        $this->end_controls_section();
    }

    protected function register_container_style_controls() {
        $this->start_controls_section(
            'section_container_style',
            [
                'label' => __('Container', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'container_padding',
            [
                'label' => __('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '32',
                    'right' => '32',
                    'bottom' => '32',
                    'left' => '32',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-price-table' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'container_margin',
            [
                'label' => __('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-price-table' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'container_background',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .uc-price-table',
                'fields_options' => [
                    'background' => [
                        'default' => 'classic',
                    ],
                    'color' => [
                        'default' => '#f5f5f5',
                    ],
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'container_border',
                'selector' => '{{WRAPPER}} .uc-price-table',
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'container_border_radius',
            [
                'label' => __('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '12',
                    'right' => '12',
                    'bottom' => '12',
                    'left' => '12',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-price-table' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'container_box_shadow',
                'selector' => '{{WRAPPER}} .uc-price-table',
            ]
        );

        $this->end_controls_section();
    }

    protected function register_header_style_controls() {
        $this->start_controls_section(
            'section_header_style',
            [
                'label' => __('Header', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'active_sections',
                            'operator' => 'contains',
                            'value' => 'header',
                        ],
                    ],
                ],
            ]
        );

        // Title Typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __('Title Typography', 'unistudio-core'),
                'selector' => '{{WRAPPER}} .plan-title',
            ]
        );

        // Title Color
        $this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} .plan-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'header_background',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .price-table-header',
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'active_sections',
                            'operator' => 'contains',
                            'value' => 'header',
                        ],
                    ],
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'header_border',
                'selector' => '{{WRAPPER}} .price-table-header',
                'separator' => 'before',
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'active_sections',
                            'operator' => 'contains',
                            'value' => 'header',
                        ],
                    ],
                ],
            ]
        );

        // Description Typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'label' => __('Description Typography', 'unistudio-core'),
                'selector' => '{{WRAPPER}} .plan-description',
                'separator' => 'before',
            ]
        );

        // Description Color
        $this->add_control(
            'description_color',
            [
                'label' => __('Description Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#666666',
                'selectors' => [
                    '{{WRAPPER}} .plan-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function register_pricing_style_controls() {
        $this->start_controls_section(
            'section_pricing_style',
            [
                'label' => __('Pricing', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'active_sections',
                            'operator' => 'contains',
                            'value' => 'pricing',
                        ],
                    ],
                ],
            ]
        );
    
        $this->add_responsive_control(
            'pricing_direction',
            [
                'label' => __('Direction', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'row',
                'options' => [
                    'column' => __('Vertical', 'unistudio-core'),
                    'row' => __('Horizontal', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-price-table .price-table-pricing' => 'display: inline-flex; flex-direction: {{VALUE}};',
                ],
            ]
        );


    
        $this->add_responsive_control(
            'pricing_price_alignment',
            [
                'label' => __('Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => __('Start', 'unistudio-core'),
                        'icon' => 'eicon-align-start-h',
                    ],
                    'center' => [
                        'title' => __('Center', 'unistudio-core'),
                        'icon' => 'eicon-align-center-h',
                    ],
                    'flex-end' => [
                        'title' => __('End', 'unistudio-core'),
                        'icon' => 'eicon-align-end-h',
                    ],
                ],
                'default' => 'flex-end',
                'selectors' => [
                    '{{WRAPPER}} .uc-price-table .price-table-pricing' => 'align-items: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'pricing_color',
            [
                'label' => __('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#000000',
                'selectors' => [
                    '{{WRAPPER}} .price-table-pricing' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'price_typography_font_family_override',
            [
                'label' => __('Price Font Family Override', 'unistudio-core'),
                'type' => Controls_Manager::HIDDEN,
                'default' => 'initial',
                'selectors' => [
                    '{{WRAPPER}} .price-table-price-wrap' => 'font-family: var(--font-family-secondary);',
                ],
            ]
        );

        // Price Typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'price_typography',
                'label' => __('Price Typography', 'unistudio-core'),
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 48
                        ]
                    ],
                    'font_weight' => ['default' => '700'],
                ],
                'separator' => 'before',
                'selector' => '{{WRAPPER}} .price-table-price-wrap',
            ]
        );

        $this->add_control(
            'currency_typography_font_family_override',
            [
                'label' => __('Currency Font Family Override', 'unistudio-core'),
                'type' => Controls_Manager::HIDDEN,
                'default' => 'initial',
                'selectors' => [
                    '{{WRAPPER}} .currency-symbol' => 'font-family: var(--font-family-secondary);',
                ],
            ]
        );

        // Period Typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'period_typography',
                'label' => __('Period Typography', 'unistudio-core'),
                'selector' => '{{WRAPPER}} .period',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 14
                        ]
                    ],
                    'font_weight' => ['default' => '500'],
                ],
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();
    }

    protected function register_features_style_controls() {

        $this->start_controls_section(
            'section_features_style',
            [
                'label' => __('Features', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'active_sections',
                            'operator' => 'contains',
                            'value' => 'features',
                        ],
                    ],
                ],
            ]
        );

        // Features Container
        $this->add_responsive_control(
            'features_spacing',
            [
                'label' => __('Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    'em' => [
                        'min' => 0,
                        'max' => 5,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 12,
                ],
                'selectors' => [
                    '{{WRAPPER}} .features-list' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Feature Text Style
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'features_typography',
                'label' => __('Typography', 'unistudio-core'),
                'selector' => '{{WRAPPER}} .feature-text',
                'separator' => 'before',
            ]
        );

        // Active Feature Style
        $this->add_control(
            'feature_active_color',
            [
                'label' => __('Active Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .feature-active .feature-icon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .feature-active .feature-icon svg' => 'fill: {{VALUE}};',
                    '{{WRAPPER}} .feature-active .feature-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        // Inactive Feature Style
        $this->add_control(
            'feature_inactive_color',
            [
                'label' => __('Inactive Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .feature-inactive .feature-icon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .feature-inactive .feature-icon svg' => 'fill: {{VALUE}};',
                    '{{WRAPPER}} .feature-inactive .feature-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        // Feature Icon Style
        $this->add_control(
            'features_icon_size',
            [
                'label' => __('Icon Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 12,
                        'max' => 48,
                        'step' => 2,
                    ],
                    'em' => [
                        'min' => 0.75,
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'selectors' => [
                    '{{WRAPPER}} .feature-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .feature-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function register_cta_style_controls() {
        $this->start_controls_section(
            'section_cta_style',
            [
                'label' => __('Call to Action', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'active_sections',
                            'operator' => 'contains',
                            'value' => 'cta',
                        ],
                    ],
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'cta_background',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .price-table-cta',
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'active_sections',
                            'operator' => 'contains',
                            'value' => 'cta',
                        ],
                    ],
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'cta_border',
                'selector' => '{{WRAPPER}} .price-table-cta',
                'separator' => 'before',
                'conditions' => [
                    'terms' => [
                        [
                            'name' => 'active_sections',
                            'operator' => 'contains',
                            'value' => 'cta',
                        ],
                    ],
                ],
            ]
        );
    
        // Button Style
        $this->add_control(
            'button_style_heading',
            [
                'label' => __('Button', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separtor' => 'before'
            ]
        );
    
        $this->add_responsive_control(
            'button_width',
            [
                'label' => __('Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => '%',
                    'size' => 100,
                ],
                'selectors' => [
                    '{{WRAPPER}} .price-table-button' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'button_padding',
            [
                'label' => __('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .price-table-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        // Button Colors
        $this->start_controls_tabs('button_styles');
    
        // Normal State
        $this->start_controls_tab(
            'button_normal',
            [
                'label' => __('Normal', 'unistudio-core'),
            ]
        );
    
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'label' => __('Typography', 'unistudio-core'),
                'selector' => '{{WRAPPER}} .price-table-button',
            ]
        );
    
        $this->add_control(
            'button_text_color',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#FFFFFF',
                'selectors' => [
                    '{{WRAPPER}} .price-table-button' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'button_background',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .price-table-button',
                'fields_options' => [
                    'background' => [
                        'default' => 'classic',
                    ],
                    'color' => [
                        'default' => 'var(--color-primary)',
                    ],
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'selector' => '{{WRAPPER}} .price-table-button',
                'separator' => 'before',
            ]
        );
    
        $this->add_control(
            'button_border_radius',
            [
                'label' => __('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .price-table-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow',
                'selector' => '{{WRAPPER}} .price-table-button',
            ]
        );
    
        $this->end_controls_tab();
    
        // Hover State
        $this->start_controls_tab(
            'button_hover',
            [
                'label' => __('Hover', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'button_text_color_hover',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#FFFFFF',
                'selectors' => [
                    '{{WRAPPER}} .price-table-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'button_background_hover',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .price-table-button:hover',
                'fields_options' => [
                    'background' => [
                        'default' => 'classic',
                    ],
                    'color' => [
                        'default' => 'var(--color-secondary)',
                    ],
                ],
            ]
        );
    
        $this->add_control(
            'button_border_color_hover',
            [
                'label' => __('Border Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .price-table-button:hover' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'button_border_border!' => '',
                ],
            ]
        );
    
        $this->add_control(
            'button_border_radius_hover',
            [
                'label' => __('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .price-table-button:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_box_shadow_hover',
                'selector' => '{{WRAPPER}} .price-table-button:hover',
            ]
        );
    
        $this->add_control(
            'button_hover_transition',
            [
                'label' => __('Transition Duration', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'size' => 0.3,
                ],
                'selectors' => [
                    '{{WRAPPER}} .price-table-button' => 'transition: all {{SIZE}}s ease-in-out;',
                ],
            ]
        );
    
        $this->end_controls_tab();
    
        $this->end_controls_tabs();
    
        // Additional Info Style
        $this->add_control(
            'additional_info_heading',
            [
                'label' => __('Additional Info', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'additional_info!' => '',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'additional_info_typography',
                'selector' => '{{WRAPPER}} .additional-info',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 14
                        ]
                    ],
                    'font_weight' => ['default' => '400'],
                ],
                'condition' => [
                    'additional_info!' => '',
                ],
            ]
        );
    
        $this->add_control(
            'additional_info_color',
            [
                'label' => __('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#666666',
                'selectors' => [
                    '{{WRAPPER}} .additional-info' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'additional_info!' => '',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'additional_info_margin',
            [
                'label' => __('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '12',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .additional-info' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'additional_info!' => '',
                ],
            ]
        );
    
        $this->end_controls_section();
    }

    protected function register_featured_style_controls() {
        $this->start_controls_section(
            'section_featured_style',
            [
                'label' => __('Featured Badge', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_featured_badge' => 'yes',
                ],
            ]
        );
    
        $this->add_control(
            'badge_text_color',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#FFFFFF',
                'selectors' => [
                    '{{WRAPPER}} .price-table-badge' => 'color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_control(
            'badge_background_color',
            [
                'label' => __('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => 'var(--color-primary)',
                'selectors' => [
                    '{{WRAPPER}} .price-table-badge' => 'background-color: {{VALUE}};',
                ],
            ]
        );
    
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'badge_typography',
                'selector' => '{{WRAPPER}} .price-table-badge .badge-text',
            ]
        );
    
        $this->add_responsive_control(
            'badge_padding',
            [
                'label' => __('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '4',
                    'right' => '12',
                    'bottom' => '4',
                    'left' => '12',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .price-table-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'badge_border_radius',
            [
                'label' => __('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '4',
                    'right' => '4',
                    'bottom' => '4',
                    'left' => '4',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .price-table-badge' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'featured_badge_position',
            [
                'label' => __('Position', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'ribbon-top-right',
                'options' => [
                    'ribbon-top-left' => __('Top Left', 'unistudio-core'),
                    'ribbon-top-right' => __('Top Right', 'unistudio-core'),
                    'ribbon-top-center' => __('Top Center', 'unistudio-core'),
                    'ribbon-top' => __('Top Stretch', 'unistudio-core'),
                ],
                'condition' => [
                    'show_featured_badge' => 'yes',
                ],
                'frontend_available' => true,
                'render_type' => 'template',
            ]
        );
    
        $this->add_responsive_control(
            'featured_badge_distance',
            [
                'label' => __('Distance from Edge', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 16,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .featured-ribbon-top-left .price-table-badge' => 'left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .featured-ribbon-top-right .price-table-badge' => 'right: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'featured_badge_position' => ['ribbon-top-left', 'ribbon-top-right'],
                ],
            ]
        );
    
        $this->add_responsive_control(
            'featured_badge_top_distance',
            [
                'label' => __('Distance from Top', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .price-table-badge' => 'top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
    
        $this->end_controls_section();
    }

    protected function register_hover_effects_controls() {
        $this->start_controls_section(
            'section_hover_effects',
            [
                'label' => __('Hover Effects', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
    
        // Container Hover Effects
        $this->start_controls_tabs('container_hover_effects');
    
        // Normal State
        $this->start_controls_tab(
            'container_normal_state',
            [
                'label' => __('Normal', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'container_scale',
            [
                'label' => __('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.8,
                        'max' => 1.5,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-price-table' => 'transform: scale({{SIZE}}) translateY({{container_translate_y.SIZE}}px);',
                ],
            ]
        );
    
        $this->add_control(
            'container_translate_y',
            [
                'label' => __('Translate Y', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-price-table' => 'transform: scale({{container_scale.SIZE}}) translateY({{SIZE}}px);',
                ],
            ]
        );
    
        // Container Box Shadow
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'container_box_shadow_normal',
                'selector' => '{{WRAPPER}} .uc-price-table',
            ]
        );
    
        $this->end_controls_tab();
    
        // Hover State
        $this->start_controls_tab(
            'container_hover_state',
            [
                'label' => __('Hover', 'unistudio-core'),
            ]
        );
    
        $this->add_control(
            'container_scale_hover',
            [
                'label' => __('Scale', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0.8,
                        'max' => 1.5,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-price-table:hover' => 'transform: scale({{SIZE}}) translateY({{container_translate_y_hover.SIZE}}px);',
                ],
            ]
        );
    
        $this->add_control(
            'container_translate_y_hover',
            [
                'label' => __('Translate Y', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -100,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-price-table:hover' => 'transform: scale({{container_scale_hover.SIZE}}) translateY({{SIZE}}px);',
                ],
            ]
        );
    
        // Container Box Shadow on Hover
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'container_box_shadow_hover',
                'selector' => '{{WRAPPER}} .uc-price-table:hover',
            ]
        );
    
        // Container Background on Hover
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'container_background_hover',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .uc-price-table:hover',
            ]
        );
    
        $this->end_controls_tab();
    
        $this->end_controls_tabs();
    
        // Transition Effects
        $this->add_control(
            'transition_heading',
            [
                'label' => __('Transition', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
    
        $this->add_control(
            'transition_duration',
            [
                'label' => __('Duration', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'size' => 0.3,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-price-table' => 'transition: all {{SIZE}}s ease-in-out;',
                ],
            ]
        );
    
        $this->end_controls_section();

    }

    protected function render() {
        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_price_table')) {
            return;
        }
    
        $settings = $this->get_settings_for_display();
        
        // Build wrapper classes
        $wrapper_classes = ['uc-price-table'];
        
        // Add featured classes if enabled
        if ($settings['show_featured_badge'] === 'yes') {
            $wrapper_classes[] = 'featured';
            $wrapper_classes[] = 'featured-' . $settings['featured_badge_position'];
        }
        
        // Add layout type class
        if (!empty($settings['layout_type'])) {
            $wrapper_classes[] = 'price-table-layout-' . $settings['layout_type'];
        }
        
        // Add render attributes
        $this->add_render_attribute('wrapper', 'class', $wrapper_classes);
        
        ?>
        
        <div <?php $this->print_render_attribute_string('wrapper'); ?>>
            <?php 
            // Render featured badge if enabled
            if ($settings['show_featured_badge'] === 'yes' && !empty($settings['featured_badge_text'])) : ?>
                <div class="price-table-badge">
                    <?php
                        if (isset($settings['featured_badge_icon']['library']) && $settings['featured_badge_icon']['library'] === 'svg') {
                            echo '<img class="uc-custom-icon" src="' . esc_url($settings['featured_badge_icon']['value']['url']) . '" alt="svg-icon">';
                        } else {
                            \Elementor\Icons_Manager::render_icon($settings['featured_badge_icon'], ['class' => 'badge-icon', 'aria-hidden' => 'true']);
                        }
                    ?>
                    <span class="badge-text"><?php echo esc_html($settings['featured_badge_text']); ?></span>
                </div>
            <?php endif; ?>
    
            <?php
            // Render sections based on repeater order
            if (!empty($settings['section_order'])) {
                foreach ($settings['section_order'] as $item) {
                    if (!empty($item['section_type'])) {
                        $method = 'render_' . $item['section_type'];
                        if (method_exists($this, $method)) {
                            $this->$method($settings);
                        }
                    }
                }
            }
            ?>
        </div>
        <?php
    }
    
    protected function render_header($settings) {
        if (empty($settings['plan_title']) && empty($settings['plan_description'])) {
            return;
        }
        ?>
        <div class="price-table-header">
            <?php if (!empty($settings['plan_title'])) : ?>
                <h3 class="plan-title"><?php echo esc_html($settings['plan_title']); ?></h3>
            <?php endif; ?>
    
            <?php if (!empty($settings['plan_description'])) : ?>
                <p class="plan-description"><?php echo esc_html($settings['plan_description']); ?></p>
            <?php endif; ?>
        </div>
        <?php
    }
    
    protected function render_pricing($settings) {
        $currency_symbol = $settings['currency_symbol'];
        $is_currency_before = $settings['currency_position'] === 'before';
        if($settings['price_format'] === 'fractional') {
            $price_parts = explode('.', $settings['price']);
            $integer_part = $price_parts[0];
            $fractional_part = isset($price_parts[1]) ? $price_parts[1] : '';
        }
        ?>
        <div class="price-table-pricing">
            <?php if ($settings['show_original_price'] === 'yes' && !empty($settings['original_price'])) : ?>
                <div class="price-table-original-price">
                    <?php if ($is_currency_before) : ?>
                        <span class="original-price-currency-symbol"><?php echo esc_html($currency_symbol); ?></span>
                    <?php endif; ?>
                    <span class="original-price s"><?php echo esc_html($settings['original_price']); ?></span>
                    <?php if (!$is_currency_before) : ?>
                        <span class="original-price-currency-symbol"><?php echo esc_html($currency_symbol); ?></span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="price-table-price-wrap">
                <?php if ($is_currency_before) : ?>
                    <span class="currency-symbol"><?php echo esc_html($currency_symbol); ?></span>
                <?php endif; ?>
                
                <?php if (!empty($fractional_part) && $settings['price_format'] === 'fractional') : ?>
                    <span class="price-integer-part"><?php echo esc_html($integer_part); ?></span>
                <?php else: ?>
                    <span class="price"><?php echo esc_html($settings['price']); ?></span>
                <?php endif; ?>
                
                <?php if (!empty($fractional_part) && $settings['price_format'] === 'fractional') : ?>
                    <div class="price-fractional-part">
                        <span class="fractional-part"><?php echo esc_html($fractional_part); ?></span>
                    </div>
                <?php endif; ?>
                
                <?php if (!$is_currency_before) : ?>
                    <span class="currency-symbol"><?php echo esc_html($currency_symbol); ?></span>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($settings['period'])) : ?>
                <span class="period"><?php echo esc_html($settings['period']); ?></span>
            <?php endif; ?>
        </div>
        <?php
    }
    
    protected function render_features($settings) {
        if (empty($settings['features_list'])) {
            return;
        }
        ?>
        <div class="price-table-features">
            <ul class="features-list">
                <?php foreach ($settings['features_list'] as $item) : 
                    $feature_class = $item['feature_active'] === 'yes' ? 'feature-active' : 'feature-inactive';
                ?>
                    <li class="feature-item <?php echo esc_attr($feature_class); ?>">
                        <?php if (!empty($item['feature_icon']['value'])) : ?>
                            <span class="feature-icon">
                                <?php \Elementor\Icons_Manager::render_icon($item['feature_icon'], ['aria-hidden' => 'true']); ?>
                            </span>
                        <?php endif; ?>
                        <span class="feature-text"><?php echo esc_html($item['feature_text']); ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php
    }
    
    protected function render_cta($settings) {
        if (empty($settings['button_text'])) {
            return;
        }
        ?>
        <div class="price-table-cta">
            <?php
            $this->add_link_attributes('button', $settings['button_link']);
            $this->add_render_attribute('button', 'class', 'uc-button btn btn-primary price-table-button');
            ?>
            <a <?php $this->print_render_attribute_string('button'); ?>>
                <?php echo esc_html($settings['button_text']); ?>
            </a>
    
            <?php if (!empty($settings['additional_info'])) : ?>
                <div class="additional-info">
                    <?php echo esc_html($settings['additional_info']); ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    protected function render_header_pricing($settings) {
        ?>
        <div class="price-table-header-pricing">
            <?php
            if (!empty($settings['plan_title']) || !empty($settings['plan_description'])) : ?>
                <div class="price-table-header">
                    <?php if (!empty($settings['plan_title'])) : ?>
                        <h3 class="plan-title"><?php echo esc_html($settings['plan_title']); ?></h3>
                    <?php endif; ?>
    
                    <?php if (!empty($settings['plan_description'])) : ?>
                        <p class="plan-description"><?php echo esc_html($settings['plan_description']); ?></p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php $this->render_pricing($settings); ?>

        </div>
        <?php
    }
    
    protected function render_pricing_cta($settings) {
        ?>
        <div class="price-table-pricing-cta">

            <?php $this->render_pricing($settings); ?>
    
            <?php
            if (!empty($settings['button_text'])) : ?>
                <div class="price-table-cta">
                    <?php
                    $this->add_link_attributes('button', $settings['button_link']);
                    $this->add_render_attribute('button', 'class', 'uc-button btn btn-primary price-table-button');
                    ?>
                    <a <?php $this->print_render_attribute_string('button'); ?>>
                        <?php echo esc_html($settings['button_text']); ?>
                    </a>
    
                    <?php if (!empty($settings['additional_info'])) : ?>
                        <div class="additional-info">
                            <?php echo esc_html($settings['additional_info']); ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }
}