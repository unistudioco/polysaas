<?php
namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Team extends Widget_Base {
    public function get_name() {
        return 'uc_team';
    }
    
    public function get_title() {
        return __('UC - Team Card', 'unistudio-core');
    }
        
    public function get_icon() {
        return 'eicon-person';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    }
    
    public function get_style_depends() {
        return ['uc-team'];
    }
    
    public function register_widget_styles() {
        Asset_Manager::getInstance()->register_widget_style(
            'uc-team',
            'assets/css/widgets/team.min.css',
            ['uc-core']
        );
    }

    protected function register_controls() {
        $this->start_controls_section(
            'section_team_members',
            [
                'label' => esc_html__('Content', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'member_name',
            [
                'label' => esc_html__('Name', 'unistudio-core'),
                'default' => esc_html__('John Doe', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
            ]
        );
        
        $this->add_control(
            'member_position',
            [
                'label' => esc_html__('Position', 'unistudio-core'),
                'default' => esc_html__('CEO at UniStudio', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'member_bio',
            [
                'label' => esc_html__('Bio', 'unistudio-core'),
                'default' => esc_html__('Lorem ipsum dolor sit amet consectetur adipisicing elit. Tenetur fuga, voluptatem magni autem repellendus neque dolorum est.', 'unistudio-core'),
                'type' => Controls_Manager::TEXTAREA,
            ]
        );

        $this->add_control(
            'member_image',
            [
                'label' => esc_html__('Photo', 'unistudio-core'),
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $this->add_control(
            'social_icons_list',
            [
                'label' => esc_html__('Social Icons', 'unistudio-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => [
                    [
                        'name' => 'social_icon_name',
                        'label' => esc_html__('Name', 'unistudio-core'),
                        'type' => Controls_Manager::TEXT,
                        'default' => esc_html__('Facebook', 'unistudio-core'),
                    ],
                    [
                        'name' => 'social_icon',
                        'label' => esc_html__('Icon', 'unistudio-core'),
                        'type' => Controls_Manager::ICONS,
                        'default' => [
                            'value' => 'unicon-logo-facebook',
                            'library' => 'unicons',
                        ],
                        'recommended' => [
                            'unicons' => [
                                'logo-linkedin',
                                'logo-twitter',
                                'logo-facebook',
                                'logo-instagram',
                                'logo-github',
                                'logo-youtube',
                                'logo-dribbble',
                                'logo-behance',
                            ],
                        ],
                    ],
                    [
                        'name' => 'social_icon_link',
                        'label' => esc_html__('Link', 'unistudio-core'),
                        'type' => Controls_Manager::URL,
                        'placeholder' => esc_html__('https://your-link.com', 'unistudio-core'),
                        'default' => [
                            'url' => '#',
                            'is_external' => true,
                            'nofollow' => true,
                        ],
                    ],
                ],
                'default' => [
                    [
                        'social_icon_name' => esc_html__('LinkedIn', 'unistudio-core'),
                        'social_icon' => [
                            'value' => 'unicon-logo-linkedin',
                            'library' => 'unicons',
                        ],
                        'social_icon_link' => [
                            'url' => '#',
                        ],
                    ],
                    [
                        'social_icon_name' => esc_html__('Twitter', 'unistudio-core'),
                        'social_icon' => [
                            'value' => 'unicon-logo-twitter',
                            'library' => 'unicons',
                        ],
                        'social_icon_link' => [
                            'url' => '#',
                        ],
                    ],
                ],
                'title_field' => '{{{ social_icon_name }}}',
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_team_settings',
            [
                'label' => esc_html__('Settings', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'team_layout',
            [
                'label' => esc_html__('Pre-defined Layouts', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '1',
                'label_block' => 'yes',
                'options' => [
                    '1' => esc_html__('Layout 01', 'unistudio-core'),
                    '2' => esc_html__('Layout 02', 'unistudio-core'),
                    '3' => esc_html__('Layout 03', 'unistudio-core'),
                    '4' => esc_html__('Layout 04', 'unistudio-core'),
                ],
            ]
        );

        $this->add_control(
            'show_photo',
            [
                'label' => __('Show Photo', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_position',
            [
                'label' => __('Show Position', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_bio',
            [
                'label' => __('Show Bio', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'show_social',
            [
                'label' => __('Show Social Links', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Add Team Style Controls
        $this->register_team_card_layout_controls();
        $this->register_team_card_styling_controls();
        $this->register_team_text_style_controls();
        $this->register_team_social_styling_controls();
    }

    protected function register_team_card_layout_controls() {

        // Layout Controls Section
        $this->start_controls_section(
            'section_team_layout',
            [
                'label' => esc_html__('Card Layout', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
            
        // Team Member Card
        $this->add_control(
            'team_card_heading',
            [
                'label' => esc_html__('Member Card', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
            ]
        );
        
        $this->add_responsive_control(
            'team_card_width',
            [
                'label' => esc_html__('Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px', 'vh'],
                'range' => [
                    '%' => ['min' => 0, 'max' => 100],
                    'px' => ['min' => 0, 'max' => 1440],
                    'vh' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-card' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'team_card_min_height',
            [
                'label' => esc_html__('Min Height', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => ['min' => 0, 'max' => 1000],
                    'vh' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-card' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_control(
            'team_card_direction',
            [
                'label' => esc_html__('Direction', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'column',
                'options' => [
                    'row' => esc_html__('Row', 'unistudio-core'),
                    'row-reverse' => esc_html__('Row Reverse', 'unistudio-core'),
                    'column' => esc_html__('Column', 'unistudio-core'),
                    'column-reverse' => esc_html__('Column Reverse', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-card' => 'flex-direction: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'team_card_gap',
            [
                'label' => esc_html__('Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 16,
                    'unit' => 'px',
                ],
                'size_units' => ['px', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 128,
                        'step' => 8,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-card' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'team_card_vertical_align',
            [
                'label' => esc_html__('Y Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Start', 'unistudio-core'),
                        'icon' => 'eicon-align-start-v',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'unistudio-core'),
                        'icon' => 'eicon-align-center-v',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('End', 'unistudio-core'),
                        'icon' => 'eicon-align-end-v',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-card' => 'align-items: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'team_card_horizontal_align',
            [
                'label' => esc_html__('X Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Start', 'unistudio-core'),
                        'icon' => 'eicon-align-start-h',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'unistudio-core'),
                        'icon' => 'eicon-align-center-h',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('End', 'unistudio-core'),
                        'icon' => 'eicon-align-end-h',
                    ],
                    'space-between' => [
                        'title' => esc_html__('Space Between', 'unistudio-core'),
                        'icon' => 'eicon-justify-space-between-h',
                    ],
                    'space-around' => [
                        'title' => esc_html__('Space around', 'unistudio-core'),
                        'icon' => 'eicon-justify-space-around-h',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-card' => 'justify-content: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'team_card_text_align',
            [
                'label' => __('Text Align', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'unistudio-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'unistudio-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'unistudio-core'),
                        'icon' => 'eicon-text-align-right',
                    ]
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .uc-team-card' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'team_card_container_margin',
            [
                'label' => esc_html__('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', '%'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-card' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );
        
        // Member Info Container
        $this->add_control(
            'member_info_container_heading',
            [
                'label' => esc_html__('Info Container', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->add_responsive_control(
            'member_info_container_width',
            [
                'label' => esc_html__('Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%', 'px', 'vh'],
                'range' => [
                    '%' => ['min' => 0, 'max' => 100],
                    'px' => ['min' => 0, 'max' => 1440],
                    'vh' => ['min' => 0, 'max' => 100],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-info' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->add_control(
            'member_info_direction',
            [
                'label' => esc_html__('Direction', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'column',
                'options' => [
                    'row' => esc_html__('Row', 'unistudio-core'),
                    'row-reverse' => esc_html__('Row Reverse', 'unistudio-core'),
                    'column' => esc_html__('Column', 'unistudio-core'),
                    'column-reverse' => esc_html__('Column Reverse', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-info' => 'flex-direction: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'member_info_vertical_align',
            [
                'label' => esc_html__('Vertical Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Start', 'unistudio-core'),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'unistudio-core'),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('End', 'unistudio-core'),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-info' => 'align-items: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'member_info_gap',
            [
                'label' => esc_html__('Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 4,
                    'unit' => 'px',
                ],
                'size_units' => ['px', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 128,
                        'step' => 8,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-info' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        // Member Photo
        $this->add_control(
            'member_photo_heading',
            [
                'label' => esc_html__('Member Photo', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_photo' => 'yes',
                ],
            ]
        );
        
        $this->add_responsive_control(
            'member_photo_size',
            [
                'label' => esc_html__('Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 120,
                    'unit' => 'px',
                ],
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 48,
                        'max' => 256,
                        'step' => 8,
                    ],
                    '%' => [
                        'min' => 10,
                        'max' => 100,
                        'step' => 10,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-photo .image' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}}; min-width: {{SIZE}}{{UNIT}}; min-height: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_photo' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'member_photo_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '100',
                    'right' => '100', 
                    'bottom' => '100',
                    'left' => '100',
                    'unit' => '%',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-photo .image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_photo' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'member_bio_heading',
            [
                'label' => esc_html__('Bio', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_bio' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'member_bio_margin',
            [
                'label' => esc_html__('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', '%'],
                'default' => [
                    'top' => '16',
                    'right' => '0',
                    'bottom' => '16',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-bio' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_bio' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function register_team_card_styling_controls() {

        $this->start_controls_section(
            'section_team_card_style',
            [
                'label' => esc_html__('Card Styling', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'background_color',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .uc-team-card',
                'fields_options' => [
                    'background' => [
                        'default' => 'classic',
                    ],
                    'color' => [
                        'default' => '#f5f5f5',
                    ]
                ],
            ]
        );

        // Border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'selector' => '{{WRAPPER}} .uc-team-card',
                'separator' => 'before',
                'fields_options' => [
                    'border' => [
                        'default' => 'solid',
                    ],
                    'width' => [
                        'default' => [
                            'top' => '0',
                            'right' => '0',
                            'bottom' => '0',
                            'left' => '0',
                            'unit' => 'px',
                            'isLinked' => true,
                        ],
                    ],
                ],
            ]
        );

        $this->add_control(
            'border_radius',
            [
                'label' => __('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Padding
        $this->add_responsive_control(
            'padding',
            [
                'label' => __('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '40',
                    'right' => '24',
                    'bottom' => '40',
                    'left' => '24',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-team-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Button Shadow
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow',
                'selector' => '{{WRAPPER}} .uc-team-card',
            ]
        );

        $this->end_controls_section();
    }

    protected function register_team_text_style_controls() {
        $this->start_controls_section(
            'section_team_style',
            [
                'label' => esc_html__('Text Styling', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
            
        // Team Member Name Styling
        $this->add_control(
            'style_member_name_heading',
            [
                'label' => esc_html__('Member Name', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'style_member_name_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .member-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'style_member_name_typography',
                'selector' => '{{WRAPPER}} .member-name',
            ]
        );
            
        // Team Member Position Styling
        $this->add_control(
            'style_member_position_heading',
            [
                'label' => esc_html__('Member Position', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'show_position' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'style_member_position_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .member-position' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'show_position' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'style_member_position_typography',
                'selector' => '{{WRAPPER}} .member-position',
                'condition' => [
                    'show_position' => 'yes',
                ],
            ]
        );
            
        // Team Member Bio Styling
        $this->add_control(
            'style_bio_heading',
            [
                'label' => esc_html__('Member Bio', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'show_bio' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'style_bio_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .member-bio' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'show_bio' => 'yes',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'style_bio_typography',
                'selector' => '{{WRAPPER}} .member-bio',
                'condition' => [
                    'show_bio' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function register_team_social_styling_controls() {

        // Layout Controls Section
        $this->start_controls_section(
            'section_social_styling',
            [
                'label' => esc_html__('Social Icons', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'social_icons_container_padding',
            [
                'label' => esc_html__('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', '%'],
                'selectors' => [
                    '{{WRAPPER}} .member-social' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'social_icons_container_margin',
            [
                'label' => esc_html__('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem', '%'],
                'default' => [
                    'top' => '16',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-social' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'social_icons_spacing',
            [
                'label' => esc_html__('Icons Spacing', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 12,
                    'unit' => 'px',
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-social' => 'gap: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'social_icons_align',
            [
                'label' => esc_html__('Icons Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Start', 'unistudio-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'unistudio-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('End', 'unistudio-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .member-social' => 'justify-content: {{VALUE}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        // Individual Social Icons
        $this->add_control(
            'social_icons_style_heading',
            [
                'label' => esc_html__('Social Icons Style', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'social_icon_size',
            [
                'label' => esc_html__('Icon Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 18,
                    'unit' => 'px',
                ],
                'range' => [
                    'px' => [
                        'min' => 12,
                        'max' => 48,
                        'step' => 1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'social_icon_padding',
            [
                'label' => esc_html__('Icon Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'rem'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'social_icon_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '100',
                    'right' => '100',
                    'bottom' => '100',
                    'left' => '100',
                    'unit' => '%',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        // Social Icons Colors
        $this->start_controls_tabs(
            'social_icons_colors_tabs',
            [
                'condition' => [
                    'show_social' => 'yes',
                ],
            ]
        );

        // Normal State
        $this->start_controls_tab(
            'social_icons_colors_normal',
            [
                'label' => esc_html__('Normal', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'social_icon_bg_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => 'var(--color-primary)',
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'social_icon_color',
            [
                'label' => esc_html__('Icon Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        // Hover State
        $this->start_controls_tab(
            'social_icons_colors_hover',
            [
                'label' => esc_html__('Hover', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'social_icon_hover_bg_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => 'var(--color-secondary)',
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'social_icon_hover_color',
            [
                'label' => esc_html__('Icon Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'social_icon_hover_transition',
            [
                'label' => esc_html__('Hover Transition', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0.3,
                ],
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .member-social .social-icon' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render() {
        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_team')) {
            return;
        }

        $settings = $this->get_settings_for_display();

        $this->add_render_attribute('wrapper', [
            'class' => 'elementor-widget-' . $this->get_name(),
            'data-widget' => $this->get_name(),
        ]);

        ?>
        <div <?php $this->print_render_attribute_string('wrapper'); ?>>
            <?php $this->render_team_content($settings); ?>
        </div>
        <?php

    }

    protected function render_team_content($settings) { ?>
        <div class="uc-team-card">
            <?php if ($settings['show_photo'] === 'yes' && !empty($settings['member_image']['url'])): ?>
                <div class="member-photo">
                    <img class="image" src="<?php echo esc_url($settings['member_image']['url']); ?>" 
                         alt="<?php echo esc_attr($settings['member_name']); ?>">
                </div>
            <?php endif; ?>
            <div class="team-content-wrap">
                <div class="member-info">
                    <?php if (!empty($settings['member_name'])): ?>
                        <h6 class="member-name"><?php echo esc_html($settings['member_name']); ?></h6>
                    <?php endif; ?>
    
                    <?php if ($settings['show_position'] === 'yes' && !empty($settings['member_position'])): ?>
                        <div class="member-position">
                            <?php echo esc_html($settings['member_position']); ?>
                        </div>
                    <?php endif; ?>
                </div>
    
                <?php if ($settings['show_bio'] === 'yes' && !empty($settings['member_bio'])): ?>
                    <div class="member-bio">
                        <?php echo wp_kses_post($settings['member_bio']); ?>
                    </div>
                <?php endif; ?>
    
                <?php if ($settings['show_social'] === 'yes' && !empty($settings['social_icons_list'])): ?>
                    <div class="member-social">
                        <?php
                        foreach ($settings['social_icons_list'] as $item) {
                            $target = $item['social_icon_link']['is_external'] ? ' target="_blank"' : '';
                            $nofollow = $item['social_icon_link']['nofollow'] ? ' rel="nofollow"' : '';
                            
                            if (!empty($item['social_icon_link']['url'])) {
                                ?>
                                <a href="<?php echo esc_url($item['social_icon_link']['url']); ?>"
                                   class="social-icon"
                                   <?php echo $target . $nofollow; ?>>
                                    <i class="<?php echo esc_attr($item['social_icon']['value']); ?>"></i>
                                </a>
                                <?php
                            }
                        }
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php
    }
}