<?php 
namespace UniStudioCore\ElementorManager\Template_Library;

use Elementor\TemplateLibrary\Source_Local;

class Source_Global_Sections extends Source_Local {
    public function get_id() {
        return 'global_sections';
    }

    public function get_title() {
        return __('Global Sections', 'unistudio-core');
    }

    public function register_data() {
        // Don't call parent::register_data() to avoid duplicate tabs
        
        // Register tab filters
        add_filter('elementor/template-library/get_local_templates_type', function($types) {
            $types['uc_global_sections'] = [
                'title' => __('Global Section', 'unistudio-core'),
                'show_in_library' => true,
            ];
            return $types;
        });

        // Register Global Section type in templates manager
        add_filter('elementor/template-library/register_template_type', function($types) {
            $types['uc_global_sections'] = [
                'title' => __('Global Section', 'unistudio-core'),
                'show_in_library' => true,
                'categories' => [], // Empty array to avoid category duplicates
            ];
            return $types;
        });
    }

    // protected function get_template_types() {
    //     // Override parent method to provide only our template type
    //     return [
    //         'uc_global_sections' => __('Global Section', 'unistudio-core'),
    //     ];
    // }
}