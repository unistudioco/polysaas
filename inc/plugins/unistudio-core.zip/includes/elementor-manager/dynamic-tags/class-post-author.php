<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Tag;
use Elementor\Controls_Manager;

class Post_Author extends Tag {
    public function get_name() {
        return 'uc-post-author';
    }

    public function get_title() {
        return __('Post Author', 'polysaas');
    }

    public function get_group() {
        return 'uc-dynamic-tags-post';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }

    protected function register_controls() {
        $this->add_control(
            'author_info',
            [
                'label' => __('Author Info', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => 'display_name',
                'options' => [
                    'display_name' => __('Display Name', 'polysaas'),
                    'first_name' => __('First Name', 'polysaas'),
                    'last_name' => __('Last Name', 'polysaas'),
                    'nickname' => __('Nickname', 'polysaas'),
                    'username' => __('Username', 'polysaas'),
                    'email' => __('Email', 'polysaas'),
                    'bio' => __('Biographical Info', 'polysaas'),
                ],
            ]
        );

        $this->add_control(
            'link_to_author',
            [
                'label' => __('Link to Author Archive', 'polysaas'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'polysaas'),
                'label_off' => __('No', 'polysaas'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'author_info!' => 'email',
                ],
            ]
        );

        $this->add_control(
            'show_avatar',
            [
                'label' => __('Show Avatar', 'polysaas'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'polysaas'),
                'label_off' => __('Hide', 'polysaas'),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $this->add_control(
            'avatar_size',
            [
                'label' => __('Avatar Size', 'polysaas'),
                'type' => Controls_Manager::NUMBER,
                'default' => 96,
                'min' => 20,
                'max' => 300,
                'condition' => [
                    'show_avatar' => 'yes',
                ],
            ]
        );
    }

    public function render() {
        $settings = $this->get_settings_for_display();
        $post_id = get_the_ID();
        
        if (!$post_id) {
            return;
        }
        
        $author_id = get_post_field('post_author', $post_id);
        
        if (!$author_id) {
            return;
        }
        
        $author_info = $settings['author_info'];
        $avatar_output = '';
        
        if ('yes' === $settings['show_avatar']) {
            $avatar_size = (int) $settings['avatar_size'];
            $avatar_output = get_avatar($author_id, $avatar_size) . ' ';
        }
        
        switch ($author_info) {
            case 'first_name':
                $info = get_the_author_meta('first_name', $author_id);
                break;
            case 'last_name':
                $info = get_the_author_meta('last_name', $author_id);
                break;
            case 'nickname':
                $info = get_the_author_meta('nickname', $author_id);
                break;
            case 'username':
                $info = get_the_author_meta('user_login', $author_id);
                break;
            case 'email':
                $info = get_the_author_meta('user_email', $author_id);
                break;
            case 'bio':
                $info = get_the_author_meta('description', $author_id);
                break;
            case 'display_name':
            default:
                $info = get_the_author_meta('display_name', $author_id);
                break;
        }
        
        if (!$info) {
            $info = get_the_author_meta('display_name', $author_id);
        }
        
        if ('yes' === $settings['link_to_author'] && 'email' !== $author_info && 'bio' !== $author_info) {
            $author_url = get_author_posts_url($author_id);
            echo $avatar_output . '<a href="' . esc_url($author_url) . '">' . esc_html($info) . '</a>';
        } else {
            echo $avatar_output . esc_html($info);
        }
    }
}