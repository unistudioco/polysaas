<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Tag;
use Elementor\Controls_Manager;

class Site_Info extends Tag {
    public function get_name() {
        return 'uc-site-info';
    }

    public function get_title() {
        return __('Site Info', 'polysaas');
    }

    public function get_group() {
        return 'uc-dynamic-tags';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }

    protected function register_controls() {
        $this->add_control(
            'info_type',
            [
                'label' => __('Info Type', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => 'title',
                'options' => [
                    'title' => __('Site Title', 'polysaas'),
                    'tagline' => __('Site Tagline', 'polysaas'),
                    'description' => __('Site Description', 'polysaas'),
                    'url' => __('Site URL', 'polysaas'),
                    'email' => __('Admin Email', 'polysaas'),
                    'year' => __('Current Year', 'polysaas'),
                    'copyright' => __('Copyright Text', 'polysaas'),
                    'privacy_policy_url' => __('Privacy Policy URL', 'polysaas'),
                    'login_url' => __('Login URL', 'polysaas'),
                    'logout_url' => __('Logout URL', 'polysaas'),
                    'register_url' => __('Register URL', 'polysaas'),
                    'custom_field' => __('Custom Option Field', 'polysaas'),
                ],
            ]
        );
        
        $this->add_control(
            'custom_field_name',
            [
                'label' => __('Custom Field Name', 'polysaas'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'condition' => [
                    'info_type' => 'custom_field',
                ],
            ]
        );
        
        $this->add_control(
            'link',
            [
                'label' => __('Add Link', 'polysaas'),
                'type' => Controls_Manager::SWITCHER,
                'default' => '',
                'condition' => [
                    'info_type' => ['title', 'tagline', 'year', 'copyright'],
                ],
            ]
        );
        
        $this->add_control(
            'copyright_format',
            [
                'label' => __('Copyright Format', 'polysaas'),
                'type' => Controls_Manager::TEXT,
                'default' => '© {year} {site_title}. All Rights Reserved.',
                'description' => __('Use {year} and {site_title} as placeholders', 'polysaas'),
                'condition' => [
                    'info_type' => 'copyright',
                ],
            ]
        );
        
        $this->add_control(
            'fallback',
            [
                'label' => __('Fallback', 'polysaas'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'description' => __('Displayed if the selected field is empty', 'polysaas'),
            ]
        );
    }

    public function render() {
        $settings = $this->get_settings_for_display();
        $info_type = $settings['info_type'];
        $add_link = 'yes' === $settings['link'];
        $fallback = $settings['fallback'];
        
        switch ($info_type) {
            case 'title':
                $value = get_bloginfo('name');
                if ($add_link) {
                    $value = '<a href="' . esc_url(home_url('/')) . '">' . esc_html($value) . '</a>';
                }
                break;
                
            case 'tagline':
                $value = get_bloginfo('description');
                if ($add_link) {
                    $value = '<a href="' . esc_url(home_url('/')) . '">' . esc_html($value) . '</a>';
                }
                break;
                
            case 'description':
                $value = get_bloginfo('description');
                break;
                
            case 'url':
                $value = get_bloginfo('url');
                break;
                
            case 'email':
                $value = get_bloginfo('admin_email');
                break;
                
            case 'year':
                $value = date('Y');
                if ($add_link) {
                    $value = '<a href="' . esc_url(home_url('/')) . '">' . esc_html($value) . '</a>';
                }
                break;
                
            case 'copyright':
                $format = $settings['copyright_format'];
                $value = strtr($format, [
                    '{year}' => date('Y'),
                    '{site_title}' => get_bloginfo('name'),
                ]);
                
                if ($add_link) {
                    $value = '<a href="' . esc_url(home_url('/')) . '">' . $value . '</a>';
                }
                break;
                
            case 'privacy_policy_url':
                $value = get_privacy_policy_url();
                break;
                
            case 'login_url':
                $value = wp_login_url();
                break;
                
            case 'logout_url':
                $value = wp_logout_url();
                break;
                
            case 'register_url':
                $value = wp_registration_url();
                break;
                
            case 'custom_field':
                $field_name = $settings['custom_field_name'];
                if (empty($field_name)) {
                    $value = '';
                    break;
                }
                
                $value = get_option($field_name);
                break;
                
            default:
                $value = '';
                break;
        }
        
        if (empty($value) && !empty($fallback)) {
            $value = $fallback;
        }
        
        echo $value;
    }
}