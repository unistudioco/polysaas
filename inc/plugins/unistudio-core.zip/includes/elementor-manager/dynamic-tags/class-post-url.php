<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Data_Tag;

class Post_URL extends Data_Tag {
    public function get_name() {
        return 'uc-post-url';
    }

    public function get_title() {
        return __('Post URL', 'unistudio-core');
    }

    public function get_group() {
        return 'uc-dynamic-tags-post';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::URL_CATEGORY];
    }

    public function get_value(array $options = []) {
        $post_id = get_the_ID();
        if ($post_id) {
            return get_permalink($post_id);
        }
        return '';
    }
}