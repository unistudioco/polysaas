<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Tag;
use Elementor\Controls_Manager;

class Counter extends Tag {
    public function get_name() {
        return 'uc-counter';
    }

    public function get_title() {
        return __('Counter', 'polysaas');
    }

    public function get_group() {
        return 'uc-dynamic-tags';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }

    protected function register_controls() {
        $this->add_control(
            'counter_type',
            [
                'label' => __('Counter Type', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => 'post_views',
                'options' => [
                    'post_views' => __('Post Views', 'polysaas'),
                    'post_count' => __('Post Count', 'polysaas'),
                    'user_count' => __('User Count', 'polysaas'),
                    'comment_count' => __('Total Comments', 'polysaas'),
                    'custom_meta' => __('Custom Post Meta', 'polysaas'),
                    'custom_option' => __('Custom Site Option', 'polysaas'),
                ],
            ]
        );
        
        $this->add_control(
            'custom_field_name',
            [
                'label' => __('Meta/Option Key', 'polysaas'),
                'type' => Controls_Manager::TEXT,
                'default' => 'counter',
                'condition' => [
                    'counter_type' => ['custom_meta', 'custom_option'],
                ],
            ]
        );
        
        $this->add_control(
            'post_type',
            [
                'label' => __('Post Type', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => 'post',
                'options' => $this->get_post_types(),
                'condition' => [
                    'counter_type' => 'post_count',
                ],
            ]
        );
        
        $this->add_control(
            'number_format',
            [
                'label' => __('Number Format', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => __('Default (1234)', 'polysaas'),
                    'thousands_sep' => __('Thousands Separator (1,234)', 'polysaas'),
                    'short' => __('Short Format (1.2K)', 'polysaas'),
                ],
            ]
        );
        
        $this->add_control(
            'prefix',
            [
                'label' => __('Prefix', 'polysaas'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
            ]
        );
        
        $this->add_control(
            'suffix',
            [
                'label' => __('Suffix', 'polysaas'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
            ]
        );
        
        $this->add_control(
            'fallback',
            [
                'label' => __('Fallback', 'polysaas'),
                'type' => Controls_Manager::TEXT,
                'default' => '0',
                'description' => __('Displayed if the counter is empty or not available', 'polysaas'),
            ]
        );
    }
    
    private function get_post_types() {
        $post_types = ['post' => __('Posts', 'polysaas')];
        
        $args = [
            'public' => true,
            'show_ui' => true,
        ];
        
        $post_types_objects = get_post_types($args, 'objects');
        
        foreach ($post_types_objects as $post_type) {
            // Skip some post types if needed
            if (in_array($post_type->name, ['attachment', 'revision', 'nav_menu_item'])) {
                continue;
            }
            $post_types[$post_type->name] = $post_type->label;
        }
        
        return $post_types;
    }
    
    private function format_number($number) {
        $settings = $this->get_settings_for_display();
        $format = $settings['number_format'];
        
        if ('thousands_sep' === $format) {
            return number_format($number);
        } elseif ('short' === $format) {
            // Format to K, M, B, etc.
            if ($number >= 1000000000) {
                return round($number / 1000000000, 1) . 'B';
            } elseif ($number >= 1000000) {
                return round($number / 1000000, 1) . 'M';
            } elseif ($number >= 1000) {
                return round($number / 1000, 1) . 'K';
            }
            
            return $number;
        }
        
        return $number;
    }

    public function render() {
        $settings = $this->get_settings_for_display();
        $counter_type = $settings['counter_type'];
        $fallback = $settings['fallback'];
        $value = 0;
        
        switch ($counter_type) {
            case 'post_views':
                $post_id = get_the_ID();
                if (!$post_id) {
                    echo $fallback;
                    return;
                }
                
                // Check for popular post view counter plugins
                $view_count = get_post_meta($post_id, 'post_views_count', true); // Default meta key for many view counter plugins
                
                if (empty($view_count)) {
                    // Try other popular meta keys
                    $possible_keys = ['views', '_post_views', 'pvc_views', 'total_views'];
                    
                    foreach ($possible_keys as $key) {
                        $view_count = get_post_meta($post_id, $key, true);
                        if (!empty($view_count)) {
                            break;
                        }
                    }
                }
                
                $value = !empty($view_count) ? intval($view_count) : 0;
                break;
                
            case 'post_count':
                $post_type = $settings['post_type'];
                $count_posts = wp_count_posts($post_type);
                $value = $count_posts->publish;
                break;
                
            case 'user_count':
                $count_users = count_users();
                $value = $count_users['total_users'];
                break;
                
            case 'comment_count':
                $comments_count = wp_count_comments();
                $value = $comments_count->approved;
                break;
                
            case 'custom_meta':
                $post_id = get_the_ID();
                if (!$post_id) {
                    echo $fallback;
                    return;
                }
                
                $field_name = $settings['custom_field_name'];
                if (empty($field_name)) {
                    echo $fallback;
                    return;
                }
                
                $meta_value = get_post_meta($post_id, $field_name, true);
                $value = !empty($meta_value) ? intval($meta_value) : 0;
                break;
                
            case 'custom_option':
                $option_name = $settings['custom_field_name'];
                if (empty($option_name)) {
                    echo $fallback;
                    return;
                }
                
                $option_value = get_option($option_name);
                $value = !empty($option_value) ? intval($option_value) : 0;
                break;
                
            default:
                $value = 0;
                break;
        }
        
        if (empty($value) && $value !== 0) {
            echo $fallback;
            return;
        }
        
        // Format the number
        $formatted_value = $this->format_number($value);
        
        // Add prefix and suffix
        $output = $settings['prefix'] . $formatted_value . $settings['suffix'];
        
        echo $output;
    }
}