<?php
namespace UniStudioCore;
use UniStudioCore\Settings;

class Post_Types {
    private static $instance = null;
    
    public static function getInstance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('init', [$this, 'register_post_types']);
        add_action('init', [$this, 'register_taxonomies']);
    }
    
    public function register_post_types() {
        $settings = Settings::getInstance();

        // Portfolio Post Type
        if ($settings->isEnabled('post_type_uc_portfolio')) {
            register_post_type('uc_portfolio', [
                'labels' => [
                    'name'               => _x('Portfolio', 'post type general name', 'unistudio-core'),
                    'singular_name'      => _x('Project Item', 'post type singular name', 'unistudio-core'),
                    'menu_name'          => _x('Portfolio', 'admin menu', 'unistudio-core'),
                    'name_admin_bar'     => _x('Project Item', 'add new on admin bar', 'unistudio-core'),
                    'add_new'           => _x('Add New', 'portfolio', 'unistudio-core'),
                    'add_new_item'      => __('Add New Project', 'unistudio-core'),
                    'edit_item'         => __('Edit Project', 'unistudio-core'),
                    'new_item'          => __('New Project', 'unistudio-core'),
                    'view_item'         => __('View Project', 'unistudio-core'),
                    'search_items'      => __('Search Project', 'unistudio-core'),
                    'not_found'         => __('No projects found', 'unistudio-core'),
                    'not_found_in_trash'=> __('No projects found in trash', 'unistudio-core'),
                ],
                'public'              => true,
                'show_in_rest'        => true, // Enable Gutenberg editor
                'supports'            => ['title', 'editor', 'thumbnail', 'excerpt'],
                'has_archive'         => true,
                'rewrite'            => ['slug' => 'portfolio'],
                'menu_icon'          => 'dashicons-portfolio',
                'show_in_menu'       => true,
            ]);
        }
    }
    
    public function register_taxonomies() {
        // Project Categories
        register_taxonomy('uc_portfolio_category', ['uc_portfolio'], [
            'labels' => [
                'name'              => _x('Project Categories', 'taxonomy general name', 'unistudio-core'),
                'singular_name'     => _x('Project Category', 'taxonomy singular name', 'unistudio-core'),
                'search_items'      => __('Search Project Categories', 'unistudio-core'),
                'all_items'         => __('All Project Categories', 'unistudio-core'),
                'parent_item'       => __('Parent Project Category', 'unistudio-core'),
                'parent_item_colon' => __('Parent Project Category:', 'unistudio-core'),
                'edit_item'         => __('Edit Project Category', 'unistudio-core'),
                'update_item'       => __('Update Project Category', 'unistudio-core'),
                'add_new_item'      => __('Add New Project Category', 'unistudio-core'),
                'new_item_name'     => __('New Project Category Name', 'unistudio-core'),
                'menu_name'         => __('Categories', 'unistudio-core'),
            ],
            'hierarchical'      => true,
            'show_ui'          => true,
            'show_admin_column'=> true,
            'query_var'        => true,
            'rewrite'          => ['slug' => 'portfolio-category'],
            'show_in_rest'     => true,
        ]);

        // Project Tags
        register_taxonomy('uc_portfolio_tag', ['uc_portfolio'], [
            'labels' => [
                'name'              => _x('Project Tags', 'taxonomy general name', 'unistudio-core'),
                'singular_name'     => _x('Project Tag', 'taxonomy singular name', 'unistudio-core'),
                'search_items'      => __('Search Project Tags', 'unistudio-core'),
                'all_items'         => __('All Project Tags', 'unistudio-core'),
                'edit_item'         => __('Edit Project Tag', 'unistudio-core'),
                'update_item'       => __('Update Project Tag', 'unistudio-core'),
                'add_new_item'      => __('Add New Project Tag', 'unistudio-core'),
                'new_item_name'     => __('New Project Tag Name', 'unistudio-core'),
                'menu_name'         => __('Tags', 'unistudio-core'),
            ],
            'hierarchical'      => false,
            'show_ui'          => true,
            'show_admin_column'=> true,
            'query_var'        => true,
            'rewrite'          => ['slug' => 'portfolio-tag'],
            'show_in_rest'     => true,
        ]);

        // Team Categories
        register_taxonomy('uc_team_category', ['uc_team'], [
            'labels' => [
                'name'              => _x('Team Categories', 'taxonomy general name', 'unistudio-core'),
                'singular_name'     => _x('Team Category', 'taxonomy singular name', 'unistudio-core'),
                'search_items'      => __('Search Team Categories', 'unistudio-core'),
                'all_items'         => __('All Team Categories', 'unistudio-core'),
                'parent_item'       => __('Parent Team Category', 'unistudio-core'),
                'parent_item_colon' => __('Parent Team Category:', 'unistudio-core'),
                'edit_item'         => __('Edit Team Category', 'unistudio-core'),
                'update_item'       => __('Update Team Category', 'unistudio-core'),
                'add_new_item'      => __('Add New Team Category', 'unistudio-core'),
                'new_item_name'     => __('New Team Category Name', 'unistudio-core'),
                'menu_name'         => __('Categories', 'unistudio-core'),
            ],
            'hierarchical'      => true,
            'show_ui'          => true,
            'show_admin_column'=> true,
            'query_var'        => true,
            'rewrite'          => ['slug' => 'team-category'],
            'show_in_rest'     => true,
        ]);
    }
}