<?php

get_header();

?>

<div class="uc-portfolio-archive">
    <div class="container">
        <?php if (have_posts()) : ?>
            <header class="uc-archive-header">
                <h1 class="uc-archive-title"><?php post_type_archive_title(); ?></h1>
                <?php
                $categories = get_terms([
                    'taxonomy' => 'uc_portfolio_category',
                    'hide_empty' => true,
                ]);
                
                if (!empty($categories)) : ?>
                    <div class="uc-portfolio-filters">
                        <button class="uc-filter-archive active" data-filter="*">
                            <?php echo esc_html__('All', 'unistudio-core'); ?>
                        </button>
                        <?php foreach ($categories as $category) : ?>
                            <button class="uc-filter-archive" data-filter=".<?php echo esc_attr($category->slug); ?>">
                                <?php echo esc_html($category->name); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </header>

            <div class="uc-project-listing row child-cols-4" data-uc-grid="masonry: true;">
                <?php
                while (have_posts()) :
                    the_post();
                    ?>
                    <div class="uc-project-item">
                        <!-- portfolio item template -->
                    </div>
                <?php endwhile; ?>
            </div>

            <?php the_posts_pagination(); ?>

        <?php else : ?>
            <p><?php esc_html_e('No portfolio items found.', 'unistudio-core'); ?></p>
        <?php endif; ?>
    </div>
</div>

<?php
get_footer();