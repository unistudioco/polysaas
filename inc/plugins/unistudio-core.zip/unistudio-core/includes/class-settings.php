<?php

namespace UniStudioCore;

class Settings {
    private static $instance = null;
    private $current_page;
    
    public static function getInstance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_menu', [$this, 'add_settings_pages']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        
        // Add filter for whitelisting our option pages
        add_filter('allowed_options', [$this, 'allow_custom_options']);

        // Get current page
        $this->current_page = isset($_GET['page']) ? sanitize_key($_GET['page']) : 'uc-settings';
 }

    public function enqueue_assets($hook) {
        if (strpos($hook, 'unistudio-core') !== false) {
            // Enqueue Elementor icons
            wp_enqueue_style(
                'elementor-icons',
                ELEMENTOR_ASSETS_URL . 'lib/eicons/css/elementor-icons.min.css',
                [],
                ELEMENTOR_VERSION
            );

            // Your existing styles
            wp_enqueue_style(
                'uc-admin-styles',
                UC_URL . 'assets/css/admin/settings.css',
                ['elementor-icons'],
                UC_VERSION
            );

            // Enqueue Select2 for enhanced dropdowns
            wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css');
            wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', ['jquery'], null, true);
            
            // Custom admin scripts
            wp_enqueue_script(
                'uc-admin-scripts',
                UC_URL . 'assets/js/admin/settings.js',
                ['jquery', 'select2'],
                UC_VERSION,
                true
            );
        }
    }

    /**
     * Add our custom options to the allowed options list
     */
    public function allow_custom_options($allowed_options) {
        $allowed_options['uc_general_settings'] = [
            'uc_general_options',
        ];
        
        $allowed_options['uc_post_types_settings'] = [
            'uc_enable_portfolio',
        ];
        
        $allowed_options['uc_elementor_settings'] = [
            'uc_enable_accordion_widget',
            'uc_enable_heading_widget',
            'uc_enable_header_widget',
            'uc_enable_logo_widget',
            'uc_enable_menu_widget',
            'uc_enable_button_widget',
            'uc_enable_tabs_widget',
            'uc_enable_slider_widget',
            'uc_enable_animated_text_widget',
            'uc_enable_marquee_text_widget',
            'uc_enable_icon_box_widget',
            'uc_enable_image_box_widget',
            'uc_enable_portfolio_widget',
            'uc_enable_team_widget',
            'uc_enable_team_slider_widget',
            'uc_enable_testimonials_widget',
            'uc_enable_price_table_widget',
        ];
        
        return $allowed_options;
    }

    public function add_settings_pages() {
        // Add main menu page
        $parent_slug = 'uc-settings';
        
        add_menu_page(
            __('UC Core', 'unistudio-core'),
            __('UC Core', 'unistudio-core'),
            'manage_options',
            $parent_slug,
            [$this, 'render_general_page'],
            'dashicons-admin-generic',
            30
        );

        // Add sub-menu pages
        add_submenu_page(
            $parent_slug,
            __('General', 'unistudio-core'),
            __('General', 'unistudio-core'),
            'manage_options',
            $parent_slug,
            [$this, 'render_general_page']
        );

        add_submenu_page(
            $parent_slug,
            __('Post Types', 'unistudio-core'),
            __('Post Types', 'unistudio-core'),
            'manage_options',
            'uc-post-types',
            [$this, 'render_post_types_page']
        );

        add_submenu_page(
            $parent_slug,
            __('Elementor Widgets', 'unistudio-core'),
            __('Elementor Widgets', 'unistudio-core'),
            'manage_options',
            'uc-widgets',
            [$this, 'render_elementor_page']
        );
    }

    public function register_settings() {
        // Register settings based on current page
        switch ($this->current_page) {
            case 'uc-settings':
                $this->register_general_settings();
                break;
            
            case 'uc-post-types':
                $this->register_post_type_settings();
                break;
            
            case 'uc-widgets':
                $this->register_elementor_settings();
                break;
        }
    }

    private function register_general_settings() {
        register_setting('uc_general_settings', 'uc_general_options');
        register_setting('uc_general_settings', 'uc_custom_fonts');

        // Add sanitization callbacks
        register_setting(
            'uc_general_settings',
            'uc_custom_fonts',
            [
                'type' => 'integer',
                'sanitize_callback' => 'absint',
                'default' => null
            ]
        );
    
        
        add_settings_section(
            'custom_fonts_section',
            __('Custom Fonts', 'unistudio-core'),
            [$this, 'renderSectionDescription'],
            'uc-settings'
        );
        
        add_settings_field(
            'uc_custom_fonts',
            __('Select font typeface:', 'unistudio-core'),
            [$this, 'render_custom_font_upload'],
            'uc-settings',
            'custom_fonts_section',
            [
                'label_for' => 'uc_custom_fonts',
                'description' => __('Upload custom fonts to use on your site.', 'unistudio-core')
            ]
        );
    }

    public function render_custom_font_upload($args) {
        ?>
        <div class="uc-control-wrapper">
            <div>
                <div class="upload-file" style="border: 1px dashed #d5d5d5; padding: 8px; margin-bottom: 8px; border-radius: 4px;"><input type="file" name="uc_custom_fonts" id="uc_custom_fonts"></div>
                <button class="button uc-button btn-sm uc-upload-font-button">Upload font</button>
            </div>
        </div>
        <?php
    }

    private function register_post_type_settings() {
        register_setting('uc_post_types_settings', 'uc_enable_portfolio');

        add_settings_section(
            'post_types_section',
            __('Custom Post Types', 'unistudio-core'),
            [$this, 'renderSectionDescription'],
            'uc-post-types'
        );

        add_settings_field(
            'uc_enable_portfolio',
            __('Portfolio', 'unistudio-core'),
            [$this, 'renderCheckbox'],
            'uc-post-types',
            'post_types_section',
            [
                'label_for' => 'uc_enable_portfolio',
                'label' => __('Enable Portfolio post type and taxonomies.', 'unistudio-core')
            ]
        );
    }

    private function register_elementor_settings() {
        $widgets = [
            'header_widget' => [
                'title' => __('Header', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-header'
            ],
            'heading_widget' => [
                'title' => __('Heading', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-heading'
            ],
            'logo_widget' => [
                'title' => __('Logo', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-logo'
            ],
            'menu_widget' => [
                'title' => __('Menu', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-nav-menu'
            ],
            'button_widget' => [
                'title' => __('Button', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-button'
            ],
            'icon_box_widget' => [
                'title' => __('Icon Box', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-icon-box'
            ],
            'image_box_widget' => [
                'title' => __('Image Box', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-image-box'
            ],
            'slider_widget' => [
                'title' => __('Swiper Slider', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-nested-carousel'
            ],
            'accordion_widget' => [
                'title' => __('Accordion', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-accordion'
            ],
            'tabs_widget' => [
                'title' => __('Tabs', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-tabs'
            ],
            'animated_text_widget' => [
                'title' => __('Animated Text', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-animated-headline'
            ],
            'marquee_text_widget' => [
                'title' => __('Marquee Text', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-wordart'
            ],
            'portfolio_widget' => [
                'title' => __('Portfolio Grid', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-gallery-grid'
            ],
            'team_widget' => [
                'title' => __('Team Members', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-person'
            ],
            'team_slider_widget' => [
                'title' => __('Team Slider', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-person'
            ],
            'testimonials_widget' => [
                'title' => __('Testimonials', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-testimonial'
            ],
            'price_table_widget' => [
                'title' => __('Price Table', 'unistudio-core'),
                'description' => __('', 'unistudio-core'),
                'icon' => 'eicon-price-table'
            ],
        ];

        add_settings_section(
            'elementor_widgets_section',
            __('UC Widgets', 'unistudio-core'),
            [$this, 'renderSectionDescription'],
            'uc-widgets'
        );

        foreach ($widgets as $widget_id => $widget) {
            register_setting('uc_elementor_settings', 'uc_enable_' . $widget_id);
            
            add_settings_field(
                'uc_enable_' . $widget_id,
                $widget['title'],
                [$this, 'renderCheckbox'],
                'uc-widgets',
                'elementor_widgets_section',
                [
                    'label_for' => 'uc_enable_' . $widget_id,
                    'label' => $widget['description'],
                    'icon' => $widget['icon']
                ]
            );
        }
    }

    public function render_settings_page($page, $settings_group) {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div id="unicore-settings" class="uc-settings">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <?php $this->renderTabs(); ?>
            <form action="options.php" method="post" class="uc-settings-form">
                <?php
                settings_fields($settings_group);
                $this->render_custom_settings($page);
                submit_button(
                    __('Save Changes', 'unistudio-core'),
                    'uc-button uc-save-button',
                    'submit',
                    false,
                    ['id' => 'uc-submit']
                );
                ?>
            </form>
        </div>
        <?php
    }

    private function render_custom_settings($page) {
        global $wp_settings_sections, $wp_settings_fields;
        
        if (!isset($wp_settings_sections[$page])) {
            return;
        }

        // Get unique class based on page
        $page_class = str_replace('uc-', '', $page);
        $settings_class = 'uc-settings-fields uc-settings-' . $page_class;

        foreach ((array) $wp_settings_sections[$page] as $section) {
            if ($section['title']) {
                echo '<div class="uc-settings-section">';
                echo '<h2>' . esc_html($section['title']) . '</h2>';
            }

            if ($section['callback']) {
                echo '<div class="uc-section-description">';
                call_user_func($section['callback'], $section);
                echo '</div>';
            }

            if (!isset($wp_settings_fields) || !isset($wp_settings_fields[$page]) || !isset($wp_settings_fields[$page][$section['id']])) {
                continue;
            }

            echo '<div class="' . esc_attr($settings_class) . '">';
            foreach ((array) $wp_settings_fields[$page][$section['id']] as $field) {
                $this->render_custom_field($field);
            }
            echo '</div></div>';
        }
    }

    private function render_custom_field($field) {
        echo '<div class="uc-field-wrapper">';
        echo '<div class="uc-field-header">';
        
        // Icon container
        if (!empty($field['args']['icon'])) {
            echo '<span class="uc-field-icon"><i class="' . esc_attr($field['args']['icon']) . '"></i></span>';
        }
        
        if (!empty($field['args']['label_for'])) {
            echo '<label class="uc-field-label" for="' . esc_attr($field['args']['label_for']) . '">' . $field['title'] . '</label>';
        } else {
            echo '<div class="uc-field-label">' . $field['title'] . '</div>';
        }
        echo '</div>';
        
        echo '<div class="uc-field-content">';
        call_user_func($field['callback'], $field['args']);
        echo '</div>';

        // Description if available
        if (!empty($field['args']['description'])) {
            echo '<p class="description">' . esc_html($field['args']['description']) . '</p>';
        }
        
        echo '</div>';
    }

    public function render_general_page() {
        $this->render_settings_page('uc-settings', 'uc_general_settings');
    }

    public function render_post_types_page() {
        $this->render_settings_page('uc-post-types', 'uc_post_types_settings');
    }

    public function render_elementor_page() {
        $this->render_settings_page('uc-widgets', 'uc_elementor_settings');
    }

    private function renderTabs() {
        $tabs = [
            'uc-settings' => __('General', 'unistudio-core'),
            'uc-post-types' => __('Post Types', 'unistudio-core'),
            'uc-widgets' => __('Elementor Widgets', 'unistudio-core'),
        ];

        echo '<h2 class="nav-tab-wrapper">';
        foreach ($tabs as $page => $label) {
            $class = ($this->current_page === $page) ? 'nav-tab nav-tab-active' : 'nav-tab';
            $url = admin_url('admin.php?page=' . $page);
            echo sprintf(
                '<a href="%s" class="%s">%s</a>',
                esc_url($url),
                esc_attr($class),
                esc_html($label)
            );
        }
        echo '</h2>';
    }

    public function renderSectionDescription($args) {
        switch ($args['id']) {
            case 'post_types_section':
                echo '<p>' . esc_html__('Enable or disable custom post types.', 'unistudio-core') . '</p>';
                break;
            case 'elementor_widgets_section':
                echo '<p>' . esc_html__('Enable or disable UniStudio Core Elementor widgets.', 'unistudio-core') . '</p>';
                break;
            case 'header_footer_section':
                echo '<p>' . esc_html__('Configure your site-wide header and footer templates.', 'unistudio-core') . '</p>';
                break;
        }
    }

    public function renderCheckbox($args) {
        $option = get_option($args['label_for']);
        if ($option === false) {
            $option = '1';
        }
        ?>
        <div class="uc-control-wrapper">
            <label class="uc-switch">
                <input type="checkbox" 
                       id="<?php echo esc_attr($args['label_for']); ?>"
                       name="<?php echo esc_attr($args['label_for']); ?>"
                       value="1"
                       <?php checked('1', $option); ?>>
                <span class="uc-slider"></span>
            </label>
            <span class="uc-switch-label"><?php echo esc_html($args['label']); ?></span>
        </div>
        <?php
    }

    public function isEnabled($feature) {
        switch ($feature) {
            case 'post_type_uc_portfolio':
                return get_option('uc_enable_portfolio', '1') === '1';
            case 'widget_accordion':
                return get_option('uc_enable_accordion_widget', '1') === '1';
            case 'widget_heading':
                return get_option('uc_enable_heading_widget', '1') === '1';
            case 'widget_header':
                return get_option('uc_enable_header_widget', '1') === '1';
            case 'widget_logo':
                return get_option('uc_enable_logo_widget', '1') === '1';
            case 'widget_menu':
                return get_option('uc_enable_menu_widget', '1') === '1';
            case 'widget_button':
                return get_option('uc_enable_button_widget', '1') === '1';
            case 'widget_tabs':
                return get_option('uc_enable_tabs_widget', '1') === '1';
            case 'widget_slider':
                return get_option('uc_enable_slider_widget', '1') === '1';
            case 'widget_animated_text':
                return get_option('uc_enable_animated_text_widget', '1') === '1';
            case 'widget_marquee_text':
                return get_option('uc_enable_marquee_text_widget', '1') === '1';
            case 'widget_icon_box':
                return get_option('uc_enable_icon_box_widget', '1') === '1';
            case 'widget_image_box':
                return get_option('uc_enable_image_box_widget', '1') === '1';
            case 'widget_portfolio_grid':
                return get_option('uc_enable_portfolio_widget', '1') === '1';
            case 'widget_team':
                return get_option('uc_enable_team_widget', '1') === '1';
            case 'widget_team_slider':
                return get_option('uc_enable_team_slider_widget', '1') === '1';
            case 'widget_testimonials':
                return get_option('uc_enable_testimonials_widget', '1') === '1';
            case 'widget_price_table':
                return get_option('uc_enable_price_table_widget', '1') === '1';
            default:
                return false;
        }
    }
}