<?php
namespace UniStudioCore;

/**
 * Display Conditions Manager
 * 
 * Enhanced version that works with ACF field data in the plugin
 */
class Display_Conditions {
    private static $instance = null;
    private $conditions = [];
    private $condition_groups = [];
    
    public static function getInstance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->register_default_conditions();
        $this->register_default_groups();
        
        // Activate the filter to check display conditions when rendering sections
        add_filter('uc_should_render_global_section', [$this, 'check_display_conditions'], 10, 2);
        
        // Add hooks for checking specific section types
        add_action('wp', [$this, 'setup_section_hooks']);
    }

    /**
     * Setup hooks for checking different section types
     */
    public function setup_section_hooks() {
        // No need to set up hooks on admin pages
        if (is_admin()) {
            return;
        }

        // Add hooks for different section types
        $this->setup_header_footer_hooks();
        $this->setup_page_cover_hooks();
        $this->setup_offcanvas_hooks();
        $this->setup_popup_hooks();
    }

    /**
     * Setup hooks for header/footer sections
     */
    private function setup_header_footer_hooks() {
        // Add filters for headers and footers
        add_filter('polysaas_render_header', [$this, 'check_header_section'], 10, 2);
        add_filter('polysaas_render_footer', [$this, 'check_footer_section'], 10, 2);
    }

    /**
     * Setup hooks for page covers
     */
    private function setup_page_cover_hooks() {
        // Add filter for page cover
        add_filter('polysaas_render_page_cover', [$this, 'check_page_cover_section'], 10, 2);
    }

    /**
     * Setup hooks for offcanvas
     */
    private function setup_offcanvas_hooks() {
        // For offcanvas, we'll enqueue them in the footer if they should be displayed
        add_action('wp_head', [$this, 'render_offcanvas'], 10);
    }

    /**
     * Setup hooks for popups
     */
    private function setup_popup_hooks() {
        // For popups, we'll enqueue them in the footer if they should be displayed
        add_action('wp_head', [$this, 'render_popups'], 20);
    }

    /**
     * Check if a header section should be rendered
     */
    public function check_header_section($content, $section_id) {
        if (empty($section_id)) {
            return $content;
        }

        if ($this->check_display_conditions(true, $section_id)) {
            return $this->render_global_section($section_id);
        }

        return $content;
    }

    /**
     * Check if a footer section should be rendered
     */
    public function check_footer_section($content, $section_id) {
        if (empty($section_id)) {
            return $content;
        }

        if ($this->check_display_conditions(true, $section_id)) {
            return $this->render_global_section($section_id);
        }

        return $content;
    }

    /**
     * Check if a page cover section should be rendered
     */
    public function check_page_cover_section($content, $section_id) {
        if (empty($section_id)) {
            return $content;
        }

        if ($this->check_display_conditions(true, $section_id)) {
            return $this->render_global_section($section_id);
        }

        return $content;
    }

    /**
     * Render offcanvas that should be displayed
     */
    public function render_offcanvas() {
        // Get all published offcanvas sections
        $panels = get_posts([
            'post_type' => 'uc_global_sections',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'tax_query' => [
                [
                    'taxonomy' => 'uc_section_type',
                    'field' => 'slug',
                    'terms' => 'offcanvas',
                ]
            ]
        ]);

        foreach ($panels as $panel) {
            if ($this->check_display_conditions(true, $panel->ID)) {
                // Get offcanvas settings
                $offcanvas_settings = get_field('gs_offcanvas_settings', $panel->ID);
                
                // Default values
                $panel_width = isset($offcanvas_settings['panel_width']) ? intval($offcanvas_settings['panel_width']) : 350;
                $full_modifier = isset($offcanvas_settings['full_modifier']);
                $flip_position = $offcanvas_settings['flip_position'] ? 'flip: true;' : '';
                $animation_mode = $offcanvas_settings['animation_mode'] ? 'mode: ' . $offcanvas_settings['animation_mode'] . ';' : 'mode: slide;';
                $overlay = $offcanvas_settings['overlay'] ? 'overlay: true;' : '';
                $close_btn = $offcanvas_settings['close_btn'] ? '<span class="uc-offcanvas-close p-0 m-0 w-32px h-32px cstack" style="cursor: pointer;"><i class="icon icon-3 unicon-close d-inline-flex transition-all duration-150 hover:rotate-90"></i></span>' : '';
                $panel_theme = $offcanvas_settings['panel_theme'] ? 'bg-white text-dark' : 'bg-gray-900 text-white';
                $is_admin_bar = is_admin_bar_showing() ? '<style id="uc_offcanvas_is_admin_bar_showing">.admin-bar .uc-offcanvas-bar { margin-top: 32px; }</style>' : '';
                
                // Render offcanvas container with data attributes
                echo '<div id="uc-offcanvas-' . esc_attr($panel->ID) . '" 
                        class="uc-offcanvas"
                        data-uc-offcanvas="' . esc_attr($animation_mode) . ' ' . esc_attr($flip_position) . ' ' . esc_attr($overlay) . '"
                        data-id="' . esc_attr($panel->ID) . '">
                        <div class="uc-offcanvas-content uc-offcanvas-bar p-0 ' . $panel_theme . '">
                            ' . $close_btn . '
                            <div class="uc-offcanvas-inner">
                                ' . $this->render_global_section($panel->ID) . '
                            </div>
                        </div>
                    </div>';
                echo $is_admin_bar;

                echo '<style id="uc_offcanvas_' . esc_attr($panel->ID) . '_styling">
                @media (min-width: 576px) {
                    :not(.uc-offcanvas-flip).uc-offcanvas-container-animation {
                        left: ' . $panel_width . 'px
                    }

                    .uc-offcanvas-flip.uc-offcanvas-container-animation {
                        left: -' . $panel_width . 'px
                    }

                    .uc-offcanvas-bar {
                        left: -' . $panel_width . 'px;
                        width: ' . $panel_width . 'px;
                    }

                    .uc-offcanvas-flip .uc-offcanvas-bar {
                        right: -' . $panel_width . 'px
                    }

                    .uc-open>.uc-offcanvas-reveal {
                        width: ' . $panel_width . 'px
                    }
                }</style>';
            }
        }
    }

    /**
     * Render popups that should be displayed
     */
    public function render_popups() {
        // Get all published popup sections
        $popups = get_posts([
            'post_type' => 'uc_global_sections',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'tax_query' => [
                [
                    'taxonomy' => 'uc_section_type',
                    'field' => 'slug',
                    'terms' => 'popup',
                ]
            ]
        ]);

        foreach ($popups as $popup) {
            if ($this->check_display_conditions(true, $popup->ID)) {
                // Get popup settings
                $popup_settings = get_field('gs_popup_settings', $popup->ID);
                $trigger_settings = get_field('gs_popup_display_rules_popup_trigger_settings', $popup->ID);
                $frequency = get_field('gs_popup_display_rules_popup_frequency', $popup->ID);
                
                // Default values
                $container_width = isset($popup_settings['container_width']) ? intval($popup_settings['container_width']) : 600;
                $vertically_center = isset($popup_settings['vertically_center']) ? $popup_settings['vertically_center'] : '';
                $full_modifier = isset($popup_settings['full_modifier']) ? $popup_settings['full_modifier'] : '';
                $popup_theme = isset($popup_settings['popup_theme']) ? $popup_settings['popup_theme'] : '';
                $trigger_type = isset($trigger_settings['trigger_type']) ? $trigger_settings['trigger_type'] : 'on_load';
                $load_delay = isset($trigger_settings['load_delay']) ? intval($trigger_settings['load_delay']) * 1000 : 0;
                $scroll_percentage = isset($trigger_settings['scroll_percentage']) ? intval($trigger_settings['scroll_percentage']) : 50;
                $click_selector = isset($trigger_settings['click_selector']) ? $trigger_settings['click_selector'] : '';
                $inactivity_time = isset($trigger_settings['inactivity_time']) ? intval($trigger_settings['inactivity_time']) * 1000 : 30000;
                $is_admin_bar = is_admin_bar_showing() ? '<style id="uc_popup_is_admin_bar_showing">.admin-bar .uc-modal { margin-top: 32px; }</style>' : '';
                
                // Render popup container with data attributes
                echo '<div id="uc-popup-' . esc_attr($popup->ID) . '" 
                        class="uc-popup ' . ($full_modifier ? "uc-modal-full" : "uc-modal") . '"
                        data-uc-modal
                        data-id="' . esc_attr($popup->ID) . '"
                        data-trigger="' . esc_attr($trigger_type) . '"
                        data-delay="' . esc_attr($load_delay) . '"
                        data-scroll="' . esc_attr($scroll_percentage) . '"
                        data-selector="' . esc_attr($click_selector) . '"
                        data-inactivity="' . esc_attr($inactivity_time) . '"
                        data-frequency="' . esc_attr($frequency) . '">
                        <div class="uc-popup-content uc-modal-dialog ' . ($vertically_center ? "uc-margin-auto-vertical" : "") . ' ' . ($popup_theme ? 'bg-white text-dark' : 'bg-gray-900 text-white') . '">
                            <span class="uc-popup-close ' . ($full_modifier ? "uc-modal-close-full" : "uc-modal-close-default") . ' p-0 m-0 w-32px h-32px cstack" style="cursor: pointer;"><i class="icon icon-3 unicon-close d-inline-flex transition-all duration-150 hover:rotate-90"></i></span>
                            <div class="uc-popup-inner">
                                ' . $this->render_global_section($popup->ID) . '
                            </div>
                        </div>
                    </div>';
                echo $is_admin_bar;
            }
        }
    }

    /**
     * Render a global section
     */
    private function render_global_section($section_id) {
        // Verify section exists and is published
        $section = get_post($section_id);
        if (!$section || $section->post_status !== 'publish') {
            return '';
        }

        static $rendered_sections = [];
        if (isset($rendered_sections[$section_id])) {
            return ''; // Skip if already rendering this section
        }
        $rendered_sections[$section_id] = true;

        // Start output buffering
        ob_start();
        
        // Use Elementor's frontend
        if (class_exists('\Elementor\Plugin')) {
            $elementor = \Elementor\Plugin::instance();
            $content = $elementor->frontend->get_builder_content_for_display($section_id);
            return $content;
        }

        // Clean up
        unset($rendered_sections[$section_id]);
        
        return ob_get_clean();
    }

    private function register_default_groups() {
        $this->add_condition_group('general', [
            'label' => __('General', 'unistudio-core'),
            'priority' => 10,
        ]);

        $this->add_condition_group('archive', [
            'label' => __('Archive', 'unistudio-core'),
            'priority' => 20,
        ]);

        $this->add_condition_group('singular', [
            'label' => __('Singular', 'unistudio-core'),
            'priority' => 30,
        ]);

        $this->add_condition_group('user', [
            'label' => __('User', 'unistudio-core'),
            'priority' => 40,
        ]);
    }

    private function register_default_conditions() {
        // General conditions
        $this->add_condition('entire_site', [
            'group' => 'general',
            'label' => __('Entire Site', 'unistudio-core'),
            'callback' => function() {
                return true;
            },
        ]);

        $this->add_condition('front_page', [
            'group' => 'general',
            'label' => __('Front Page', 'unistudio-core'),
            'callback' => function() {
                return is_front_page();
            },
        ]);

        // Archive conditions
        $this->add_condition('all_archives', [
            'group' => 'archive',
            'label' => __('All Archives', 'unistudio-core'),
            'callback' => function() {
                return is_archive();
            },
        ]);

        $this->add_condition('post_type_archive', [
            'group' => 'archive',
            'label' => __('Post Type Archives', 'unistudio-core'),
            'callback' => function($args) {
                return isset($args['post_type']) && is_post_type_archive($args['post_type']);
            },
            'fields' => [
                'post_type' => [
                    'type' => 'select',
                    'label' => __('Post Type', 'unistudio-core'),
                    'options' => 'get_post_types',
                ],
            ],
        ]);

        // Singular conditions
        $this->add_condition('singular', [
            'group' => 'singular',
            'label' => __('All Singular', 'unistudio-core'),
            'callback' => function() {
                return is_singular();
            },
        ]);

        $this->add_condition('post_type', [
            'group' => 'singular',
            'label' => __('Post Type', 'unistudio-core'),
            'callback' => function($args) {
                return isset($args['post_type']) && is_singular($args['post_type']);
            },
            'fields' => [
                'post_type' => [
                    'type' => 'select',
                    'label' => __('Post Type', 'unistudio-core'),
                    'options' => 'get_post_types',
                ],
            ],
        ]);

        // User conditions
        $this->add_condition('logged_in', [
            'group' => 'user',
            'label' => __('Logged In', 'unistudio-core'),
            'callback' => function() {
                return is_user_logged_in();
            },
        ]);

        $this->add_condition('user_role', [
            'group' => 'user',
            'label' => __('User Role', 'unistudio-core'),
            'callback' => function($args) {
                if (!is_user_logged_in() || !isset($args['role'])) {
                    return false;
                }
                $user = wp_get_current_user();
                return in_array($args['role'], (array) $user->roles);
            },
            'fields' => [
                'role' => [
                    'type' => 'select',
                    'label' => __('Role', 'unistudio-core'),
                    'options' => 'get_user_roles',
                ],
            ],
        ]);
    }

    public function add_condition($id, $args) {
        $defaults = [
            'group' => 'general',
            'label' => '',
            'callback' => null,
            'fields' => [],
        ];

        $this->conditions[$id] = wp_parse_args($args, $defaults);
    }

    public function add_condition_group($id, $args) {
        $defaults = [
            'label' => '',
            'priority' => 10,
        ];

        $this->condition_groups[$id] = wp_parse_args($args, $defaults);
    }

    public function get_conditions() {
        return $this->conditions;
    }

    public function get_condition_groups() {
        return $this->condition_groups;
    }

    private function get_post_types() {
        $post_types = get_post_types(['public' => true], 'objects');
        $options = [];
        foreach ($post_types as $post_type) {
            $options[$post_type->name] = $post_type->labels->singular_name;
        }
        return $options;
    }

    private function get_user_roles() {
        global $wp_roles;
        return $wp_roles->get_names();
    }

    /**
     * Main function to check if a global section should be displayed based on its conditions
     */
    public function check_display_conditions($should_render, $section_id) {
        // First check if the section exists and is published
        $section = get_post($section_id);
        if (!$section || $section->post_status !== 'publish') {
            return false;
        }

        // Get the section type
        $terms = wp_get_post_terms($section_id, 'uc_section_type', ['fields' => 'slugs']);
        $section_type = !empty($terms) ? $terms[0] : '';

        // Get ACF field data for display conditions based on section type
        $display_conditions = [];

        switch ($section_type) {
            case 'header':
                $acf_conditions = get_field('gs_header_display_rules_display_conditions', $section_id);
                break;
            case 'footer':
                $acf_conditions = get_field('gs_footer_display_rules_display_conditions', $section_id);
                break;
            case 'pagecover':
                $acf_conditions = get_field('gs_pagecover_display_rules_display_conditions', $section_id);
                break;
            case 'offcanvas':
                $acf_conditions = get_field('gs_offcanvas_display_rules_display_conditions', $section_id);
                break;
            case 'popup':
                $acf_conditions = get_field('gs_popup_display_rules_display_conditions', $section_id);
                break;
            default:
                // For other section types, we'll return true
                return true;
        }

        // If no conditions are set, render the section
        if (empty($acf_conditions)) {
            return true;
        }

        // Track if we have any "include" type conditions
        $has_include = false;
        $include_match = false;
        $exclude_match = false;

        // Process each condition
        foreach ($acf_conditions as $condition) {
            $display_type = isset($condition['display_type']) ? $condition['display_type'] : 'include';
            $condition_type = isset($condition['condition_type']) ? $condition['condition_type'] : '';

            // Track if we have any include type
            if ($display_type === 'include') {
                $has_include = true;
            }

            // Skip if we're missing condition type
            if (empty($condition_type)) {
                continue;
            }

            // Check the condition based on type
            $matches = $this->check_condition_match($condition_type, $condition);
            
            // Process include/exclude
            if ($display_type === 'include' && $matches) {
                $include_match = true;
            } elseif ($display_type === 'exclude' && $matches) {
                $exclude_match = true;
            }
        }

        // If we have an exclude match, don't render
        if ($exclude_match) {
            return false;
        }

        // If we have include conditions but no match, don't render
        if ($has_include && !$include_match) {
            return false;
        }

        // In all other cases, render
        return true;
    }

    /**
     * Check if a specific condition matches the current context
     */
    private function check_condition_match($condition_type, $condition) {
        switch ($condition_type) {
            case 'entire_site':
                return true;

            case 'singular':
                if (!is_singular()) {
                    return false;
                }
                
                $options = isset($condition['singular_options']) ? (array)$condition['singular_options'] : [];
                
                if (empty($options)) {
                    return true;
                }
                
                $post_type = get_post_type();
                
                if (in_array('posts', $options) && $post_type === 'post') {
                    return true;
                }
                
                if (in_array('pages', $options) && $post_type === 'page') {
                    return true;
                }
                
                if (in_array('uc_portfolio', $options) && $post_type === 'uc_portfolio') {
                    return true;
                }
                
                return false;

            case 'archive':
                if (!is_archive() && !is_home() && !is_search()) {
                    return false;
                }
                
                $options = isset($condition['archive_options']) ? (array)$condition['archive_options'] : [];
                
                if (empty($options)) {
                    return true;
                }
                
                if (in_array('post_archive', $options) && (is_home() || is_category() || is_tag())) {
                    return true;
                }
                
                if (in_array('author_archive', $options) && is_author()) {
                    return true;
                }
                
                if (in_array('date_archive', $options) && is_date()) {
                    return true;
                }
                
                if (in_array('search_results', $options) && is_search()) {
                    return true;
                }
                
                if (in_array('uc_portfolio_archive', $options) && is_post_type_archive('uc_portfolio')) {
                    return true;
                }
                
                return false;

            case 'taxonomies':
                if (!is_tax() && !is_category() && !is_tag()) {
                    return false;
                }
                
                $options = isset($condition['taxonomy_options']) ? (array)$condition['taxonomy_options'] : [];
                
                if (empty($options)) {
                    return true;
                }
                
                if (in_array('category', $options) && is_category()) {
                    return true;
                }
                
                if (in_array('post_tag', $options) && is_tag()) {
                    return true;
                }
                
                if (in_array('uc_portfolio_category', $options) && is_tax('uc_portfolio_category')) {
                    return true;
                }
                
                if (in_array('uc_portfolio_tag', $options) && is_tax('uc_portfolio_tag')) {
                    return true;
                }
                
                return false;

            case 'specific_pages':
                if (!is_page()) {
                    return false;
                }
                
                $pages = isset($condition['specific_pages']) ? (array)$condition['specific_pages'] : [];
                
                if (empty($pages)) {
                    return false;
                }
                
                return in_array(get_the_ID(), $pages);

            case 'specific_posts':
                if (!is_single() || get_post_type() !== 'post') {
                    return false;
                }
                
                $posts = isset($condition['specific_posts']) ? (array)$condition['specific_posts'] : [];
                
                if (empty($posts)) {
                    return false;
                }
                
                return in_array(get_the_ID(), $posts);

            case 'specific_projects':
                if (!is_single() || get_post_type() !== 'uc_portfolio') {
                    return false;
                }
                
                $projects = isset($condition['specific_projects']) ? (array)$condition['specific_projects'] : [];
                
                if (empty($projects)) {
                    return false;
                }
                
                return in_array(get_the_ID(), $projects);

            case 'post_types':
                $post_types = isset($condition['post_types']) ? (array)$condition['post_types'] : [];
                
                if (empty($post_types)) {
                    return false;
                }
                
                return in_array(get_post_type(), $post_types);

            default:
                return false;
        }
    }
}