<?php

namespace UniStudioCore;
// Allow SVG
function uc_allow_svg_upload($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    $mimes['svgz'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'uc_allow_svg_upload', 99);

// Fix MIME type check
function uc_fix_mime_type_svg($data, $file, $filename, $mimes) {
    $filetype = wp_check_filetype($filename, $mimes);
    return [
        'ext' => $filetype['ext'],
        'type' => $filetype['type'],
        'proper_filename' => $filename
    ];
}
add_filter('wp_check_filetype_and_ext', 'uc_fix_mime_type_svg', 100, 4);

// Fix SVG dimensions
function uc_fix_svg_size_attributes($image_data) {
    if($image_data['mime'] === 'image/svg+xml') {
        if(empty($image_data['width']) && empty($image_data['height'])) {
            $svg = simplexml_load_file($image_data['url']);
            $attr = $svg->attributes();
            $viewbox = explode(' ', $attr->viewBox);
            $image_data['width'] = isset($attr->width) && preg_match('/\d+/', $attr->width, $value) ? (int) $value[0] : (count($viewbox) == 4 ? (int) $viewbox[2] : null);
            $image_data['height'] = isset($attr->height) && preg_match('/\d+/', $attr->height, $value) ? (int) $value[0] : (count($viewbox) == 4 ? (int) $viewbox[3] : null);
        }
    }
    return $image_data;
}
add_filter('wp_update_attachment_metadata', 'uc_fix_svg_size_attributes', 10, 2);

// Enable SVG preview
add_filter('wp_prepare_attachment_for_js', function($response) {
    if($response['mime'] === 'image/svg+xml') {
        $response['image'] = [
            'src' => $response['url']
        ];
    }
    return $response;
});