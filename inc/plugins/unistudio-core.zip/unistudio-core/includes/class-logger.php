<?php

namespace UniStudioCore;

class Logger {
    private static $instance = null;
    private $log_file;
    private $max_log_size = 5242880; // 5MB in bytes
    private $rotation_files = 5;
    
    public static function getInstance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $upload_dir = wp_upload_dir();
        $this->log_file = $upload_dir['basedir'] . '/unistudio-core/logs/unicore.log';
        
        // Create logs directory if it doesn't exist
        $log_dir = dirname($this->log_file);
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
        }

        // Add settings page hooks
        add_action('admin_menu', [$this, 'addLogsPage']);
        add_action('admin_post_clear_unicore_logs', [$this, 'clearLogs']);
        add_action('admin_post_download_unicore_logs', [$this, 'downloadLogs']);
    }

    /**
     * Log a message with a specific level
     */
    public function log($message, $level = 'info') {
        if (!is_string($message)) {
            $message = print_r($message, true);
        }

        $timestamp = current_time('Y-m-d H:i:s');
        $level = strtoupper($level);
        $log_entry = sprintf("[%s] [%s] %s\n", $timestamp, $level, $message);

        // Check file size and rotate if necessary
        $this->rotateLogFileIfNeeded();

        // Append to log file
        error_log($log_entry, 3, $this->log_file);
    }

    /**
     * Convenience methods for different log levels
     */
    public function info($message) {
        $this->log($message, 'INFO');
    }

    public function warning($message) {
        $this->log($message, 'WARNING');
    }

    public function error($message) {
        $this->log($message, 'ERROR');
    }

    public function debug($message) {
        if (WP_DEBUG) {
            $this->log($message, 'DEBUG');
        }
    }

    /**
     * Add logs page to admin menu
     */
    public function addLogsPage() {
        add_submenu_page(
            'unistudio-core-settings',
            __('System Logs', 'unistudio-core'),
            __('System Logs', 'unistudio-core'),
            'manage_options',
            'unistudio-core-logs',
            [$this, 'renderLogsPage']
        );
    }

    /**
     * Render the logs page
     */
    public function renderLogsPage() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $logs = $this->getLogs();
        $log_levels = ['all', 'info', 'warning', 'error', 'debug'];
        $current_level = isset($_GET['level']) ? sanitize_text_field($_GET['level']) : 'all';
        $lines_to_show = isset($_GET['lines']) ? intval($_GET['lines']) : 100;
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <div class="tablenav top">
                <div class="alignleft actions">
                    <form method="get" action="">
                        <input type="hidden" name="page" value="unistudio-core-logs">
                        
                        <select name="level">
                            <?php foreach ($log_levels as $level) : ?>
                                <option value="<?php echo esc_attr($level); ?>" 
                                        <?php selected($current_level, $level); ?>>
                                    <?php echo esc_html(ucfirst($level)); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        
                        <select name="lines">
                            <option value="50" <?php selected($lines_to_show, 50); ?>>Last 50 lines</option>
                            <option value="100" <?php selected($lines_to_show, 100); ?>>Last 100 lines</option>
                            <option value="200" <?php selected($lines_to_show, 200); ?>>Last 200 lines</option>
                            <option value="500" <?php selected($lines_to_show, 500); ?>>Last 500 lines</option>
                        </select>
                        
                        <input type="submit" class="button" value="<?php esc_attr_e('Filter', 'unistudio-core'); ?>">
                    </form>
                </div>
                
                <div class="alignright">
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                        <?php wp_nonce_field('unicore_download_logs'); ?>
                        <input type="hidden" name="action" value="download_unicore_logs">
                        <input type="submit" class="button" value="<?php esc_attr_e('Download Logs', 'unistudio-core'); ?>">
                    </form>
                    
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;">
                        <?php wp_nonce_field('unicore_clear_logs'); ?>
                        <input type="hidden" name="action" value="clear_unicore_logs">
                        <input type="submit" class="button" value="<?php esc_attr_e('Clear Logs', 'unistudio-core'); ?>"
                               onclick="return confirm('<?php esc_attr_e('Are you sure you want to clear all logs?', 'unistudio-core'); ?>');">
                    </form>
                </div>
            </div>

            <div class="log-viewer">
                <pre><?php
                if (empty($logs)) {
                    echo esc_html__('No logs found.', 'unistudio-core');
                } else {
                    $filtered_logs = $this->filterLogs($logs, $current_level, $lines_to_show);
                    echo esc_html($filtered_logs);
                }
                ?></pre>
            </div>
        </div>
        <style>
            .log-viewer {
                background: #fff;
                border: 1px solid #ccd0d4;
                padding: 20px;
                margin-top: 20px;
                overflow: auto;
            }
            .log-viewer pre {
                margin: 0;
                white-space: pre-wrap;
                word-wrap: break-word;
                font-family: monospace;
            }
        </style>
        <?php
    }

    /**
     * Get logs from file
     */
    private function getLogs() {
        if (!file_exists($this->log_file)) {
            return '';
        }
        return file_get_contents($this->log_file);
    }

    /**
     * Filter logs based on level and number of lines
     */
    private function filterLogs($logs, $level = 'all', $lines = 100) {
        $log_array = array_filter(explode("\n", $logs));
        
        if ($level !== 'all') {
            $level = strtoupper($level);
            $log_array = array_filter($log_array, function($line) use ($level) {
                return strpos($line, "[$level]") !== false;
            });
        }
        
        $log_array = array_slice($log_array, -$lines);
        return implode("\n", $log_array);
    }

    /**
     * Handle log file rotation
     */
    private function rotateLogFileIfNeeded() {
        if (!file_exists($this->log_file)) {
            return;
        }

        if (filesize($this->log_file) < $this->max_log_size) {
            return;
        }

        // Rotate existing backup files
        for ($i = $this->rotation_files - 1; $i >= 1; $i--) {
            $old_file = $this->log_file . '.' . $i;
            $new_file = $this->log_file . '.' . ($i + 1);
            if (file_exists($old_file)) {
                rename($old_file, $new_file);
            }
        }

        // Move current log to .1
        rename($this->log_file, $this->log_file . '.1');

        // Create new empty log file
        touch($this->log_file);
    }

    /**
     * Clear all logs
     */
    public function clearLogs() {
        check_admin_referer('unicore_clear_logs');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        file_put_contents($this->log_file, '');
        
        // Redirect back to logs page
        wp_redirect(add_query_arg(
            ['page' => 'unistudio-core-logs', 'cleared' => '1'],
            admin_url('admin.php')
        ));
        exit;
    }

    /**
     * Download logs
     */
    public function downloadLogs() {
        check_admin_referer('unicore_download_logs');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        $logs = $this->getLogs();
        $filename = 'unicore-logs-' . date('Y-m-d') . '.log';
        
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($logs));
        header('Connection: close');
        
        echo $logs;
        exit;
    }
}