<?php
namespace UniStudioCore;

use UniStudioCore\ElementorManager\Global_Sections_Manager;

class Global_Sections {
    private static $instance = null;
    private $global_sections_manager;
    private $display_conditions;
    
    public static function getInstance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Get Display Conditions instance
        $this->display_conditions = Display_Conditions::getInstance();

        // Initialize Global Sections Manager
        $this->global_sections_manager = Global_Sections_Manager::getInstance();

        // Add this hook to set default section type on new global sections
        add_action('wp_insert_post', [$this, 'set_default_section_type'], 10, 3);

        // Register post type and taxonomy first
        add_action('init', [$this, 'register_gs_post_type']);
        add_action('init', [$this, 'register_gs_taxonomies']);

        // Modify admin columns
        add_filter('manage_uc_global_sections_posts_columns', [$this, 'modify_columns']);
        add_action('manage_uc_global_sections_posts_custom_column', [$this, 'render_columns'], 10, 2);
        
        // Set columns order
        add_filter('manage_edit-uc_global_sections_sortable_columns', [$this, 'sortable_columns']);

        // Add "Back to List" button
        add_action('admin_print_scripts-post.php', [$this, 'add_back_to_list_button']);

        add_shortcode('uc_global_section', [$this, 'render_global_section_shortcode']);
        
        // Add necessary admin styles and scripts
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);

        // Then register with Elementor
        add_action('elementor/documents/register', [$this, 'register_elementor_document_type']);
        
        // Add menu hook
        add_action('polysaas_after_theme_settings_menu', [$this, 'add_to_theme_settings']);

        add_filter('template_include', [$this, 'set_elementor_canvas_template']);

        // Initialize additional functionality
        $this->init();

        // Add display conditions integration - now working with ACF fields
        $this->init_display_conditions();
    }

    public function init() {
        // Add Elementor hooks
        add_action('elementor/theme/register_locations', [$this, 'register_elementor_locations']);
        add_action('init', [$this, 'handle_preview_request']);
    }

    /**
     * Handle preview request and hide admin bar
     */
    public function handle_preview_request() {
        if (isset($_GET['uc_global_sections']) && isset($_GET['preview_frame'])) {
            // Force hide admin bar
            add_filter('show_admin_bar', '__return_false');
            
            // Remove admin bar styling
            remove_action('wp_head', '_admin_bar_bump_cb');
            
            // Optional: Add any custom preview styles
            add_action('wp_head', function() {
                ?>
                <style>
                    html { margin-top: 0 !important; }
                    body { background: transparent !important; }
                </style>
                <?php
            });
        }
    }

    /**
     * Set default section type for new global sections
     */
    public function set_default_section_type($post_id, $post, $update) {
        // Only run for new global sections
        if ($update || $post->post_type !== 'uc_global_sections') {
            return;
        }

        // Set the default ACF value
        if (function_exists('update_field')) {
            update_field('global_section_type', 'generic', $post_id);
        }

        // Set the default taxonomy term
        wp_set_object_terms($post_id, 'generic', 'uc_section_type');
    }

    private function init_display_conditions() {
        // Use the Display_Conditions class for checking conditions
        // The class now uses ACF fields for condition data
        
        // Register actions for theme template integration
        add_action('after_setup_theme', [$this, 'register_theme_display_hooks']);
    }
    
    /**
     * Register hooks to integrate with theme templates
     */
    public function register_theme_display_hooks() {
        // Add hooks for your theme templates here
        // These will delegate to the Display_Conditions class methods
        
        // Headers
        add_filter('polysaas_header_section', [$this, 'get_header_section'], 10);
        
        // Footers
        add_filter('polysaas_footer_section', [$this, 'get_footer_section'], 10);
        
        // Page Covers
        add_filter('polysaas_page_cover_section', [$this, 'get_page_cover_section'], 10);
        
        // Mega Menus integration
        add_filter('polysaas_mega_menu_section', [$this, 'get_mega_menu_section'], 10, 2);
    }
    
    /**
     * Get header section
     */
    public function get_header_section() {
        // Get the header section ID from theme settings
        $header_type = get_theme_mod('polysaas_header_layout_type', '_default');
        
        if ($header_type === '_gs') {
            $section_id = get_theme_mod('polysaas_header_layout_source', 0);
            if (!empty($section_id)) {
                return $section_id;
            }
        }
        
        return 0;
    }
    
    /**
     * Get footer section
     */
    public function get_footer_section() {
        // Get the footer section ID from theme settings
        $footer_type = get_theme_mod('polysaas_footer_layout_type', '_default');
        
        if ($footer_type === '_gs') {
            $section_id = get_theme_mod('polysaas_footer_layout_source', 0);
            if (!empty($section_id)) {
                return $section_id;
            }
        }
        
        return 0;
    }
    
    /**
     * Get page cover section
     */
    public function get_page_cover_section() {
        // Get page-specific cover section
        $page_id = get_the_ID();
        
        if (!$page_id) {
            return 0;
        }
        
        $header_layout = get_post_meta($page_id, 'page_header_layout', true);
        
        // If page cover is disabled, return 0
        if ($header_layout === 'disabled') {
            return 0;
        }
        
        $header_template = get_post_meta($page_id, 'page_header_template', true);
        
        // If using a global section template
        if ($header_template === 'custom') {
            $cover_id = get_post_meta($page_id, 'page_cover_override', true);
            if (!empty($cover_id)) {
                return $cover_id;
            }
        }
        
        // If no page-specific cover, check for defaults in theme settings
        $default_cover_type = get_theme_mod('polysaas_page_cover_type', '_default');
        
        if ($default_cover_type === '_gs') {
            return get_theme_mod('polysaas_page_cover_source', 0);
        }
        
        return 0;
    }
    
    /**
     * Get mega menu section by menu item ID
     */
    public function get_mega_menu_section($section_id, $menu_item_id) {
        // If section already set, return it
        if (!empty($section_id)) {
            return $section_id;
        }
        
        // Check for mega menu setting on this menu item
        $mega_menu_enabled = get_post_meta($menu_item_id, '_menu_item_mega_menu', true);
        
        if ($mega_menu_enabled) {
            $mega_menu_id = get_post_meta($menu_item_id, '_menu_item_mega_menu_id', true);
            if (!empty($mega_menu_id)) {
                return $mega_menu_id;
            }
        }
        
        return 0;
    }

    public function register_elementor_document_type($documents_manager) {
        // Register the document type
        $documents_manager->register_document_type(
            'uc_global_sections',
            \UniStudioCore\ElementorManager\Documents\Global_Section::class
        );

        // Associate our post type with the document type
        add_filter('elementor/document/config', function($config, $post_id) {
            if (get_post_type($post_id) === 'uc_global_sections') {
                $config['type'] = 'uc_global_sections';
            }
            return $config;
        }, 10, 2);
    }

    public function register_template_post_type($args) {
        $args['uc_global_sections'] = 'Global Section';
        return $args;
    }

    public function preview_styles($handles) {
        $handles[] = 'elementor-preview';
        return $handles;
    }

    public function add_to_theme_settings($parent_slug) {
        if (!$parent_slug) {
            return;
        }

        // Add Global Sections as submenu to theme settings
        add_submenu_page(
            $parent_slug,
            __('Global Sections', 'unistudio-core'),
            __('Global Sections', 'unistudio-core'),
            'manage_options',
            'edit.php?post_type=uc_global_sections'
        );
    }

    public function register_gs_post_type() {
        $labels = [
            'name'               => _x('Global Sections', 'post type general name', 'unistudio-core'),
            'singular_name'      => _x('Global Section', 'post type singular name', 'unistudio-core'),
            'menu_name'          => _x('Global Sections', 'admin menu', 'unistudio-core'),
            'name_admin_bar'     => _x('Global Section', 'add new on admin bar', 'unistudio-core'),
            'add_new'            => _x('Add New', 'global section', 'unistudio-core'),
            'add_new_item'       => __('Add New Global Section', 'unistudio-core'),
            'edit_item'          => __('Edit Global Section', 'unistudio-core'),
            'new_item'           => __('New Global Section', 'unistudio-core'),
            'view_item'          => __('View Global Section', 'unistudio-core'),
            'search_items'       => __('Search Global Sections', 'unistudio-core'),
            'not_found'          => __('No Global sections found', 'unistudio-core'),
            'not_found_in_trash' => __('No Global sections found in trash', 'unistudio-core'),
            'all_items'          => __('All Global Sections', 'unistudio-core'),
        ];
    
        $args = [
            'labels'              => $labels,
            'supports' => [
                'title',
                'elementor',
            ],
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'show_in_nav_menus' => true,
            'exclude_from_search' => true,
            'capability_type' => 'post',
            'hierarchical' => false,
            'has_archive' => false,
            'rewrite' => false,
            'query_var' => true,
            'can_export' => true,
            'delete_with_user' => false,
            'show_in_rest' => true,
        ];
    
        register_post_type('uc_global_sections', $args);
    }

    public function register_gs_taxonomies() {
        // Register Section Type Taxonomy
        register_taxonomy('uc_section_type', ['uc_global_sections'], [
            'labels' => [
                'name'              => _x('Section Types', 'taxonomy general name', 'unistudio-core'),
                'singular_name'     => _x('Section Type', 'taxonomy singular name', 'unistudio-core'),
                'search_items'      => __('Search Section Types', 'unistudio-core'),
                'all_items'         => __('All Section Types', 'unistudio-core'),
                'edit_item'         => __('Edit Section Type', 'unistudio-core'),
                'update_item'       => __('Update Section Type', 'unistudio-core'),
                'add_new_item'      => __('Add New Section Type', 'unistudio-core'),
                'new_item_name'     => __('New Section Type Name', 'unistudio-core'),
                'menu_name'         => __('Section Types', 'unistudio-core'),
            ],
            'hierarchical'      => true,
            'show_ui'           => false,
            'show_admin_column' => true,
            'show_in_menu'      => true,
            'query_var'         => true,
            'delete_with_user' => false,
            'rewrite'           => ['slug' => 'section-type'],
        ]);

        // Register default terms
        $this->register_default_terms();
    }

    private function register_default_terms() {
        $terms = [
            'generic' => __('Generic Section', 'unistudio-core'),
            'header' => __('Header', 'unistudio-core'),
            'footer' => __('Footer', 'unistudio-core'),
            'megamenu' => __('Mega Menu', 'unistudio-core'),
            'offcanvas' => __('Off Canvas', 'unistudio-core'),
            'popup' => __('Popup', 'unistudio-core'),
            'card' => __('Dynamic Card', 'unistudio-core'),
            'pagecover' => __('Page Cover', 'unistudio-core'),
        ];

        foreach ($terms as $slug => $name) {
            if (!term_exists($slug, 'uc_section_type')) {
                wp_insert_term($name, 'uc_section_type', [
                    'slug' => $slug
                ]);
            }
        }
    }

    public function register_template_type() {
        // Get the document types manager
        $types_manager = \Elementor\Plugin::$instance->documents;
    
        if ($types_manager) {
            // Register Global Section type
            $types_manager->register_document_type(
                'uc_global_sections',
                \UniStudioCore\ElementorManager\Documents\Global_Section::class
            );
        }
    }

    public function render_header($content) {
        $header_type = get_theme_mod('polysaas_header_layout_type', '_default');
        
        if ($header_type === '_gs') {
            $section_id = get_theme_mod('polysaas_header_layout_source');
            if ($section_id && $this->check_display_conditions(true, $section_id)) {
                $terms = wp_get_post_terms($section_id, 'uc_section_type', ['fields' => 'slugs']);
                if (!empty($terms) && in_array('header', $terms)) {
                    return $this->render_global_section($section_id);
                }
            }
        }
        
        return $content;
    }

    public function render_footer($content) {
        $footer_type = get_theme_mod('polysaas_footer_layout_type', '_default');
        
        if ($footer_type === '_gs') {
            $section_id = get_theme_mod('polysaas_footer_layout_source');
            if ($section_id && $this->check_display_conditions(true, $section_id)) {
                return $this->render_global_section($section_id);
            }
        }
        
        return $content;
    }

    public function render_global_section($section_id) {
    
        // Verify section exists and is published
        $section = get_post($section_id);
        if (!$section || $section->post_status !== 'publish') {
            return '';
        }
    
        // Get section type
        $section_type = $this->get_section_type($section_id);
    
        // Use Elementor's frontend directly
        if (class_exists('\Elementor\Plugin')) {
            $elementor = \Elementor\Plugin::instance();
            $content = $elementor->frontend->get_builder_content_for_display($section_id);
            
            if (empty($content)) {
                return '';
            }
            
            return $content;
        }
    
        return '';
    }

    private function get_section_type($section_id) {
        $terms = wp_get_post_terms($section_id, 'uc_section_type', ['fields' => 'slugs']);
        return !empty($terms) ? $terms[0] : '';
    }

    public function set_elementor_canvas_template( $template ) {
        if ( is_singular( 'uc_global_sections' ) ) {
            $elementor_canvas = locate_template( 'elementor-canvas.php' );
            
            if ( ! $elementor_canvas ) {
                $elementor_canvas = ELEMENTOR_PATH . 'modules/page-templates/templates/canvas.php';
            }
            
            if ( file_exists( $elementor_canvas ) ) {
                return $elementor_canvas;
            }
        }
        return $template;
    }

    /**
     * Legacy check display conditions method 
     * Now uses the Display_Conditions class
     */
    public function check_display_conditions($should_render, $section_id) {
        // First check if the section exists and is published
        $section = get_post($section_id);
        if (!$section || $section->post_status !== 'publish') {
            return false;
        }

        // Use our Display_Conditions class for checking conditions
        return $this->display_conditions->check_display_conditions($should_render, $section_id);
    }
    
    /**
     * Theme integration helper - renders header, footer, page cover sections
     * This is the main integration point to be used in theme templates
     */
    public function render_template_section($template_type, $content = '') {
        // Get section ID based on template type
        $section_id = 0;
        
        switch ($template_type) {
            case 'header':
                $section_id = apply_filters('polysaas_header_section', 0);
                break;
                
            case 'footer':
                $section_id = apply_filters('polysaas_footer_section', 0);
                break;
                
            case 'page_cover':
                $section_id = apply_filters('polysaas_page_cover_section', 0);
                break;
        }
        
        // If no section ID was found or section should not be displayed, return default content
        if (empty($section_id)) {
            return $content;
        }
        
        // Apply display conditions filter
        if (!$this->display_conditions->check_display_conditions(true, $section_id)) {
            return $content;
        }
        
        // Render the section
        $section_content = $this->render_global_section($section_id);
        
        if (!empty($section_content)) {
            return $section_content;
        }
        
        return $content;
    }

    public function register_elementor_locations($elementor_theme_manager) {
        $elementor_theme_manager->register_location('header');
        $elementor_theme_manager->register_location('footer');
        $elementor_theme_manager->register_location('megamenu');
        $elementor_theme_manager->register_location('card');
        $elementor_theme_manager->register_location('offcanvas');
        $elementor_theme_manager->register_location('popups');
        $elementor_theme_manager->register_location('pagecover');
    }

    /**
     * Render preview column content
     */
    public function render_preview_column($column, $post_id) {
        if ($column === 'uc_preview_column') {
            // Check if Elementor is active
            if (!did_action('elementor/loaded')) {
                printf(
                    '<span class="uc-notice uc-notice-warning">%s</span>',
                    esc_html__('Elementor is required to preview sections', 'unistudio-core')
                );
                return;
            }

            // Check if this post has Elementor content
            if (!get_post_meta($post_id, '_elementor_edit_mode', true)) {
                printf(
                    '<span class="uc-notice">%s</span>',
                    esc_html__('No Elementor content', 'unistudio-core')
                );
                return;
            }

            $preview_url = add_query_arg([
                'uc_global_sections' => get_post_field('post_name', $post_id),
                'preview_frame' => 1
            ], home_url('/'));
            
            $edit_url = add_query_arg([
                'post' => $post_id,
                'action' => 'elementor'
            ], admin_url('/post.php'));
            
            ?>
            <div class="uc-preview-iframe" data-id="<?php echo esc_attr($post_id); ?>">
                <a href="<?php echo esc_url($preview_url); ?>" class="button button-small btn" target="_blank">
                    <i class="icon dashicons dashicons-welcome-view-site"></i>
                    <span><?php _e('Preview', 'unistudio-core'); ?></span>
                </a>
                <div class="uc-preview-iframe-holder">
                    <iframe data-src="<?php echo esc_url($preview_url); ?>" 
                            frameborder="0" 
                            scrolling="no"></iframe>
                </div>
            </div>
            <div class="uc-elementor-edit">
                <a title="<?php esc_attr_e(__('Edit with Elementor', 'unistudio-core' )) ?>" href="<?php echo esc_url($edit_url); ?>" class="button button-small" target="_blank">
                    <i class="icon dashicons dashicons-edit"></i>
                </a>
            </div>
            <?php
        }
    }

    /**
     * Modify admin columns
     */
    public function modify_columns($columns) {
        $new_columns = [];
        
        // Checkbox should always be first
        if (isset($columns['cb'])) {
            $new_columns['cb'] = $columns['cb'];
        }
        
        // Set the order of columns
        $new_columns['title'] = $columns['title'];
        $new_columns['taxonomy-uc_section_type'] = __('Section Type', 'unistudio-core');
        $new_columns['shortcode'] = __('Shortcode', 'unistudio-core');
        $new_columns['uc_preview_column'] = __('Quick Preview', 'unistudio-core');
        $new_columns['date'] = $columns['date'];
        
        return $new_columns;
    }

    /**
     * Render column content
     */
    public function render_columns($column, $post_id) {
        switch ($column) {
            case 'shortcode':
                $shortcode = sprintf('[uc_global_section id="%d"]', $post_id);
                ?>
                <div class="uc-shortcode-field">
                    <input type="text" 
                        value="<?php echo esc_attr($shortcode); ?>" 
                        readonly 
                        class="uc-shortcode-input" 
                        onclick="this.select()">
                    <button type="button" 
                            class="button button-small uc-copy-shortcode" 
                            data-shortcode="<?php echo esc_attr($shortcode); ?>">
                        <span class="dashicons dashicons-clipboard"></span>
                    </button>
                </div>
                <?php
                break;

            case 'uc_preview_column':
                // Your existing preview column code
                $this->render_preview_column($column, $post_id);
                break;
        }
    }

    /**
     * Make columns sortable
     */
    public function sortable_columns($columns) {
        $columns['taxonomy-uc_section_type'] = 'taxonomy-uc_section_type';
        return $columns;
    }

    /**
     * Add "Back to List" button on edit page
     */
    public function add_back_to_list_button() {
        global $post_type;
        
        // Only add for our post type
        if ($post_type !== 'uc_global_sections') {
            return;
        }
    
        add_action('admin_footer', function() {
            ?>
            <script>
            document.addEventListener('DOMContentLoaded', function() {
                const titleAction = document.querySelector('.page-title-action');
                if (titleAction) {
                    const backButton = document.createElement('a');
                    backButton.href = '<?php echo esc_url(admin_url('edit.php?post_type=uc_global_sections')); ?>';
                    backButton.className = 'page-title-action';
                    backButton.textContent = '<?php echo esc_js(__('Back to List', 'unistudio-core')); ?>';
                    
                    titleAction.insertAdjacentElement('afterend', backButton);
                }
            });
            </script>
            <?php
        });
    }

    /**
     * Render Global Section shortcode
     */
    public function render_global_section_shortcode($atts) {
        // Parse attributes
        $atts = shortcode_atts([
            'id' => 0
        ], $atts);

        $section_id = intval($atts['id']);
        
        // Validate section exists and is published
        $section = get_post($section_id);
        if (!$section || $section->post_status !== 'publish' || $section->post_type !== 'uc_global_sections') {
            return '';
        }

        // Prevent infinite loops
        static $rendered_sections = [];
        if (isset($rendered_sections[$section_id])) {
            return ''; // Skip if already rendering this section
        }
        $rendered_sections[$section_id] = true;

        // Start output buffering
        ob_start();

        // Check if Elementor is active
        if (class_exists('\Elementor\Plugin')) {
            $elementor = \Elementor\Plugin::instance();
            echo $elementor->frontend->get_builder_content_for_display($section_id);
        }

        // Clean up
        unset($rendered_sections[$section_id]);

        // Return the buffered content
        return ob_get_clean();
    }

    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        if ($hook !== 'edit.php' || get_current_screen()->post_type !== 'uc_global_sections') {
            return;
        }

        // Enqueue styles
        wp_enqueue_style(
            'uc-admin-gs-preview',
            UC_URL . 'assets/css/admin/cpt-gs.css',
            [],
            UC_VERSION
        );

        // Enqueue scripts
        wp_enqueue_script(
            'uc-admin-gs-preview',
            UC_URL . 'assets/js/admin/cpt-gs.js',
            ['jquery'],
            UC_VERSION,
            true
        );
    }
}