<?php

namespace UniStudioCore;

class Asset_Manager {
    private static $instance = null;
    private $registered_scripts = [];
    private $registered_styles = [];
    
    public static function getInstance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'register_core_assets']);
    }

    public function register_core_assets() {
        // Register core assets that might be needed by multiple widgets
        wp_register_script(
            'uc-core',
            UC_URL . 'assets/js/core.min.js',
            ['jquery'],
            UC_VERSION,
            true
        );

        wp_register_style(
            'uc-core',
            UC_URL . 'assets/css/core.min.css',
            [],
            UC_VERSION
        );
    }

    public function register_widget_script($handle, $relative_path, $deps = ['jquery'], $in_footer = true) {
        if (!isset($this->registered_scripts[$handle])) {
            wp_register_script(
                $handle,
                UC_URL . $relative_path,
                $deps,
                UC_VERSION,
                $in_footer
            );
            $this->registered_scripts[$handle] = true;
        }
    }

    public function register_widget_style($handle, $relative_path, $deps = []) {
        if (!isset($this->registered_styles[$handle])) {
            wp_register_style(
                $handle,
                UC_URL . $relative_path,
                $deps,
                UC_VERSION
            );
            $this->registered_styles[$handle] = true;
        }
    }

    public function is_script_registered($handle) {
        return isset($this->registered_scripts[$handle]);
    }

    public function is_style_registered($handle) {
        return isset($this->registered_styles[$handle]);
    }
}