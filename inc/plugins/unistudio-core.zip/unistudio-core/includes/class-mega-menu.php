<?php

namespace UniStudioCore;

class Mega_Menu {
    private static $instance = null;
    
    public static function getInstance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('wp_nav_menu_item_custom_fields', [$this, 'add_mega_menu_fields'], 10, 4);
        add_action('wp_update_nav_menu_item', [$this, 'save_mega_menu_fields'], 10, 3);
        add_filter('nav_menu_link_attributes', [$this, 'modify_nav_menu_link'], 10, 3);
    }

    public function add_mega_menu_fields($item_id, $item, $depth, $args) {
        $mega_menu_enabled = get_post_meta($item_id, '_uc_mega_menu_enabled', true);
        $mega_menu_id = get_post_meta($item_id, '_uc_mega_menu_id', true);

        // Get all mega menu posts
        $mega_menus = get_posts([
            'post_type' => 'uc_global_sections',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'tax_query' => [
                [
                    'taxonomy' => 'uc_section_type',
                    'field' => 'slug',
                    'terms' => 'megamenu',
                ]
            ]
        ]);

        ?>
        <p class="field-mega-menu description description-wide">
            <label>
                <input type="checkbox" 
                       name="uc_mega_menu_enabled[<?php echo $item_id; ?>]" 
                       value="1" 
                       <?php checked($mega_menu_enabled, 1); ?> />
                <?php _e('Enable Mega Menu', 'unistudio-core'); ?>
            </label>
        </p>
        <p class="field-mega-menu-content description description-wide">
            <label>
                <?php _e('Select Mega Menu Content', 'unistudio-core'); ?><br>
                <select name="uc_mega_menu_id[<?php echo $item_id; ?>]" class="widefat">
                    <option value=""><?php _e('-- Select --', 'unistudio-core'); ?></option>
                    <?php foreach ($mega_menus as $mega_menu) : ?>
                        <option value="<?php echo $mega_menu->ID; ?>" <?php selected($mega_menu_id, $mega_menu->ID); ?>>
                            <?php echo esc_html($mega_menu->post_title); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </label>
        </p>
        <?php
    }

    public function save_mega_menu_fields($menu_id, $menu_item_db_id, $menu_item_args) {
        if (isset($_POST['uc_mega_menu_enabled'][$menu_item_db_id])) {
            update_post_meta($menu_item_db_id, '_uc_mega_menu_enabled', 1);
        } else {
            delete_post_meta($menu_item_db_id, '_uc_mega_menu_enabled');
        }

        if (isset($_POST['uc_mega_menu_id'][$menu_item_db_id])) {
            update_post_meta($menu_item_db_id, '_uc_mega_menu_id', $_POST['uc_mega_menu_id'][$menu_item_db_id]);
        }
    }

    public function modify_nav_menu_link($atts, $item, $args) {
        $mega_menu_enabled = get_post_meta($item->ID, '_uc_mega_menu_enabled', true);
        $mega_menu_id = get_post_meta($item->ID, '_uc_mega_menu_id', true);

        if ($mega_menu_enabled && $mega_menu_id) {
            $atts['class'] = isset($atts['class']) ? $atts['class'] . ' uc-has-mega-menu' : 'uc-has-mega-menu';
            $atts['data-mega-menu-id'] = $mega_menu_id;
        }

        return $atts;
    }

    public function get_mega_menu_content($menu_id) {
        if (!$menu_id) return '';

        if (class_exists('\Elementor\Plugin')) {
            $elementor = \Elementor\Plugin::instance();
            $content = $elementor->frontend->get_builder_content($menu_id, true);
            return $content;
        }

        return get_post_field('post_content', $menu_id);
    }
}