<?php
namespace UniStudioCore;

use Elementor\Plugin as ElementorPlugin;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;
use UniStudioCore\ElementorManager\Widgets;
use UniStudioCore\ElementorManager\DynamicTags;
use UniStudioCore\ElementorManager\Global_Sections_Manager;

class ElementorManager {
    private static $instance = null;
    private $category_prefix = 'uc-';
    private $settings;
    private $asset_manager;
    private $global_sections_manager;
    
    private $widgets = [
        'accordion' =>          Widgets\Accordion::class,
        'heading' =>            Widgets\Heading::class,
        'header' =>             Widgets\Header::class,
        'logo' =>               Widgets\Logo::class,
        'menu' =>               Widgets\Menu::class,
        'button' =>             Widgets\Button::class,
        'tabs' =>               Widgets\Tabs::class,
        'slider' =>             Widgets\Slider::class,
        'icon_box' =>           Widgets\Icon_Box::class,
        'image_box' =>          Widgets\Image_Box::class,
        'animated_text' =>      Widgets\Animated_Text::class,
        'marquee_text' =>       Widgets\Marquee_Text::class,
        'portfolio_grid' =>     Widgets\Portfolio_Grid::class,
        'team' =>               Widgets\Team::class,
        'team_slider' =>        Widgets\Team_Slider::class,
        'testimonials' =>       Widgets\Testimonials::class,
        'price_table' =>        Widgets\Price_Table::class,
    ];
    
    private $dynamic_tags = [
        'site_logo' =>              DynamicTags\Site_Logo::class,
        'global_section' =>         DynamicTags\Global_Section::class,
        'offcanvas' =>              DynamicTags\Offcanvas::class,
        'popup' =>                  DynamicTags\Popup::class,
        'archive_title' =>          DynamicTags\Archive_Title::class,
        'featured_image' =>         DynamicTags\Featured_Image::class,
        'post_title' =>             DynamicTags\Post_Title::class,
        'post_url' =>               DynamicTags\Post_URL::class,
        'post_excerpt' =>           DynamicTags\Post_Excerpt::class,
        'post_date' =>              DynamicTags\Post_Date::class,
        'post_author' =>            DynamicTags\Post_Author::class,
        'post_terms' =>             DynamicTags\Post_Terms::class,
        'post_comments_count' =>    DynamicTags\Post_Comments_Count::class,
        // 'post_custom_field' =>      DynamicTags\Post_Custom_Field::class,
        'author_info' =>            DynamicTags\Author_Info::class,
        'related_posts' =>          DynamicTags\Related_Posts::class,
        'post_reading_time' =>      DynamicTags\Post_Reading_Time::class,
        // 'counter' =>                DynamicTags\Counter::class,
    ];
    
    public static function getInstance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->settings = Settings::getInstance();
        $this->asset_manager = Asset_Manager::getInstance();
        $this->global_sections_manager = Global_Sections_Manager::getInstance();
        
        // Register Custom Widgets
        add_action('elementor/widgets/register', [$this, 'registerWidgets']);
        add_action('elementor/elements/categories_registered', [$this, 'addWidgetCategory']);

        // Register Custom Dynamic Tags
        add_action('elementor/dynamic_tags/register', [$this, 'registerDynamicTags']);
        add_action('wp_ajax_uc_get_posts_by_type', [$this, 'getPostsByType']);
        
        // Register Assets
        add_action('elementor/frontend/after_register_scripts', [$this, 'register_widget_scripts']);
        add_action('elementor/frontend/after_register_styles', [$this, 'register_widget_styles']);
        add_action('elementor/editor/before_enqueue_scripts', [$this, 'enqueueEditorScripts']);
        add_action('elementor/editor/after_enqueue_scripts', [$this, 'enqueueEditorScriptsAfter']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_frontend_scripts']);

        // Add Unicons to the Elementor's Library
        add_filter('elementor/icons_manager/additional_tabs', [$this, 'addUniconsTab']);
        add_action('elementor/frontend/after_enqueue_styles', [$this, 'enqueueUnicons']);
        add_action('elementor/editor/after_enqueue_styles', [$this, 'enqueueUnicons']);
    }

    public function enqueue_frontend_scripts() {
        wp_enqueue_script(
            'uc-dynamic-tags-frontend',
            UC_URL . 'assets/js/elementor/dynamic-tags.js',
            ['jquery'],
            UC_VERSION,
            true
        );
    }

    public function enqueueEditorScriptsAfter() {
        wp_enqueue_script(
            'uc-dynamic-tags',
            UC_URL . 'assets/js/elementor/dynamic-tags.js',
            ['jquery', 'elementor-editor'],
            UC_VERSION,
            true
        );
    }

    public function getPostsByType() {
        check_ajax_referer('elementor-editing', '_nonce');

        if (!isset($_POST['post_type'])) {
            wp_send_json_error('No post type specified');
        }

        $post_type = sanitize_text_field($_POST['post_type']);
        
        $args = [
            'post_type' => $post_type,
            'posts_per_page' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
        ];

        $posts = get_posts($args);

        $options = [];
        foreach ($posts as $post) {
            $options[] = [
                'id' => $post->ID,
                'text' => $post->post_title
            ];
        }

        wp_send_json_success($options);
    }
    
    public function registerDynamicTags($dynamic_tags_manager) {
        // Include and register each dynamic tag
        foreach ($this->dynamic_tags as $tag_id => $tag_class) {
            $dynamic_tags_manager->register(new $tag_class());
        }

        // Register tag group
        ElementorPlugin::$instance->dynamic_tags->register_group('uc-dynamic-tags', [
            'title' => __('UC - General', 'unistudio-core')
        ]);

        // Register tag group
        ElementorPlugin::$instance->dynamic_tags->register_group('uc-dynamic-tags-archive', [
            'title' => __('UC - Archive', 'unistudio-core')
        ]);

        // Register tag group
        ElementorPlugin::$instance->dynamic_tags->register_group('uc-dynamic-tags-post', [
            'title' => __('UC - Post', 'unistudio-core')
        ]);

        // Register tag group
        ElementorPlugin::$instance->dynamic_tags->register_group('uc-dynamic-tags-actions', [
            'title' => __('UC - Actions', 'unistudio-core')
        ]);
    }
    
    public function enqueueUnicons() {
        wp_enqueue_style(
            'unicons',
            UC_URL . 'assets/css/unicons.min.css',
            [],
            UC_VERSION
        );

        $custom_css = '
            .elementor-icons-manager__tab__item__icon.unicon-:before {
                font-family: "Unicons" !important;
            }
            [class^="unicon-"]:before, 
            [class*=" unicon-"]:before {
                font-family: "Unicons" !important;
            }
        ';
        wp_add_inline_style('unicons', $custom_css);
    }

    public function addUniconsTab($tabs) {
        $tabs['unicons'] = [
            'name'          => 'unicons',
            'label'         => esc_html__('Unicons', 'unistudio-core'),
            'prefix'        => 'unicon-',
            'displayPrefix' => '',
            'labelIcon'     => 'unicon-package',
            'ver'          => UC_VERSION,
            'icons'        => $this->getUniconsList(),
            'native'       => true,
        ];
        
        return $tabs;
    }

    private function getUniconsList() {
        $icons = [];
        $pattern = '/\.unicon-([\w-]+):before\s*{\s*content:/';
        
        $css_file = file_get_contents(UC_PATH . 'assets/css/unicons.min.css');
        preg_match_all($pattern, $css_file, $matches);
        
        return !empty($matches[1]) ? $matches[1] : [];
    }

    public function registerWidgets($widgets_manager) {
        foreach ($this->widgets as $widget_id => $widget_class) {
            if ($this->settings->isEnabled('widget_' . $widget_id)) {
                $widgets_manager->register(new $widget_class());
            }
        }
    }

    public function register_widget_scripts() {
        foreach ($this->widgets as $widget_id => $widget_class) {
            if ($this->settings->isEnabled('widget_' . $widget_id)) {
                $widget = new $widget_class();
                if (method_exists($widget, 'register_widget_scripts')) {
                    $widget->register_widget_scripts();
                }
            }
        }
    }

    public function register_widget_styles() {
        foreach ($this->widgets as $widget_id => $widget_class) {
            if ($this->settings->isEnabled('widget_' . $widget_id)) {
                $widget = new $widget_class();
                if (method_exists($widget, 'register_widget_styles')) {
                    $widget->register_widget_styles();
                }
            }
        }
    }

    public function enqueueEditorScripts() {
        foreach ($this->widgets as $widget_id => $widget_class) {
            if ($this->settings->isEnabled('widget_' . $widget_id)) {
                $widget = new $widget_class();
                if (method_exists($widget, 'enqueueEditorScripts')) {
                    $widget->enqueueEditorScripts();
                }
            }
        }
    }
    
    public function addWidgetCategory($elements_manager) {
        $elements_manager->add_category(
            $this->category_prefix . 'elements',
            [
                'title' => __('UniStudio Core Elements', 'unistudio-core'),
                'icon' => 'fa fa-plug',
            ]
        );

        // Reorder categories using Reflection
        $reflection = new \ReflectionClass($elements_manager);
        $property = $reflection->getProperty('categories');
        $property->setAccessible(true);
        
        $categories = $property->getValue($elements_manager);
        
        $category_order = [
            'layout',
            'uc-elements',
            'basic',
            'pro',
            'general'
        ];
        
        uksort($categories, function($key_one, $key_two) use ($category_order) {
            $pos_1 = array_search($key_one, $category_order);
            $pos_2 = array_search($key_two, $category_order);
            
            if ($pos_1 !== false && $pos_2 !== false) {
                return $pos_1 - $pos_2;
            }
            
            if ($pos_1 !== false) {
                return -1;
            }
            
            if ($pos_2 !== false) {
                return 1;
            }
            
            return 0;
        });
        
        $property->setValue($elements_manager, $categories);
    }
}