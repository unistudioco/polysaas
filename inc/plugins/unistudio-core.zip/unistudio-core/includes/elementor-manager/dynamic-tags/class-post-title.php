<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Tag;
use Elementor\Controls_Manager;

class Post_Title extends Tag {
    public function get_name() {
        return 'uc-post-title';
    }

    public function get_title() {
        return __('Post Title', 'unistudio-core');
    }

    public function get_group() {
        return 'uc-dynamic-tags-post';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }

    protected function register_controls() {
        $this->add_control(
            'post_id',
            [
                'label' => __('Post', 'unistudio-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'default' => '',
                'options' => $this->get_posts_options(),
            ]
        );
    }

    private function get_posts_options() {
        $options = ['' => __('Current Post', 'unistudio-core')];
        
        $posts = get_posts([
            'post_type' => ['post', 'page', 'portfolio'],
            'posts_per_page' => -1,
        ]);

        foreach ($posts as $post) {
            $options[$post->ID] = $post->post_title;
        }

        return $options;
    }

    public function render() {
        $post_id = $this->get_settings('post_id');
        
        if (!$post_id) {
            $post_id = get_the_ID();
        }
        
        if ($post_id) {
            echo get_the_title($post_id);
        }
    }
}