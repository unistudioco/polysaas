<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Tag;
use Elementor\Controls_Manager;

class Archive_Title extends Tag {
    public function get_name() {
        return 'uc-archive-title';
    }

    public function get_title() {
        return __('Archive Title', 'polysaas');
    }

    public function get_group() {
        return 'uc-dynamic-tags-archive';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }

    protected function register_controls() {
        $this->add_control(
            'include_context',
            [
                'label' => __('Include Context', 'polysaas'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'description' => __('For example: "Category: Business" or just "Business"', 'polysaas'),
            ]
        );
        
        $this->add_control(
            'show_description',
            [
                'label' => __('Show Description', 'polysaas'),
                'type' => Controls_Manager::SWITCHER,
                'default' => '',
            ]
        );
    }

    public function render() {
        $settings = $this->get_settings_for_display();
        $include_context = 'yes' === $settings['include_context'];
        $show_description = 'yes' === $settings['show_description'];
        
        if (is_search()) {
            $title = sprintf(
                __('Search Results for: %s', 'polysaas'),
                '<span>' . get_search_query() . '</span>'
            );
        } elseif (is_404()) {
            $title = __('Page Not Found', 'polysaas');
        } elseif (is_home() && !is_front_page()) {
            $title = single_post_title('', false);
        } elseif (is_front_page()) {
            $title = get_bloginfo('name');
        } elseif (is_archive()) {
            // Get title based on the archive type
            if ($include_context) {
                $title = get_the_archive_title();
            } else {
                // Remove the archive context
                if (is_category()) {
                    $title = single_cat_title('', false);
                } elseif (is_tag()) {
                    $title = single_tag_title('', false);
                } elseif (is_author()) {
                    $title = get_the_author();
                } elseif (is_year()) {
                    $title = get_the_date(_x('Y', 'yearly archives date format', 'polysaas'));
                } elseif (is_month()) {
                    $title = get_the_date(_x('F Y', 'monthly archives date format', 'polysaas'));
                } elseif (is_day()) {
                    $title = get_the_date();
                } elseif (is_tax()) {
                    $title = single_term_title('', false);
                } elseif (is_post_type_archive()) {
                    $title = post_type_archive_title('', false);
                } else {
                    $title = get_the_archive_title();
                }
            }
        } else {
            $title = get_the_title();
        }
        
        echo $title;
        
        if ($show_description && is_archive()) {
            $description = get_the_archive_description();
            if ($description) {
                echo '<div class="archive-description">' . wp_kses_post($description) . '</div>';
            }
        }
    }
}