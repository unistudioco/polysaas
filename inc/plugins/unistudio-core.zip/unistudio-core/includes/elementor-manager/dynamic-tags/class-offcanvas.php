<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use Elementor\Core\DynamicTags\Tag;
use Elementor\Modules\DynamicTags\Module as TagsModule;

class Offcanvas extends Tag {
    public function get_name() {
        return 'uc-offcanvas-trigger';
    }

    public function get_title() {
        return __('Offcanvas Trigger', 'unistudio-core');
    }

    public function get_group() {
        return 'uc-dynamic-tags-actions';
    }

    public function get_categories() {
        return [TagsModule::URL_CATEGORY];
    }

    protected function register_controls() {
        $this->add_control(
            'section_id',
            [
                'label' => __('Offcanvas Section', 'unistudio-core'),
                'type' => 'select',
                'options' => $this->get_offcanvas_sections(),
            ]
        );
    }

    private function get_offcanvas_sections() {
        $sections = [];
        
        // Get all published offcanvas sections
        $offcanvas_panels = get_posts([
            'post_type' => 'uc_global_sections',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'tax_query' => [
                [
                    'taxonomy' => 'uc_section_type',
                    'field' => 'slug',
                    'terms' => 'offcanvas',
                ]
            ]
        ]);

        foreach ($offcanvas_panels as $panel) {
            $sections[$panel->ID] = $panel->post_title;
        }
        
        return $sections;
    }

    /**
     * Render the tag output - this outputs the URL
     */
    public function render() {
        $section_id = $this->get_settings('section_id');
        
        if (!$section_id) {
            echo '#';
            return;
        }

        // Output the URL that will be intercepted by our JS or used directly by UIkit
        echo '#uc-offcanvas-' . esc_attr($section_id);
    }
}