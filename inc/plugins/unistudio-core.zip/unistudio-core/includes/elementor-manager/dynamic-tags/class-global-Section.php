<?php

namespace UniStudioCore\ElementorManager\DynamicTags;

use Elementor\Core\DynamicTags\Tag;
use Elementor\Modules\DynamicTags\Module as TagsModule;

class Global_Section extends Tag {
    public function get_name() {
        return 'global-section';
    }

    public function get_title() {
        return __('Global Section', 'unistudio-core');
    }

    public function get_group() {
        return 'uc-dynamic-tags';
    }

    public function get_categories() {
        return [TagsModule::TEXT_CATEGORY];
    }

    protected function register_controls() {
        $this->add_control(
            'section_id',
            [
                'label' => __('Select Global Section', 'unistudio-core'),
                'type' => 'select2',
                'label_block' => 'true',
                'options' => $this->get_global_sections_list(),
            ]
        );
    }

    private function get_global_sections_list() {
        $sections = [];
        
        $query = new \WP_Query([
            'post_type' => 'uc_global_sections',
            'posts_per_page' => -1,
            'post_status' => 'publish',
        ]);

        foreach ($query->posts as $post) {
            $sections[$post->ID] = $post->post_title;
        }

        return $sections;
    }

    public function render() {
        $section_id = $this->get_settings('section_id');
        if (!$section_id) {
            return;
        }

        echo do_shortcode("[uc_global_section id=\"{$section_id}\"]");
    }
}