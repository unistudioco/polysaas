<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Tag;
use Elementor\Controls_Manager;

class Post_Reading_Time extends Tag {
    public function get_name() {
        return 'uc-post-reading-time';
    }

    public function get_title() {
        return __('Post Reading Time', 'polysaas');
    }

    public function get_group() {
        return 'uc-dynamic-tags-post';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }

    protected function register_controls() {
        $this->add_control(
            'words_per_minute',
            [
                'label' => __('Words Per Minute', 'polysaas'),
                'type' => Controls_Manager::NUMBER,
                'default' => 200,
                'min' => 100,
                'max' => 300,
                'step' => 10,
                'description' => __('Average reading speed (words per minute)', 'polysaas'),
            ]
        );
        
        $this->add_control(
            'format',
            [
                'label' => __('Format', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => 'minutes',
                'options' => [
                    'minutes' => __('X Min Read', 'polysaas'),
                    'detailed' => __('X Min Y Sec Read', 'polysaas'),
                    'seconds' => __('Total Seconds', 'polysaas'),
                    'custom' => __('Custom Format', 'polysaas'),
                ],
            ]
        );
        
        $this->add_control(
            'custom_format',
            [
                'label' => __('Custom Format', 'polysaas'),
                'type' => Controls_Manager::TEXT,
                'default' => '{minutes} min read',
                'placeholder' => '{minutes} min read',
                'description' => __('Use {minutes}, {seconds}, and {total_seconds} as placeholders', 'polysaas'),
                'condition' => [
                    'format' => 'custom',
                ],
            ]
        );
        
        $this->add_control(
            'include_images',
            [
                'label' => __('Include Images in Calculation', 'polysaas'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
                'description' => __('Add extra time for images in content', 'polysaas'),
            ]
        );
        
        $this->add_control(
            'icon',
            [
                'label' => __('Prefix Icon', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => __('None', 'polysaas'),
                    'clock' => __('Clock', 'polysaas'),
                    'hourglass' => __('Hourglass', 'polysaas'),
                    'book' => __('Book', 'polysaas'),
                ],
            ]
        );
    }

    public function render() {
        $settings = $this->get_settings_for_display();
        $post_id = get_the_ID();
        
        if (!$post_id) {
            return;
        }
        
        $words_per_minute = intval($settings['words_per_minute']);
        $include_images = 'yes' === $settings['include_images'];
        
        // Get post content
        $post = get_post($post_id);
        $content = $post->post_content;
        
        // Count words
        $word_count = str_word_count(strip_tags($content));
        
        // Basic reading time calculation in seconds
        $reading_time_seconds = floor($word_count / ($words_per_minute / 60));
        
        // Add time for images if enabled
        if ($include_images) {
            // Count images in content
            $image_count = substr_count($content, '<img');
            
            // Add 3 seconds per image to reading time
            $reading_time_seconds += ($image_count * 3);
        }
        
        // Format the reading time
        $format = $settings['format'];
        $minutes = floor($reading_time_seconds / 60);
        $seconds = $reading_time_seconds % 60;
        
        // Add icon if selected
        $icon_html = '';
        if (!empty($settings['icon'])) {
            switch ($settings['icon']) {
                case 'clock':
                    $icon_html = '<i class="far fa-clock" aria-hidden="true"></i> ';
                    break;
                case 'hourglass':
                    $icon_html = '<i class="fas fa-hourglass-half" aria-hidden="true"></i> ';
                    break;
                case 'book':
                    $icon_html = '<i class="fas fa-book" aria-hidden="true"></i> ';
                    break;
            }
        }
        
        // Generate output based on format
        switch ($format) {
            case 'minutes':
                // Round up to the nearest minute for better readability
                $minutes = max(1, ceil($reading_time_seconds / 60));
                $output = sprintf(_n('%d min read', '%d min read', $minutes, 'polysaas'), $minutes);
                break;
                
            case 'detailed':
                $output = '';
                if ($minutes > 0) {
                    $output .= sprintf(_n('%d min', '%d min', $minutes, 'polysaas'), $minutes);
                }
                
                if ($seconds > 0 || $minutes === 0) {
                    if ($minutes > 0) {
                        $output .= ' ';
                    }
                    $output .= sprintf(_n('%d sec', '%d sec', $seconds, 'polysaas'), $seconds);
                }
                
                $output .= ' ' . __('read', 'polysaas');
                break;
                
            case 'seconds':
                $output = sprintf(_n('%d second read', '%d second read', $reading_time_seconds, 'polysaas'), $reading_time_seconds);
                break;
                
            case 'custom':
                $custom_format = $settings['custom_format'];
                $output = strtr($custom_format, [
                    '{minutes}' => $minutes,
                    '{seconds}' => $seconds,
                    '{total_seconds}' => $reading_time_seconds,
                ]);
                break;
                
            default:
                $output = sprintf(_n('%d min read', '%d min read', $minutes, 'polysaas'), $minutes);
                break;
        }
        
        echo $icon_html . $output;
    }
}