<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Tag;
use Elementor\Controls_Manager;

class Post_Comments_Count extends Tag {
    public function get_name() {
        return 'uc-post-comments-count';
    }

    public function get_title() {
        return __('Post Comments Count', 'polysaas');
    }

    public function get_group() {
        return 'uc-dynamic-tags-post';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }

    protected function register_controls() {
        
    }

    public function render() {
        $settings = $this->get_settings_for_display();
        $post_id = get_the_ID();
        
        if (!$post_id) {
            return;
        }
    }

}