<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use Elementor\Core\DynamicTags\Tag;
use Elementor\Modules\DynamicTags\Module as TagsModule;

class Popup extends Tag {
    public function get_name() {
        return 'uc-popup-trigger';
    }

    public function get_title() {
        return __('Popup Trigger', 'unistudio-core');
    }

    public function get_group() {
        return 'uc-dynamic-tags-actions';
    }

    public function get_categories() {
        return [TagsModule::URL_CATEGORY];
    }

    protected function register_controls() {
        $this->add_control(
            'section_id',
            [
                'label' => __('Popup Section', 'unistudio-core'),
                'type' => 'select',
                'options' => $this->get_popup_sections(),
            ]
        );
    }

    private function get_popup_sections() {
        $sections = [];
        
        // Get all published popup sections
        $popup_panels = get_posts([
            'post_type' => 'uc_global_sections',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'tax_query' => [
                [
                    'taxonomy' => 'uc_section_type',
                    'field' => 'slug',
                    'terms' => 'popup',
                ]
            ]
        ]);

        foreach ($popup_panels as $panel) {
            $sections[$panel->ID] = $panel->post_title;
        }
        
        return $sections;
    }

    /**
     * Render the tag output
     */
    public function render() {
        $section_id = $this->get_settings('section_id');
        
        if (!$section_id) {
            echo '#';
            return;
        }

        // Output the URL
        echo '#uc-popup-' . esc_attr($section_id);
    }
}