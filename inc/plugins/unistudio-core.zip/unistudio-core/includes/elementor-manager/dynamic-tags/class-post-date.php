<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Tag;
use Elementor\Controls_Manager;

class Post_Date extends Tag {
    public function get_name() {
        return 'uc-post-date';
    }

    public function get_title() {
        return __('Post Date', 'polysaas');
    }

    public function get_group() {
        return 'uc-dynamic-tags-post';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }

    protected function register_controls() {
        $this->add_control(
            'date_type',
            [
                'label' => __('Date Type', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => 'publish',
                'options' => [
                    'publish' => __('Publish Date', 'polysaas'),
                    'modified' => __('Last Modified Date', 'polysaas'),
                ],
            ]
        );

        $this->add_control(
            'date_format',
            [
                'label' => __('Date Format', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => __('Default', 'polysaas'),
                    'F j, Y' => date('F j, Y'),
                    'Y-m-d' => date('Y-m-d'),
                    'm/d/Y' => date('m/d/Y'),
                    'd/m/Y' => date('d/m/Y'),
                    'custom' => __('Custom', 'polysaas'),
                ],
            ]
        );

        $this->add_control(
            'custom_format',
            [
                'label' => __('Custom Format', 'polysaas'),
                'type' => Controls_Manager::TEXT,
                'default' => 'F j, Y',
                'placeholder' => 'F j, Y',
                'description' => sprintf(
                    /* translators: %s: WordPress date format reference link */
                    __('Refer to %s for date format options.', 'polysaas'),
                    '<a href="https://wordpress.org/support/article/formatting-date-and-time/" target="_blank">WordPress Format</a>'
                ),
                'condition' => [
                    'date_format' => 'custom',
                ],
            ]
        );

        $this->add_control(
            'human_readable_date',
            [
                'label' => __('Human Readable', 'polysaas'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'polysaas'),
                'label_off' => __('No', 'polysaas'),
                'return_value' => 'yes',
                'default' => '',
                'description' => __('Display time difference (e.g. "2 days ago")', 'polysaas'),
            ]
        );
    }

    public function render() {
        $settings = $this->get_settings_for_display();
        $post_id = get_the_ID();
        
        if (!$post_id) {
            return;
        }
        
        $date_type = $settings['date_type'];
        $date_timestamp = 'publish' === $date_type ? get_the_date('U', $post_id) : get_the_modified_date('U', $post_id);
        
        if ('yes' === $settings['human_readable_date']) {
            // Human readable time difference
            echo human_time_diff($date_timestamp, current_time('timestamp')) . ' ' . __('ago', 'polysaas');
            return;
        }
        
        $date_format = $settings['date_format'];
        
        if ('default' === $date_format) {
            $date_format = get_option('date_format');
        } elseif ('custom' === $date_format) {
            $date_format = $settings['custom_format'];
        }
        
        echo 'publish' === $date_type ? get_the_date($date_format, $post_id) : get_the_modified_date($date_format, $post_id);
    }
}