<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Data_Tag;
use Elementor\Controls_Manager;

class Author_Info extends Data_Tag {
    public function get_name() {
        return 'uc-author-info';
    }

    public function get_title() {
        return __('Author Info', 'polysaas');
    }

    public function get_group() {
        return 'uc-dynamic-tags-post';
    }

    public function get_categories() {
        return [
            \Elementor\Modules\DynamicTags\Module::IMAGE_CATEGORY,
            \Elementor\Modules\DynamicTags\Module::URL_CATEGORY,
        ];
    }

    protected function register_controls() {
        $this->add_control(
            'info_type',
            [
                'label' => __('Info Type', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => 'avatar',
                'options' => [
                    'avatar' => __('Avatar Image', 'polysaas'),
                    'url' => __('Author URL', 'polysaas'),
                    'email_url' => __('Email URL', 'polysaas'),
                    'website_url' => __('Website URL', 'polysaas'),
                ],
            ]
        );
        
        $this->add_control(
            'avatar_size',
            [
                'label' => __('Avatar Size', 'polysaas'),
                'type' => Controls_Manager::NUMBER,
                'default' => 96,
                'min' => 20,
                'max' => 512,
                'condition' => [
                    'info_type' => 'avatar',
                ],
            ]
        );
    }

    public function get_value(array $options = []) {
        $settings = $this->get_settings_for_display();
        $post_id = get_the_ID();
        
        if (!$post_id) {
            return '';
        }
        
        $author_id = get_post_field('post_author', $post_id);
        
        if (!$author_id) {
            return '';
        }
        
        $info_type = $settings['info_type'];
        
        switch ($info_type) {
            case 'avatar':
                $avatar_size = (int) $settings['avatar_size'];
                $avatar_url = get_avatar_url($author_id, ['size' => $avatar_size]);
                
                return [
                    'url' => $avatar_url,
                    'id' => 0,
                    'size' => '',
                    'alt' => sprintf(__('Avatar of %s', 'polysaas'), get_the_author_meta('display_name', $author_id)),
                    'source' => 'avatar',
                ];
                
            case 'url':
                return get_author_posts_url($author_id);
                
            case 'email_url':
                $email = get_the_author_meta('user_email', $author_id);
                return $email ? 'mailto:' . $email : '';
                
            case 'website_url':
                return get_the_author_meta('user_url', $author_id);
                
            default:
                return '';
        }
    }
}