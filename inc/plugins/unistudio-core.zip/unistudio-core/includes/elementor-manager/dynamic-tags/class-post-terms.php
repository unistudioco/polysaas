<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Tag;
use Elementor\Controls_Manager;

class Post_Terms extends Tag {
    public function get_name() {
        return 'uc-post-terms';
    }

    public function get_title() {
        return __('Post Terms', 'polysaas');
    }

    public function get_group() {
        return 'uc-dynamic-tags-post';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }

    protected function register_controls() {
        $taxonomies = $this->get_taxonomies();
        
        $this->add_control(
            'taxonomy',
            [
                'label' => __('Taxonomy', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'options' => $taxonomies,
                'default' => 'category',
            ]
        );

        $this->add_control(
            'separator',
            [
                'label' => __('Separator', 'polysaas'),
                'type' => Controls_Manager::TEXT,
                'default' => ', ',
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => __('Link', 'polysaas'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'max_terms',
            [
                'label' => __('Max Terms to Show', 'polysaas'),
                'type' => Controls_Manager::NUMBER,
                'default' => '',
                'min' => 1,
            ]
        );

        $this->add_control(
            'prefix_text',
            [
                'label' => __('Prefix Text', 'polysaas'),
                'type' => Controls_Manager::TEXT,
                'default' => '',
            ]
        );
    }

    private function get_taxonomies() {
        $taxonomies = [];
        
        $post_types = get_post_types(['public' => true], 'objects');
        foreach ($post_types as $post_type) {
            $post_type_taxonomies = get_object_taxonomies($post_type->name, 'objects');
            foreach ($post_type_taxonomies as $slug => $object) {
                if (!isset($taxonomies[$slug])) {
                    $taxonomies[$slug] = $object->label;
                }
            }
        }
        
        return $taxonomies;
    }

    public function render() {
        $settings = $this->get_settings_for_display();
        $post_id = get_the_ID();
        
        if (!$post_id || !taxonomy_exists($settings['taxonomy'])) {
            return;
        }
        
        $terms = wp_get_post_terms($post_id, $settings['taxonomy']);
        
        if (empty($terms) || is_wp_error($terms)) {
            return;
        }
        
        // Limit number of terms
        if (!empty($settings['max_terms'])) {
            $terms = array_slice($terms, 0, $settings['max_terms']);
        }
        
        $terms_links = [];
        
        foreach ($terms as $term) {
            if ('yes' === $settings['link']) {
                $terms_links[] = '<a href="' . esc_url(get_term_link($term)) . '">' . esc_html($term->name) . '</a>';
            } else {
                $terms_links[] = esc_html($term->name);
            }
        }
        
        $prefix = '';
        if (!empty($settings['prefix_text'])) {
            $prefix = $settings['prefix_text'] . ' ';
        }
        
        echo $prefix . implode($settings['separator'], $terms_links);
    }
}