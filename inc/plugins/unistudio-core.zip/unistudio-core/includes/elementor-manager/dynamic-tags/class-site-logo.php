<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Data_Tag;
use Elementor\Controls_Manager;

class Site_Logo extends Data_Tag {
    public function get_name() {
        return 'uc-site-logo';
    }

    public function get_title() {
        return __('Site Logo', 'polysaas');
    }

    public function get_group() {
        return 'uc-dynamic-tags';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::IMAGE_CATEGORY];
    }
    
    protected function register_controls() {
        $this->add_control(
            'fallback',
            [
                'label' => __('Fallback', 'polysaas'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => '',
                ],
                'description' => __('Displayed if site logo is not set', 'polysaas'),
            ]
        );
        
        $this->add_control(
            'logo_type',
            [
                'label' => __('Logo Type', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => __('Default', 'polysaas'),
                    'dark' => __('Dark Version', 'polysaas'),
                ],
                'description' => __('Select logo type. Dark version will be used if custom field "dark_logo" is set.', 'polysaas'),
            ]
        );
    }

    public function get_value(array $options = []) {
        $logo_type = $this->get_settings('logo_type');
        $fallback = $this->get_settings('fallback');
        
        // Try to get custom theme settings logo first
        $custom_logo_id = 0;
        
        if ($logo_type === 'dark' && function_exists('get_theme_mod')) {
            // Check for dark logo in theme mod or options
            $custom_logo_id = get_theme_mod('custom_logo_dark');
            
            // If no dark logo in theme mods, try custom field
            if (!$custom_logo_id) {
                $custom_logo_id = get_option('site_dark_logo');
            }
        }
        
        // If no dark logo or if default logo requested, get the standard logo
        if (!$custom_logo_id) {
            $custom_logo_id = get_theme_mod('custom_logo');
        }
        
        if (!$custom_logo_id && function_exists('get_option')) {
            $custom_logo_id = get_option('site_logo');
        }
        
        if (!$custom_logo_id && !empty($fallback['id'])) {
            $custom_logo_id = $fallback['id'];
        }
        
        if (!$custom_logo_id) {
            return [];
        }
        
        $logo_data = [
            'id' => $custom_logo_id,
            'url' => wp_get_attachment_image_url($custom_logo_id, 'full'),
        ];
        
        if (!empty($logo_data['id'])) {
            $attachment_metadata = wp_get_attachment_metadata($custom_logo_id);
            $logo_data['size'] = '';
            $logo_data['dimension'] = [
                'width' => $attachment_metadata['width'] ?? '',
                'height' => $attachment_metadata['height'] ?? ''
            ];
            $logo_data['alt'] = get_post_meta($custom_logo_id, '_wp_attachment_image_alt', true) ?: get_bloginfo('name');
        }
        
        return $logo_data;
    }
}