<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Data_Tag;
use Elementor\Controls_Manager;

class Featured_Image extends Data_Tag {
    public function get_name() {
        return 'uc-featured-image';
    }

    public function get_title() {
        return __('Featured Image', 'unistudio-core');
    }

    public function get_group() {
        return 'uc-dynamic-tags-post';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::IMAGE_CATEGORY];
    }

    protected function register_controls() {
        $post_types = $this->get_public_post_types();
        
        $this->add_control(
            'post_type',
            [
                'label' => __('Post Type', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'current',
                'options' => $post_types,
            ]
        );

        $this->add_control(
            'post_id',
            [
                'label' => __('Select Post', 'unistudio-core'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => [],
                'condition' => [
                    'post_type!' => 'current',
                ],
            ]
        );
    }

    private function get_public_post_types() {
        $post_types = ['current' => __('Current Post', 'unistudio-core')];
        
        $args = [
            'public' => true,
            'show_ui' => true,
        ];
        
        $post_types_objects = get_post_types($args, 'objects');
        
        foreach ($post_types_objects as $post_type) {
            // Skip some post types if needed
            if (in_array($post_type->name, ['attachment'])) {
                continue;
            }
            $post_types[$post_type->name] = $post_type->label;
        }
    
        return $post_types;
    }

    protected function get_value(array $options = []) {
        $settings = $this->get_settings();
        $post_type = $settings['post_type'];
        
        if ($post_type === 'current' || empty($settings['post_id'])) {
            $post_id = get_the_ID();
        } else {
            $post_id = $settings['post_id'];
        }
        
        if (!$post_id || !has_post_thumbnail($post_id)) {
            return [];
        }

        $thumbnail_id = get_post_thumbnail_id($post_id);

        $image_data = [
            'id' => $thumbnail_id,
            'url' => get_the_post_thumbnail_url($post_id, 'full'),
        ];

        if (!empty($image_data['id'])) {
            $attachment_metadata = wp_get_attachment_metadata($thumbnail_id);
            $image_data['size'] = '';
            $image_data['dimension'] = [
                'width' => $attachment_metadata['width'] ?? '',
                'height' => $attachment_metadata['height'] ?? ''
            ];
            $image_data['alt'] = get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true);
        }

        return $image_data;
    }
}