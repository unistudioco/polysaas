<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Tag;
use Elementor\Controls_Manager;

class Related_Posts extends Tag {
    public function get_name() {
        return 'uc-related-posts';
    }

    public function get_title() {
        return __('Related Posts', 'polysaas');
    }

    public function get_group() {
        return 'uc-dynamic-tags';
    }

    public function get_categories() {
        return [\Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY];
    }

    protected function register_controls() {
        $this->add_control(
            'relation_by',
            [
                'label' => __('Relation By', 'polysaas'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => [
                    'category' => __('Category', 'polysaas'),
                    'tag' => __('Tag', 'polysaas'),
                    'author' => __('Author', 'polysaas'),
                ],
                'default' => ['category', 'tag'],
            ]
        );
        
        $this->add_control(
            'number_of_posts',
            [
                'label' => __('Number of Posts', 'polysaas'),
                'type' => Controls_Manager::NUMBER,
                'default' => 3,
                'min' => 1,
                'max' => 10,
            ]
        );
        
        $this->add_control(
            'display_format',
            [
                'label' => __('Display Format', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => 'list',
                'options' => [
                    'list' => __('Unordered List', 'polysaas'),
                    'ordered' => __('Ordered List', 'polysaas'),
                    'inline' => __('Inline (comma separated)', 'polysaas'),
                    'custom' => __('Custom HTML', 'polysaas'),
                ],
            ]
        );
        
        $this->add_control(
            'custom_html',
            [
                'label' => __('Custom HTML', 'polysaas'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => '<div class="related-post"><a href="{post_url}">{post_title}</a></div>',
                'description' => __('Use {post_title}, {post_url}, {post_excerpt}, {post_date}, {post_author} as placeholders', 'polysaas'),
                'condition' => [
                    'display_format' => 'custom',
                ],
            ]
        );
        
        $this->add_control(
            'show_date',
            [
                'label' => __('Show Date', 'polysaas'),
                'type' => Controls_Manager::SWITCHER,
                'default' => '',
                'condition' => [
                    'display_format!' => 'custom',
                ],
            ]
        );
        
        $this->add_control(
            'date_format',
            [
                'label' => __('Date Format', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => __('Default', 'polysaas'),
                    'F j, Y' => date('F j, Y'),
                    'Y-m-d' => date('Y-m-d'),
                    'm/d/Y' => date('m/d/Y'),
                    'd/m/Y' => date('d/m/Y'),
                ],
                'condition' => [
                    'show_date' => 'yes',
                    'display_format!' => 'custom',
                ],
            ]
        );
    }

    public function render() {
        $settings = $this->get_settings_for_display();
        $post_id = get_the_ID();
        
        if (!$post_id) {
            return;
        }
        
        $current_post_type = get_post_type($post_id);
        $number_of_posts = intval($settings['number_of_posts']);
        $relation_by = $settings['relation_by'];
        
        // Prepare query arguments
        $args = [
            'post_type' => $current_post_type,
            'post_status' => 'publish',
            'posts_per_page' => $number_of_posts,
            'post__not_in' => [$post_id], // Exclude current post
            'orderby' => 'date',
            'order' => 'DESC',
        ];
        
        // Tax query for categories and tags
        $tax_query = [];
        
        if (in_array('category', $relation_by) && is_object_in_taxonomy($current_post_type, 'category')) {
            $categories = wp_get_post_categories($post_id);
            if (!empty($categories)) {
                $tax_query[] = [
                    'taxonomy' => 'category',
                    'field' => 'term_id',
                    'terms' => $categories,
                ];
            }
        }
        
        if (in_array('tag', $relation_by) && is_object_in_taxonomy($current_post_type, 'post_tag')) {
            $tags = wp_get_post_tags($post_id, ['fields' => 'ids']);
            if (!empty($tags)) {
                $tax_query[] = [
                    'taxonomy' => 'post_tag',
                    'field' => 'term_id',
                    'terms' => $tags,
                ];
            }
        }
        
        if (count($tax_query) > 1) {
            $tax_query['relation'] = 'OR';
            $args['tax_query'] = $tax_query;
        } elseif (count($tax_query) === 1) {
            $args['tax_query'] = $tax_query;
        }
        
        // Add author query if selected
        if (in_array('author', $relation_by)) {
            $args['author'] = get_post_field('post_author', $post_id);
        }
        
        // Get related posts
        $related_posts = new \WP_Query($args);
        
        if (!$related_posts->have_posts()) {
            return;
        }
        
        // Display posts according to selected format
        $display_format = $settings['display_format'];
        $date_format = 'default' === $settings['date_format'] ? get_option('date_format') : $settings['date_format'];
        
        // Open list if needed
        if ('list' === $display_format) {
            echo '<ul class="related-posts-list">';
        } elseif ('ordered' === $display_format) {
            echo '<ol class="related-posts-list">';
        } elseif ('inline' === $display_format) {
            echo '<div class="related-posts-inline">';
        } elseif ('custom' === $display_format) {
            echo '<div class="related-posts-custom">';
        }
        
        $count = 0;
        while ($related_posts->have_posts()) {
            $related_posts->the_post();
            $related_post_id = get_the_ID();
            
            if ('custom' === $display_format) {
                $html = $settings['custom_html'];
                $replacements = [
                    '{post_title}' => get_the_title(),
                    '{post_url}' => get_permalink(),
                    '{post_excerpt}' => wp_trim_words(get_the_excerpt(), 20),
                    '{post_date}' => get_the_date($date_format),
                    '{post_author}' => get_the_author(),
                ];
                
                echo strtr($html, $replacements);
            } else {
                if ('list' === $display_format || 'ordered' === $display_format) {
                    echo '<li class="related-post-item">';
                }
                
                echo '<a href="' . get_permalink() . '">' . get_the_title() . '</a>';
                
                if ('yes' === $settings['show_date']) {
                    echo ' <span class="related-post-date">(' . get_the_date($date_format) . ')</span>';
                }
                
                if ('list' === $display_format || 'ordered' === $display_format) {
                    echo '</li>';
                } elseif ('inline' === $display_format && $count < $related_posts->post_count - 1) {
                    echo ', ';
                }
            }
            
            $count++;
        }
        
        // Close list
        if ('list' === $display_format) {
            echo '</ul>';
        } elseif ('ordered' === $display_format) {
            echo '</ol>';
        } elseif ('inline' === $display_format || 'custom' === $display_format) {
            echo '</div>';
        }
        
        wp_reset_postdata();
    }
}