<?php
namespace UniStudioCore\ElementorManager\DynamicTags;

use \Elementor\Core\DynamicTags\Tag;
use Elementor\Controls_Manager;

class Post_Custom_Field extends Tag {
    public function get_name() {
        return 'uc-post-custom-field';
    }

    public function get_title() {
        return __('Post Custom Field', 'polysaas');
    }

    public function get_group() {
        return 'uc-dynamic-tags-post';
    }

    public function get_categories() {
        return [
            \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY,
            \Elementor\Modules\DynamicTags\Module::URL_CATEGORY,
            \Elementor\Modules\DynamicTags\Module::POST_META_CATEGORY,
        ];
    }

    protected function register_controls() {
        $this->add_control(
            'key',
            [
                'label' => __('Key', 'polysaas'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'default' => '',
                'options' => $this->get_custom_keys_array(),
                'description' => __('Choose a meta key or type a custom one', 'polysaas'),
            ]
        );
        
        $this->add_control(
            'custom_key',
            [
                'label' => __('Custom Key', 'polysaas'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '',
                'description' => __('Type a custom meta key if not found in the list above', 'polysaas'),
            ]
        );
        
        $this->add_control(
            'fallback',
            [
                'label' => __('Fallback', 'polysaas'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => '',
                'description' => __('Displayed if the custom field is empty', 'polysaas'),
            ]
        );
        
        $this->add_control(
            'is_acf_field',
            [
                'label' => __('ACF Field', 'polysaas'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'polysaas'),
                'label_off' => __('No', 'polysaas'),
                'default' => '',
                'description' => __('Is this an Advanced Custom Fields field?', 'polysaas'),
                'separator' => 'before',
            ]
        );
        
        $this->add_control(
            'acf_field_type',
            [
                'label' => __('ACF Field Type', 'polysaas'),
                'type' => Controls_Manager::SELECT,
                'default' => 'text',
                'options' => [
                    'text' => __('Text / Number / Email / etc', 'polysaas'),
                    'image' => __('Image', 'polysaas'),
                    'date' => __('Date', 'polysaas'),
                    'relationship' => __('Relationship', 'polysaas'),
                ],
                'condition' => [
                    'is_acf_field' => 'yes',
                ],
            ]
        );
    }
    
    private function get_custom_keys_array() {
        global $wpdb;
        
        $custom_keys = $wpdb->get_col(
            "SELECT DISTINCT meta_key
            FROM {$wpdb->postmeta}
            WHERE meta_key NOT LIKE '\_%'
            ORDER BY meta_key"
        );
        
        $options = [];
        
        if (!empty($custom_keys)) {
            foreach ($custom_keys as $key) {
                $options[$key] = $key;
            }
        }
        
        return $options;
    }

    public function render() {
        $settings = $this->get_settings_for_display();
        $post_id = get_the_ID();
        
        if (!$post_id) {
            echo $settings['fallback'];
            return;
        }
        
        $key = $settings['key'];
        
        if (empty($key) && !empty($settings['custom_key'])) {
            $key = $settings['custom_key'];
        }
        
        if (empty($key)) {
            echo $settings['fallback'];
            return;
        }
        
        if ('yes' === $settings['is_acf_field'] && function_exists('get_field')) {
            $value = get_field($key, $post_id);
            
            if ($settings['acf_field_type'] === 'image' && is_array($value)) {
                $value = isset($value['url']) ? $value['url'] : '';
            } elseif ($settings['acf_field_type'] === 'date' && !empty($value)) {
                $value = date_i18n(get_option('date_format'), strtotime($value));
            } elseif ($settings['acf_field_type'] === 'relationship' && is_array($value)) {
                $titles = [];
                foreach ($value as $related_post) {
                    if (is_object($related_post)) {
                        $titles[] = $related_post->post_title;
                    } elseif (is_numeric($related_post)) {
                        $titles[] = get_the_title($related_post);
                    }
                }
                $value = implode(', ', $titles);
            }
        } else {
            $value = get_post_meta($post_id, $key, true);
        }
        
        if (is_array($value)) {
            $value = implode(', ', $value);
        }
        
        if ('' === $value && !empty($settings['fallback'])) {
            $value = $settings['fallback'];
        }
        
        echo wp_kses_post($value);
    }
}