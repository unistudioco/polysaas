<?php
namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;
use UniStudioCore\ACF_Helpers;

class Portfolio_Grid extends Widget_Base {
    public function get_name() {
        return 'uc_portfolio_grid';
    }
    
    public function get_title() {
        return __('UC - Portfolio Grid', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-gallery-grid';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    }
    
    public function get_script_depends() {
        return ['uc-protfolio-grid'];
    }

    public function get_style_depends() {
        return ['uc-protfolio-grid'];
    }

    public function register_widget_scripts() {
        Asset_Manager::getInstance()->register_widget_script(
            'uc-protfolio-grid',
            'assets/js/widgets/portfolio-grid.min.js',
            ['uc-core']
        );
    }

    public function register_widget_styles() {
        Asset_Manager::getInstance()->register_widget_style(
            'uc-protfolio-grid',
            'assets/css/widgets/portfolio-grid.min.css',
            ['uc-core']
        );
    }
    
    protected function register_controls() {
        // Layout Section
        $this->start_controls_section(
            'section_layout',
            [
                'label' => __('Layout', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'columns',
            [
                'label' => __('Columns', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '3',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
            ]
        );
        
        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Posts Per Page', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 6,
            ]
        );
        
        $this->add_control(
            'show_filters',
            [
                'label' => __('Show Filters', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        
        $this->end_controls_section();
        
        // Query Section
        $this->start_controls_section(
            'section_query',
            [
                'label' => __('Query', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'orderby',
            [
                'label' => __('Order By', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'date',
                'options' => [
                    'date' => __('Date', 'unistudio-core'),
                    'title' => __('Title', 'unistudio-core'),
                    'menu_order' => __('Menu Order', 'unistudio-core'),
                    'rand' => __('Random', 'unistudio-core'),
                ],
            ]
        );
        
        $this->add_control(
            'order',
            [
                'label' => __('Order', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'DESC',
                'options' => [
                    'DESC' => __('Descending', 'unistudio-core'),
                    'ASC' => __('Ascending', 'unistudio-core'),
                ],
            ]
        );
        
        $this->end_controls_section();
        
        // Style Sections...
        $this->register_style_controls();
    }
    
    protected function register_style_controls() {
        // Grid Style
        $this->start_controls_section(
            'section_grid_style',
            [
                'label' => __('Grid', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_responsive_control(
            'column_gap',
            [
                'label' => __('Columns Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 30,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-portfolio-grid' => 'grid-gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {

        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_portfolio_grid')) {
            return;
        }

        $settings = $this->get_settings_for_display();
        
        // Add a unique class for this instance
        $widget_id = $this->get_id();
        $unique_class = 'uc-portfolio-grid-' . $widget_id;
        
        // Query arguments
        $args = [
            'post_type' => 'uc_portfolio',
            'posts_per_page' => $settings['posts_per_page'],
            'orderby' => $settings['orderby'],
            'order' => $settings['order'],
        ];
        
        $query = new \WP_Query($args);
        
        if ($query->have_posts()) :
            // Get all portfolio categories if filters are enabled
            $categories = [];
            if ('yes' === $settings['show_filters']) {
                $categories = get_terms([
                    'taxonomy' => 'uc_portfolio_category',
                    'hide_empty' => true,
                ]);
            }
            ?>
            
            <div class="uc-portfolio-element uc-portfolio-wrapper <?php echo esc_attr($unique_class); ?>">
                <?php if (!empty($categories)) : ?>
                    <div class="uc-portfolio-filters">
                        <button class="uc-filter active" data-filter="*" data-widget="<?php echo esc_attr($widget_id); ?>">
                            <?php echo esc_html__('All', 'unistudio-core'); ?>
                        </button>
                        <?php foreach ($categories as $category) : ?>
                            <button class="uc-filter" data-filter=".<?php echo esc_attr($category->slug); ?>" data-widget="<?php echo esc_attr($widget_id); ?>">
                                <?php echo esc_html($category->name); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                
                <div class="uc-projects-listing child-cols-<?php echo esc_attr($settings['columns']); ?>" data-uc-grid="masonry: true;">
                    <?php
                    while ($query->have_posts()) :
                        $query->the_post();
                        ?>
                        <div class="uc-project-item">
                            <!-- portfolio item template -->
                        </div>
                    <?php
                    endwhile;
                    wp_reset_postdata();
                    ?>
                </div>
            </div>
            <?php
        endif;
    }
}