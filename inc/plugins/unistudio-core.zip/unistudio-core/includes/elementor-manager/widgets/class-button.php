<?php

namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Button extends Widget_Base {
    public function get_name() {
        return 'uc_button';
    }
    
    public function get_title() {
        return __('UC - Button', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-button';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'button_type',
            [
                'label' => __('Type', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'link',
                'options' => [
                    'link' => __('Link', 'unistudio-core'),
                    'button' => __('Button', 'unistudio-core'),
                ],
            ]
        );
        
        $this->add_control(
            'text',
            [
                'label' => __('Text', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Click here', 'unistudio-core'),
                'placeholder' => __('Click here', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => __('Link', 'unistudio-core'),
                'type' => Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'unistudio-core'),
                'dynamic' => [
                    'active' => true,
                ],
                'default' => [
                    'url' => '#',
                ],
                'condition' => [
                    'button_type' => 'link',
                ],
            ]
        );

        $this->add_control(
			'heading_before_button_styling',
			[
				'label' => esc_html__( 'Styling Options', 'textdomain' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
            'button_style',
            [
                'label' => __('Style', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => __('Default', 'unistudio-core'),
                    'outline' => __('Outline', 'unistudio-core'),
                    'alt' => __('Alternate', 'unistudio-core'),
                    'ghost' => __('Ghost', 'unistudio-core'),
                ],
            ]
        );

        $this->add_control(
            'button_state',
            [
                'label' => __('State', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'primary',
                'options' => [
                    'primary' => __('Primary', 'unistudio-core'),
                    'secondary' => __('Secondary', 'unistudio-core'),
                    'success' => __('Success', 'unistudio-core'),
                    'info' => __('Info', 'unistudio-core'),
                    'warning' => __('Warning', 'unistudio-core'),
                    'danger' => __('Danger', 'unistudio-core'),
                    'light' => __('Light', 'unistudio-core'),
                    'dark' => __('Dark', 'unistudio-core'),
                ],
            ]
        );

        $this->add_control(
            'size',
            [
                'label' => __('Size', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'md',
                'options' => [
                    '2xs' => __('2X Small', 'unistudio-core'),
                    'xs' => __('Extra Small', 'unistudio-core'),
                    'sm' => __('Small', 'unistudio-core'),
                    'md' => __('Medium', 'unistudio-core'),
                    'lg' => __('Large', 'unistudio-core'),
                    'xl' => __('Extra Large', 'unistudio-core'),
                    '2xl' => __('2X Large', 'unistudio-core'),
                ],
            ]
        );

        $this->add_responsive_control(
            'full_width',
            [
                'label' => __('Full Width', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .uc-button-wrapper' => 'width: 100%;',
                    '{{WRAPPER}} .uc-button-wrapper .btn' => 'width: 100%; display: inline-flex; justify-content: center;',
                ],
            ]
        );

        $this->add_responsive_control(
            'btn_align',
            [
                'label' => __('Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'unistudio-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'unistudio-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'unistudio-core'),
                        'icon' => 'eicon-text-align-right',
                    ]
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .uc-button-wrapper' => 'text-align: {{VALUE}};',
                ],
                'condition' => [
                    'full_width' => '',
                ],
            ]
        );

        $this->add_control(
			'heading_before_icon',
			[
				'label' => esc_html__( 'Icon', 'textdomain' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        // Icon Options
        $this->add_control(
            'show_icon',
            [
                'label' => __('Show Icon', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => __('Icon', 'unistudio-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'unicon-star-filled',
                    'library' => 'unicons',
                ],
                'recommended' => [
                    'unicons' => [
                        'star-filled',
                        'star',
                        'arrow-down',
                        'arrow-up',
                        'arrow-left',
                        'arrow-right',
                        'arrow-up-right',
                        'add',
                        'add-alt',
                        'add-alt-filled',
                        'download-cloud',
                        'upload-cloud',
                        'cart',
                        'bookmark-filled',
                        'view-alt-filled',
                        'location-filled',
                    ],
                ],
                'condition' => [
                    'show_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'icon_position',
            [
                'label' => __('Icon Position', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'before',
                'options' => [
                    'before' => __('Before', 'unistudio-core'),
                    'after' => __('After', 'unistudio-core'),
                ],
                'condition' => [
                    'show_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
			'heading_before_css_selectors',
			[
				'label' => esc_html__( 'CSS Selectors', 'textdomain' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
            'custom_id',
            [
                'label' => __('Button ID', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'placeholder' => __('my-button-id', 'unistudio-core'),
                'description' => __('Add your custom id WITHOUT the Pound key. e.g: my-button-id', 'unistudio-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'custom_classes',
            [
                'label' => __('Button Classes', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'placeholder' => __('class-one class-two', 'unistudio-core'),
                'description' => __('Multiple classes should be separated with spaces.', 'unistudio-core'),
                'label_block' => true,
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'section_style',
            [
                'label' => __('Button', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
    
        $this->add_responsive_control(
            'min_width',
            [
                'label' => esc_html__('Min Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1280,
                    ],
                ],
                'default' => [
                    'size' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .btn' => 'min-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'typography',
                'selector' => '{{WRAPPER}} .btn',
            ]
        );

        $this->add_control(
            'btn_states_heading',
            [
                'label' => __('Button States', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->start_controls_tabs('style_tabs');

        // Normal State
        $this->start_controls_tab(
            'style_normal',
            [
                'label' => __('Normal', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'background_color',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .btn',
            ]
        );

        $this->end_controls_tab();

        // Hover State
        $this->start_controls_tab(
            'style_hover',
            [
                'label' => __('Hover', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'hover_color',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'hover_background_color',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .btn:hover',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        // Border
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'selector' => '{{WRAPPER}} .btn',
                'separator' => 'before',
                'fields_options' => [
                    'border' => [
                        'default' => 'solid',
                    ],
                    'width' => [
                        'default' => [
                            'top' => '1',
                            'right' => '1',
                            'bottom' => '1',
                            'left' => '1',
                            'unit' => 'px',
                            'isLinked' => true,
                        ],
                    ],
                ],
            ]
        );

        $this->add_control(
            'border_radius',
            [
                'label' => __('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Padding
        $this->add_responsive_control(
            'padding',
            [
                'label' => __('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Button Shadow
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow',
                'selector' => '{{WRAPPER}} .btn',
            ]
        );

        $this->add_control(
            'btn_transition_heading',
            [
                'label' => __('Transition', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->add_control(
            'btn_transition_duration',
            [
                'label' => __('Transition Duration', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0.3,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 3,
                        'step' => 0.1,
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} .btn' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );
        
        $this->add_control(
            'btn_transition_timing',
            [
                'label' => __('Timing Function', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'ease',
                'options' => [
                    'linear' => __('Linear', 'unistudio-core'),
                    'ease' => __('Ease', 'unistudio-core'),
                    'ease-in' => __('Ease In', 'unistudio-core'),
                    'ease-out' => __('Ease Out', 'unistudio-core'),
                    'ease-in-out' => __('Ease In Out', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .btn' => 'transition-timing-function: {{VALUE}}',
                ],
            ]
        );
        
        $this->add_control(
            'btn_transition_property',
            [
                'label' => __('Transition Properties', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'all',
                'options' => [
                    'all' => __('All', 'unistudio-core'),
                    'none' => __('None', 'unistudio-core'),
                    'background' => __('Background Only', 'unistudio-core'),
                    'background, color' => __('Background & Color', 'unistudio-core'),
                    'background, border' => __('Background & Border', 'unistudio-core'),
                    'background, border, color' => __('Background, Border & Color', 'unistudio-core'),
                    'background, border, border-radius, color, box-shadow' => __('All Properties', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} .btn' => 'transition-property: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Icon Style Section
        $this->start_controls_section(
            'section_icon_style',
            [
                'label' => __('Icon', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_icon' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __('Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .btn i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => __('Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 12,
                        'max' => 48,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .btn i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_spacing',
            [
                'label' => __('Spacing', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .btn' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }
    
    protected function render() {
        // Check if widget is enabled in settings
        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_button')) {
            return;
        }
    
        $settings = $this->get_settings_for_display();
    
        // Initialize wrapper classes and styles
        $wrapper_classes = ['uc-button-wrapper'];
    
        // Initialize button classes and styles
        $button_classes = ['btn'];
    
        // Add size class if specified
        if (!empty($settings['size'])) {
            $button_classes[] = 'btn-' . esc_attr($settings['size']);
        }
    
        // Add style classes based on button style and state
        $style_prefix = ($settings['button_style'] === 'default') ? 'btn-' : 'btn-' . $settings['button_style'] . '-';
        $button_classes[] = $style_prefix . esc_attr($settings['button_state']);

    
        // Add custom classes if specified
        if (!empty($settings['custom_css_classes'])) {
            $button_classes[] = esc_attr($settings['custom_css_classes']);
        }

        // Add the custom classes
        if (!empty($settings['custom_classes'])) {
            $button_classes[] = esc_attr($settings['custom_classes']);
        }
    
        // Prepare button attributes
        $button_attributes = [];

        // Add the custom ID
        if (!empty($settings['custom_id'])) {
            $button_attributes['id'] = esc_attr($settings['custom_id']);
        }
        
        // Handle link attributes for <a> tag
        if ($settings['button_type'] === 'link' && !empty($settings['link']['url'])) {
            $button_attributes['href'] = esc_url($settings['link']['url']);
            
            if (!empty($settings['link']['is_external'])) {
                $button_attributes['target'] = '_blank';
                $button_attributes['rel'][] = 'noopener';
            }
            
            if (!empty($settings['link']['nofollow'])) {
                $button_attributes['rel'][] = 'nofollow';
            }
    
            if (!empty($settings['link']['custom_attributes'])) {
                $custom_attributes = explode("\n", $settings['link']['custom_attributes']);
                foreach ($custom_attributes as $attribute) {
                    if (strpos($attribute, '|') !== false) {
                        list($key, $value) = explode('|', $attribute);
                        $button_attributes[trim($key)] = trim($value);
                    }
                }
            }
        }
    
        // Add additional attributes for button type
        if ($settings['button_type'] === 'button') {
            $button_attributes['type'] = 'button';
            if (!empty($settings['button_name'])) {
                $button_attributes['name'] = esc_attr($settings['button_name']);
            }
            if (!empty($settings['button_value'])) {
                $button_attributes['value'] = esc_attr($settings['button_value']);
            }
        }
    
        // Build the attributes string
        $attributes_str = '';
        foreach ($button_attributes as $key => $value) {
            if ($key === 'rel' && is_array($value)) {
                $value = implode(' ', $value);
            }
            $attributes_str .= ' ' . $key . '="' . esc_attr($value) . '"';
        }
    
        // Start output buffering for better control
        ob_start();
        ?>
        <div class="<?php echo esc_attr(implode(' ', $wrapper_classes)); ?>">
            <?php
            // Define tag type
            $tag = $settings['button_type'] === 'button' ? 'button' : 'a';
            
            // Open tag with classes, styles, and attributes
            echo '<' . $tag . ' class="' . esc_attr(implode(' ', $button_classes)) . '"' . $attributes_str . '>';
    
            // Icon before text
            if ($settings['show_icon'] === 'yes' && $settings['icon_position'] === 'before') {
                \Elementor\Icons_Manager::render_icon($settings['icon'], [
                    'aria-hidden' => 'true',
                    'class' => 'btn-icon-before'
                ]);
            }
    
            // Button text
            if (!empty($settings['text'])) {
                echo '<span class="btn-text">' . esc_html($settings['text']) . '</span>';
            }
    
            // Icon after text
            if ($settings['show_icon'] === 'yes' && $settings['icon_position'] === 'after') {
                \Elementor\Icons_Manager::render_icon($settings['icon'], [
                    'aria-hidden' => 'true',
                    'class' => 'btn-icon-after'
                ]);
            }
    
            // Close tag
            echo '</' . $tag . '>';
            ?>
        </div>
        <?php
        
        // Output the buffered content
        echo ob_get_clean();
    }

}