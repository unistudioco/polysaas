<?php

namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Heading extends Widget_Base {
    public function get_name() {
        return 'uc_heading';
    }
    
    public function get_title() {
        return __('UC - Heading', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-heading';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    }
    
    public function get_script_depends() {
        return ['jquery', 'elementor-frontend', 'uc-heading'];
    }

    public function register_widget_scripts() {
        Asset_Manager::getInstance()->register_widget_script(
            'uc-heading',
            'assets/js/widgets/heading.min.js',
            ['jquery', 'elementor-frontend'],
            '1.0.0',
            true
        );
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'heading_text',
            [
                'label' => __('Title', 'unistudio-core'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __('Type here...', 'unistudio-core'),
                'placeholder' => __('Type here...', 'unistudio-core'),
				'ai' => [
					'type' => 'text',
				],
				'dynamic' => [
					'active' => true,
				],
                'label_block' => true,
                'inline_editing' => true,
            ]
        );

        $this->add_control(
            'heading_type',
            [
                'label' => __('HTML Tag', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'h2',
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->register_style_controls();
        $this->register_highlight_text_controls();
    }
    
    protected function register_style_controls() {
        $this->start_controls_section(
            'section_style',
            [
                'label' => __('Heading', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // Typography
        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'heading_typography',
                'selector' => '{{WRAPPER}} .uc-heading',
            ]
        );

        // Text Color
        $this->add_control(
            'heading_color',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .uc-heading' => 'color: {{VALUE}};',
                ],
            ]
        );

        // Alignment
        $this->add_responsive_control(
            'align',
            [
                'label' => __('Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'unistudio-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __('Center', 'unistudio-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __('Right', 'unistudio-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'selectors' => [
                    '{{WRAPPER}} .uc-heading' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        // Spacing
        $this->add_responsive_control(
            'heading_spacing',
            [
                'label' => __('Spacing', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-heading' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        // Text Stroke Popover
        $this->add_control(
            'text_stroke_popover',
            [
                'label' => __('Text Stroke', 'unistudio-core'),
                'type' => Controls_Manager::POPOVER_TOGGLE,
                'separator' => 'before',
            ]
        );

        $this->start_popover();

        $this->add_control(
            'text_stroke_width',
            [
                'label' => __('Stroke Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => -10,
                        'max' => 10,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-heading' => '-webkit-text-stroke-width: {{SIZE}}px;',
                ],
                'condition' => [
                    'text_stroke_popover' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'text_stroke_color',
            [
                'label' => __('Stroke Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-heading' => '-webkit-text-stroke-color: {{VALUE}};',
                ],
                'condition' => [
                    'text_stroke_popover' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'text_stroke_fill_color',
            [
                'label' => __('Fill Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-heading' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'text_stroke_popover' => 'yes',
                ],
            ]
        );

        $this->end_popover();

        // Text Shadow
        $this->add_group_control(
            \Elementor\Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'text_shadow',
                'selector' => '{{WRAPPER}} .uc-heading',
            ]
        );

        $this->end_controls_section();
    }
    
    protected function register_highlight_text_controls() {
        $this->start_controls_section(
            'section_highlight_text',
            [
                'label' => __('Highligh Text', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'highlight_text',
            [
                'label' => __('Highlight Text', 'unistudio-core'),
                'type' => Controls_Manager::TEXTAREA,
                'description' => __('You can break the line to highlight multiple words or phrase, CASE SENSETIVE!', 'unistudio-core'),
                'label_block' => true,
            ]
        );
        
        // Text Styling
        $this->add_control(
            'highlight_style',
            [
                'label' => __('Text Style', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'color',
                'options' => [
                    'color' => __('Solid Color', 'unistudio-core'),
                    'gradient' => __('Text Gradient', 'unistudio-core'),
                ],
                'condition' => [
                    'highlight_text!' => '',
                ],
            ]
        );

        $this->add_control(
            'highlight_color',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-heading .highlight' => 'color: {{VALUE}};',
                ],
                'condition' => [
                    'highlight_text!' => '',
                    'highlight_style' => 'color',
                ],
            ]
        );

        $this->add_control(
            'highlight_gradient_color_a',
            [
                'label' => __('From', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'highlight_text!' => '',
                    'highlight_style' => 'gradient',
                ],
            ]
        );

        $this->add_control(
            'highlight_gradient_color_b',
            [
                'label' => __('To', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'highlight_text!' => '',
                    'highlight_style' => 'gradient',
                ],
            ]
        );

        $this->add_control(
            'highlight_gradient_angle',
            [
                'label' => __('Angle', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['deg'],
                'default' => [
                    'unit' => 'deg',
                    'size' => 90,
                ],
                'range' => [
                    'deg' => [
                        'step' => 10,
                        'min' => 0,
                        'max' => 360,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-heading .highlight' => 'background: linear-gradient({{SIZE}}{{UNIT}}, {{highlight_gradient_color_a.VALUE}} 0%, {{highlight_gradient_color_b.VALUE}} 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;',
                ],
                'condition' => [
                    'highlight_text!' => '',
                    'highlight_style' => 'gradient',
                ],
            ]
        );
        
        // Background
        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'container_background',
                'types' => ['classic', 'gradient'],
                'exclude' => ['image'],
                'selector' => '{{WRAPPER}} .uc-heading .highlight',
                'condition' => [
                    'highlight_text!' => '',
                    'highlight_style' => 'color',
                ],
            ]
        );
        
        // Padding
        $this->add_responsive_control(
            'highlight_padding',
            [
                'label' => __('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-heading .highlight' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'highlight_text!' => '',
                ],
            ]
        );

         // Border Radius Control
         $this->add_responsive_control(
            'highlight_border_radius',
            [
                'label' => __('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '0',
                    'right' => '0',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-heading .highlight' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'condition' => [
                    'highlight_text!' => '',
                ],
            ]
        );

        // Border Control
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'highlight_border',
                'label' => __('Border', 'unistudio-core'),
                'selector' => '{{WRAPPER}} .uc-heading .highlight',
                'condition' => [
                    'highlight_text!' => '',
                ],
            ]
        );

        // Rotation Popover
        $this->add_control(
            'highlight_rotate_popover',
            [
                'label' => __('Rotate', 'unistudio-core'),
                'type' => Controls_Manager::POPOVER_TOGGLE,
                'condition' => [
                    'highlight_text!' => '',
                ],
            ]
        );

        $this->start_popover();

        $this->add_responsive_control(
            'highlight_rotate',
            [
                'label' => __('Angle', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['deg'],
                'range' => [
                    'deg' => [
                        'min' => -180,
                        'max' => 180,
                    ],
                ],
                'default' => [
                    'unit' => 'deg',
                    'size' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-heading .highlight' => 'display: inline-block; transform: rotate({{SIZE}}{{UNIT}});',
                ],
                'condition' => [
                    'highlight_rotate_popover' => 'yes',
                ],
            ]
        );

        $this->end_popover();

        $this->end_controls_section();
    }
    
    protected function render() {
        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_heading')) {
            return;
        }
        $settings = $this->get_settings_for_display();
        $is_edit_mode = \Elementor\Plugin::$instance->editor->is_edit_mode();
        
        $this->add_render_attribute('heading', [
            'class' => ['uc-heading']
        ]);
    
        if ($is_edit_mode) {
            $this->add_render_attribute('heading', [
                'class' => 'elementor-inline-editing',
                'data-elementor-setting-key' => 'heading_text',
                'data-elementor-inline-editing-toolbar' => 'basic',
                'contenteditable' => 'true',
                'data-pen-placeholder' => __('Type Here...', 'unistudio-core')
            ]);
        }
    
        $heading_text = $settings['heading_text'];
        
        if (!empty($settings['highlight_text'])) {
            $highlight_texts = explode("\n", $settings['highlight_text']);
            foreach ($highlight_texts as $text) {
                $text = trim($text);
                if (!empty($text) && strpos($heading_text, $text) !== false) {
                    $heading_text = str_replace(
                        $text,
                        '<span class="highlight">' . $text . '</span>',
                        $heading_text
                    );
                }
            }
        }
        
        if (!empty($settings['link']['url'])) {
            $this->add_link_attributes('heading_link', $settings['link']);
            $heading_text = sprintf('<a %1$s>%2$s</a>',
                $this->get_render_attribute_string('heading_link'),
                $heading_text
            );
        }
        
        printf('<%1$s %2$s>%3$s</%1$s>',
            $settings['heading_type'],
            $this->get_render_attribute_string('heading'),
            $heading_text
        );
    }
}