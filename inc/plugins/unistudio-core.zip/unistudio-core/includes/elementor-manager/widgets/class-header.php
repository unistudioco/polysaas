<?php

namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Header extends Widget_Base {
    public function get_name() {
        return 'uc_header';
    }
    
    public function get_title() {
        return __('UC - Header', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-header';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    }

    public function get_keywords() {
        return ['header', 'navigation', 'sticky', 'container'];
    }
    
    public function get_script_depends() {
        return ['uc-header'];
    }

    public function get_style_depends() {
        return ['uc-header'];
    }

    public function register_widget_scripts() {
        Asset_Manager::getInstance()->register_widget_script(
            'uc-header',
            'assets/js/widgets/header.min.js',
            ['uc-core']
        );
    }

    public function register_widget_styles() {
        Asset_Manager::getInstance()->register_widget_style(
            'uc-header',
            'assets/css/widgets/header.min.css',
            ['uc-core']
        );
    }

    private function get_headers_list() {
        $headers = [];
        
        // Query headers
        $args = [
            'post_type' => 'uc_header',
            'posts_per_page' => -1,
            'post_status' => 'publish',
        ];
        
        $query = new \WP_Query($args);
        
        if ($query->have_posts()) {
            while ($query->have_posts()) {
                $query->the_post();
                $headers[get_the_ID()] = get_the_title();
            }
        }
        
        wp_reset_postdata();
        
        return $headers;
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Header Settings', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $headers = $this->get_headers_list();
        
        if (empty($headers)) {
            $this->add_control(
                'no_headers_notice',
                [
                    'type' => Controls_Manager::RAW_HTML,
                    'raw' => sprintf(
                        __('No headers found. <a href="%s" target="_blank">Create a new header</a>', 'unistudio-core'),
                        admin_url('post-new.php?post_type=uc_header')
                    ),
                    'content_classes' => 'elementor-panel-alert elementor-panel-alert-warning',
                ]
            );
        }

        $this->add_control(
            'header_template',
            [
                'label' => esc_html__('Select Header', 'unistudio-core'),
                'type' => Controls_Manager::SELECT2,
                'options' => $headers,
                'default' => array_key_first($headers),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'enable_sticky',
            [
                'label' => esc_html__('Enable Sticky', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'unistudio-core'),
                'label_off' => esc_html__('No', 'unistudio-core'),
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'sticky_start',
            [
                'label' => esc_html__('Start Position', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '0',
                'options' => [
                    '0' => esc_html__('Top', 'unistudio-core'),
                    '100vh' => esc_html__('After First Screen', 'unistudio-core'),
                ],
                'condition' => [
                    'enable_sticky' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        
        if (empty($settings['header_template'])) {
            ?>
            <div class="uc-header-placeholder">
                <?php esc_html_e('Please select a header template.', 'unistudio-core'); ?>
            </div>
            <?php
            return;
        }

        // Get header content
        $header_content = \Elementor\Plugin::$instance->frontend->get_builder_content($settings['header_template'], true);
        
        if (empty($header_content)) {
            ?>
            <div class="elementor-alert elementor-alert-warning">
                <?php esc_html_e('Header template not found or empty.', 'unistudio-core'); ?>
            </div>
            <?php
            return;
        }

        // Build sticky attributes
        $sticky_attr = '';
        if ($settings['enable_sticky'] === 'yes') {
            $sticky_options = [
                'start' => $settings['sticky_start'],
                'sel-target' => '.uc-navbar-container',
                'cls-active' => 'uc-navbar-sticky',
                'cls-inactive' => 'uc-navbar-transparent'
            ];
            $sticky_attr = ' data-uc-sticky="' . esc_attr(implode('; ', array_map(function($key, $value) { 
                return "$key: $value"; 
            }, array_keys($sticky_options), $sticky_options))) . '"';
        }

        ?>
        <header class="uc-header<?php echo $settings['enable_sticky'] === 'yes' ? ' uc-sticky' : ''; ?>"<?php echo $sticky_attr; ?>>
            <?php echo $header_content; ?>
        </header>
        <?php
    }
}