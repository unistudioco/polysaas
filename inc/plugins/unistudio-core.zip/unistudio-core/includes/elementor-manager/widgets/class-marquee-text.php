<?php

namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Background;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Marquee_Text extends Widget_Base {
    public function get_name() {
        return 'uc_marquee_text';
    }
    
    public function get_title() {
        return __('UC - Marquee Text', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-animation-text';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    }
    
    public function get_script_depends() {
        return ['jquery', 'elementor-frontend', 'uc-marquee-text', 'uc-marquee-text-editor'];
    }

    public function get_style_depends() {
        return ['uc-marquee-text'];
    }

    public function register_widget_scripts() {
        Asset_Manager::getInstance()->register_widget_script(
            'uc-marquee-text',
            'assets/js/widgets/marquee-text.min.js',
            ['jquery', 'elementor-frontend'] 
        );
    }

    public function uc_enqueue_editor_scripts() {
        wp_enqueue_script(
            'uc-marquee-text-editor',
            UC_URL . 'assets/js/widgets/marquee-text.min.js',
            ['jquery', 'elementor-editor'],
            UC_VERSION,
            true
        );
    }

    public function register_widget_styles() {
        Asset_Manager::getInstance()->register_widget_style(
            'uc-marquee-text',
            'assets/css/widgets/marquee-text.min.css',
            ['uc-core']
        );
    }
    
    protected function register_controls() {
        // Content Controls
        $this->register_content_controls();
        // Style Controls
        $this->register_style_controls();
    }

    protected function register_content_controls() {
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Marquee Text', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'content_type',
            [
                'label' => __('Content Type', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'text',
                'options' => [
                    'text' => __('Text', 'unistudio-core'),
                    'icon' => __('Icon', 'unistudio-core'),
                ],
            ]
        );

        $repeater->add_control(
            'text',
            [
                'label' => __('Text', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Marquee Item', 'unistudio-core'),
                'condition' => [
                    'content_type' => 'text',
                ],
            ]
        );

        $repeater->add_control(
            'icon',
            [
                'label' => __('Icon', 'unistudio-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-star',
                    'library' => 'fa-solid',
                ],
                'condition' => [
                    'content_type' => 'icon',
                ],
            ]
        );

        // Add the repeater control to the widget
        $this->add_control(
            'marquee_items',
            [
                'label' => __('Marquee Items', 'unistudio-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'content_type' => 'text',
                        'text' => __('Customizable', 'unistudio-core'),
                    ],
                    [
                        'content_type' => 'icon',
                        'icon' => [
                            'value' => 'unicon-close',
                            'library' => 'unicons',
                        ],
                    ],
                    [
                        'content_type' => 'text',
                        'text' => __('Responsive', 'unistudio-core'),
                    ],
                    [
                        'content_type' => 'icon',
                        'icon' => [
                            'value' => 'unicon-close',
                            'library' => 'unicons',
                        ],
                    ],
                    [
                        'content_type' => 'text',
                        'text' => __('Flexibility', 'unistudio-core'),
                    ],
                    [
                        'content_type' => 'icon',
                        'icon' => [
                            'value' => 'unicon-close',
                            'library' => 'unicons',
                        ],
                    ],
                    [
                        'content_type' => 'text',
                        'text' => __('Unlimited', 'unistudio-core'),
                    ],
                    [
                        'content_type' => 'icon',
                        'icon' => [
                            'value' => 'unicon-close',
                            'library' => 'unicons',
                        ],
                    ],
                ],
                'title_field' => '{{{ content_type === "text" ? text : "Icon" }}}',
            ]
        );

        $this->end_controls_section();

        // Animation Options
        $this->start_controls_section(
            'section_animation_options',
            [
                'label' => __('Animation Options', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'enable_parallax',
            [
                'label' => __('Enable Parallax', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'no',
                'frontend_available' => true,
            ]
        );

        $this->add_control(
            'parallax_speed',
            [
                'label' => __('Parallax Speed', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => -10,
                        'max' => 10,
                        'step' => 0.1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 1,
                ],
                'condition' => [
                    'enable_parallax' => 'yes',
                ],
                'frontend_available' => true,
            ]
        );

        $this->add_control(
            'parallax_direction',
            [
                'label' => __('Parallax Direction', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'default' => 'horizontal',
                'toggle' => true,
                'options' => [
                    'horizontal' => [
                        'title' => __('Horizontal', 'unistudio-core'),
                        'icon' => 'eicon-h-align-stretch',
                    ],
                    'vertical' => [
                        'title' => __('Vertical', 'unistudio-core'),
                        'icon' => 'eicon-v-align-stretch',
                    ],
                ],
                'condition' => [
                    'enable_parallax' => 'yes',
                ],
                'frontend_available' => true,
            ]
        );


        $this->add_control(
            'animation_direction',
            [
                'label' => __('Direction', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'default' => 'left',
                'toggle' => true,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'unistudio-core'),
                        'icon' => 'eicon-arrow-left',
                    ],
                    'right' => [
                        'title' => __('Right', 'unistudio-core'),
                        'icon' => 'eicon-arrow-right',
                    ],
                ],
                'condition' => [
                    'enable_parallax!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'animation_speed',
            [
                'label' => __('Speed', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 100,
                        'step' => 1,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 25,
                ],
                'frontend_available' => true,
                'render_type' => 'template',
                'condition' => [
                    'enable_parallax!' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'pause_on_hover',
            [
                'label' => __('Pause on Hover', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'unistudio-core'),
                'label_off' => __('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'enable_parallax!' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();
    }
    
    protected function register_style_controls() {
        // General Style Section
        $this->start_controls_section(
            'section_style_general',
            [
                'label' => __('General', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'marquee_height',
            [
                'label' => __('Height', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 200,
                        'step' => 1,
                    ],
                    'em' => [
                        'min' => 1,
                        'max' => 20,
                    ],
                    'vh' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 80,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-marquee-text' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'items_gap',
            [
                'label' => __('Items Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'rem'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 128,
                    ],
                    'rem' => [
                        'min' => 0,
                        'max' => 8,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 16,
                ],
                'frontend_available' => true,
                'render_type' => 'template',
            ]
        );

        $this->end_controls_section();

        // Text Style Section
        $this->start_controls_section(
            'section_style_text',
            [
                'label' => __('Text', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'text_typography',
                'selector' => '{{WRAPPER}} .uc-marquee-text-item',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_size' => [
                        'default' => [
                            'unit' => 'px',
                            'size' => 48
                        ]
                    ],
                    'font_weight' => ['default' => '700'],
                ],
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label' => __('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-marquee-text-item' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Icon Style Section
        $this->start_controls_section(
            'section_style_icon',
            [
                'label' => __('Icon', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __('Icon Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-marquee-icon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .uc-marquee-icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => __('Icon Size', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 6,
                        'max' => 300,
                    ],
                    'em' => [
                        'min' => 0.1,
                        'max' => 20,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 48,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-marquee-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .uc-marquee-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_marquee_text')) {
            return;
        }
    
        $settings = $this->get_settings_for_display();
        
        // Get animation settings
        $direction = $settings['animation_direction'];
        
        // Base wrapper attributes
        $wrapper_attributes = [
            'class' => ['uc-marquee-text']
        ];

        // Check if parallax is enabled
        $is_parallax_enabled = isset($settings['enable_parallax']) && $settings['enable_parallax'] === 'yes';

        if ($is_parallax_enabled) {
            // Add parallax attributes
            $wrapper_attributes['data-enable-parallax'] = 'yes';
            $wrapper_attributes['data-parallax-speed'] = isset($settings['parallax_speed']['size']) ? $settings['parallax_speed']['size'] : 1;
            $wrapper_attributes['data-parallax-direction'] = isset($settings['parallax_direction']) ? $settings['parallax_direction'] : 'horizontal';
        } else {
            // Add animation attributes only if parallax is disabled
            $direction = $settings['animation_direction'];
            $wrapper_attributes['class'][] = 'uc-marquee-direction-' . $direction;
            $wrapper_attributes['data-speed'] = $settings['animation_speed']['size'];
            $wrapper_attributes['data-pause-on-hover'] = $settings['pause_on_hover'];
        }

        $this->add_render_attribute('wrapper', $wrapper_attributes);
    
        // Get items gap from settings
        $items_gap = isset($settings['items_gap']['size']) ? $settings['items_gap']['size'] : 24;
        $items_gap_unit = isset($settings['items_gap']['unit']) ? $settings['items_gap']['unit'] : 'px';
        
        // Add gap as a CSS variable
        $this->add_render_attribute('wrapper', 'style', '--gap-size: ' . $items_gap . $items_gap_unit . ';');
        
        ?>
        <div <?php echo $this->get_render_attribute_string('wrapper'); ?>>
            <div class="uc-marquee-container">
                <h4 class="uc-marquee-content">
                    <?php foreach ($settings['marquee_items'] as $index => $item) : 
                        $item_style = '';
                        if (isset($item['items_gap']['size'])) {
                            $items_gap = $item['items_gap']['size'];
                            $items_gap_unit = $item['items_gap']['unit'];
                            $item_style = 'margin-right: ' . $items_gap . $items_gap_unit . ';';
                        }
                    ?>
                        <div class="uc-marquee-item" <?php echo $item_style ? 'style="' . esc_attr($item_style) . '"' : ''; ?>>
                            <?php if ($item['content_type'] === 'text') : ?>
                                <span class="uc-marquee-text-item"><?php echo esc_html($item['text']); ?></span>
                            <?php else : ?>
                                <span class="uc-marquee-icon">
                                    <?php \Elementor\Icons_Manager::render_icon($item['icon'], ['aria-hidden' => 'true']); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </h4>
            </div>
        </div>
        <?php
    }
}