<?php
namespace UniStudioCore\ElementorManager\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use UniStudioCore\Settings;
use UniStudioCore\Asset_Manager;

class Tabs extends Widget_Base {
    public function get_name() {
        return 'uc_tabs';
    }
    
    public function get_title() {
        return __('UC - Tabs', 'unistudio-core');
    }
    
    public function get_icon() {
        return 'eicon-tabs';
    }
    
    public function get_categories() {
        return ['uc-elements'];
    }
    
    public function get_script_depends() {
        return ['uc-tabs'];
    }

    public function get_style_depends() {
        return ['uc-tabs'];
    }

    public function register_widget_scripts() {
        Asset_Manager::getInstance()->register_widget_script(
            'uc-tabs',
            'assets/js/widgets/tabs.min.js',
            ['uc-core']
        );
    }

    public function register_widget_styles() {
        Asset_Manager::getInstance()->register_widget_style(
            'uc-tabs',
            'assets/css/widgets/tabs.min.css',
            ['uc-core']
        );
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'tab_content_section',
            [
                'label' => esc_html__('Content', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'tab_title',
            [
                'label' => esc_html__('Title', 'unistudio-core'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Tab Item', 'unistudio-core'),
                'dynamic' => [
                    'active' => true,
                ],
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'tab_content',
            [
                'label' => esc_html__('Content', 'unistudio-core'),
                'type' => Controls_Manager::WYSIWYG,
                'default' => esc_html__('Tab Content', 'unistudio-core'),
                'dynamic' => [
                    'active' => true,
                ],
            ]
        );

        $repeater->add_control(
            'tab_icon',
            [
                'label' => esc_html__('Icon', 'unistudio-core'),
                'type' => Controls_Manager::ICONS,
                'default' => [
                    'library' => 'unicons',
                ],
                'recommended' => [
                    'unicons' => [
                        'star-filled',
                        'star',
                        'chevron-down',
                        'chevron-up',
                        'chevron-left',
                        'chevron-right',
                        'chevron-right',
                        'add',
                        'add-alt',
                        'add-alt-filled',
                        'close',
                        'close-outline',
                    ],
                ],
            ]
        );

        $repeater->add_control(
            'is_disabled',
            [
                'label' => esc_html__('Disabled?', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'unistudio-core'),
                'label_off' => esc_html__('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'tabs',
            [
                'label' => esc_html__('Tabs Items', 'unistudio-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'tab_title' => esc_html__('Tab Item', 'unistudio-core'),
                        'tab_content' => esc_html__('Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'unistudio-core'),
                    ],
                    [
                        'tab_title' => esc_html__('Tab Item', 'unistudio-core'),
                        'tab_content' => esc_html__('Ut enim ad minim veniam, quis nostrud exercitation ullamco.', 'unistudio-core'),
                    ],
                ],
                'title_field' => '{{{ tab_title }}}',
            ]
        );

        $this->end_controls_section();

        // Options Section
        $this->start_controls_section(
            'section_options',
            [
                'label' => esc_html__('Options', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'active_tab',
            [
                'label' => esc_html__('Active Tab', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'default' => 0,
                'description' => esc_html__('Index of initially active tab (0 based)', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'tab_animation',
            [
                'label' => esc_html__('Tab animation', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => esc_html__('None', 'unistudio-core'),
                    'uc-animation-fade' => esc_html__('Fade', 'unistudio-core'),
                    'uc-animation-slide-top-small, uc-animation-slide-bottom-small' => esc_html__('Slide Bottom', 'unistudio-core'),
                    'uc-animation-slide-bottom-small, uc-animation-slide-top-small' => esc_html__('Slide Top', 'unistudio-core'),
                    'uc-animation-slide-right-small, uc-animation-slide-left-small' => esc_html__('Slide Left', 'unistudio-core'),
                    'uc-animation-slide-left-small, uc-animation-slide-right-small' => esc_html__('Slide Right', 'unistudio-core'),
                    'uc-animation-scale-up, uc-animation-scale-down' => esc_html__('Scale Up', 'unistudio-core'),
                    'uc-animation-scale-down, uc-animation-scale-up' => esc_html__('Scale Down', 'unistudio-core'),
                ],
            ]
        );

        $this->add_control(
            'tab_duration',
            [
                'label' => esc_html__('Tab animation duration', 'unistudio-core'),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 1000,
                'step' => 50,
                'default' => 200,
                'condition' => [
                    'tab_animation!' => 'none',
                ],
            ]
        );

        $this->add_control(
            'swiping',
            [
                'label' => esc_html__('Enable Swiping', 'unistudio-core'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'unistudio-core'),
                'label_off' => esc_html__('No', 'unistudio-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'media',
            [
                'label' => esc_html__('Responsive Mode', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => esc_html__('Always', 'unistudio-core'),
                    '@s' => esc_html__('Small (640px)', 'unistudio-core'),
                    '@m' => esc_html__('Medium (960px)', 'unistudio-core'),
                    '@l' => esc_html__('Large (1200px)', 'unistudio-core'),
                    '@xl' => esc_html__('X-Large (1600px)', 'unistudio-core'),
                ],
            ]
        );

        $this->end_controls_section();

        // Style Sections
        $this->start_controls_section(
            'section_tabs_style',
            [
                'label' => esc_html__('Tab Nav', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'tab_position',
            [
                'label' => esc_html__('Tab Position', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => [
                    '' => esc_html__('Top', 'unistudio-core'),
                    'uc-tab-left' => esc_html__('Left', 'unistudio-core'),
                    'uc-tab-right' => esc_html__('Right', 'unistudio-core'),
                ],
                'prefix_class' => 'uc-tab-position-',
            ]
        );

        $this->add_responsive_control(
            'tab_align',
            [
                'label' => esc_html__('Alignment', 'unistudio-core'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__('Left', 'unistudio-core'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'unistudio-core'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => esc_html__('Right', 'unistudio-core'),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__('Justify', 'unistudio-core'),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'default' => 'flex-start',
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab]' => 'justify-content: {{VALUE}};',
                    '{{WRAPPER}} [data-uc-tab] > *' => '{{VALUE}} === "justify" ? "flex: 1;" : ""',
                ],
                'prefix_class' => 'uc-tab-align-',
                'condition' => [
                    'tab_position' => '',
                ],
            ]
        );
    
        $this->add_responsive_control(
            'tab_gap',
            [
                'label' => esc_html__('Gap', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 128,
                    ],
                ],
                'default' => [
                    'size' => 8,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab]' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'tab_typography',
                'selector' => '{{WRAPPER}} [data-uc-tab] > * > a',
            ]
        );

        $this->start_controls_tabs('tabs_colors');

        $this->start_controls_tab(
            'tabs_colors_normal',
            [
                'label' => esc_html__('Normal', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'tab_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > * > a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'tab_background_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > * > a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'tab_padding',
            [
                'label' => esc_html__('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > * > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'tab_border',
                'selector' => '{{WRAPPER}} [data-uc-tab] > * > a',
            ]
        );

        $this->add_responsive_control(
            'tab_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '0',
                    'left' => '0',
                    'unit' => 'px',
                    'isLinked' => true,
                ],
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > * > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'tab_box_shadow',
                'selector' => '{{WRAPPER}} [data-uc-tab] > * > a',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tabs_colors_hover',
            [
                'label' => esc_html__('Hover', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'tab_hover_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > * > a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'tab_hover_background_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > * > a:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'tab_hover_padding',
            [
                'label' => esc_html__('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > * > a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'tab_hover_border',
                'selector' => '{{WRAPPER}} [data-uc-tab] > * > a:hover',
            ]
        );

        $this->add_responsive_control(
            'tab_hover_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > * > a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'tab_hover_box_shadow',
                'selector' => '{{WRAPPER}} [data-uc-tab] > * > a:hover',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tabs_colors_active',
            [
                'label' => esc_html__('Active', 'unistudio-core'),
            ]
        );

        $this->add_control(
            'tab_active_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > .uc-active > a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'tab_active_background_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > .uc-active > a' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'tab_active_padding',
            [
                'label' => esc_html__('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > .uc-active > a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'tab_active_border',
                'selector' => '{{WRAPPER}} [data-uc-tab] > .uc-active > a',
            ]
        );

        $this->add_responsive_control(
            'tab_active_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > .uc-active > a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'tab_active_box_shadow',
                'selector' => '{{WRAPPER}} [data-uc-tab] > .uc-active > a',
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_control(
            'tab_transition_heading',
            [
                'label' => esc_html__('Transition', 'unistudio-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );
        
        $this->add_control(
            'tab_transition_duration',
            [
                'label' => esc_html__('Transition Duration', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'default' => [
                    'size' => 0.2,
                ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 3,
                        'step' => 0.1,
                    ]
                ],
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > * > a' => 'transition-duration: {{SIZE}}s;',
                ],
            ]
        );
        
        $this->add_control(
            'tab_transition_timing',
            [
                'label' => esc_html__('Timing Function', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'ease',
                'options' => [
                    'linear' => esc_html__('Linear', 'unistudio-core'),
                    'ease' => esc_html__('Ease', 'unistudio-core'),
                    'ease-in' => esc_html__('Ease In', 'unistudio-core'),
                    'ease-out' => esc_html__('Ease Out', 'unistudio-core'),
                    'ease-in-out' => esc_html__('Ease In Out', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > * > a' => 'transition-timing-function: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'tab_transition_property',
            [
                'label' => __('Transition Properties', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'all',
                'options' => [
                    'all' => __('All', 'unistudio-core'),
                    'none' => __('None', 'unistudio-core'),
                    'background' => __('Background Only', 'unistudio-core'),
                    'background, color' => __('Background & Color', 'unistudio-core'),
                    'background, border' => __('Background & Border', 'unistudio-core'),
                    'background, border, color' => __('Background, Border & Color', 'unistudio-core'),
                    'background, border, border-radius, color, box-shadow' => __('All Properties', 'unistudio-core'),
                ],
                'selectors' => [
                    '{{WRAPPER}} [data-uc-tab] > * > a' => 'transition-property: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Content Style Section
        $this->start_controls_section(
            'section_content_style',
            [
                'label' => esc_html__('Tab Content', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_typography',
                'selector' => '{{WRAPPER}} .uc-switcher > *',
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__('Text Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-switcher > *' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'content_background_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .uc-switcher > *' => 'background-color: {{VALUE}};',
                ],
            ]
        );
         
        $this->add_responsive_control(
            'content_padding',
            [
                'label' => esc_html__('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-switcher > *' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_margin',
            [
                'label' => esc_html__('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-switcher > *' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'content_border',
                'selector' => '{{WRAPPER}} .uc-switcher > *',
            ]
        );

        $this->add_responsive_control(
            'content_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-switcher > *' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'content_box_shadow',
                'selector' => '{{WRAPPER}} .uc-switcher > *',
            ]
        );

        
        $this->end_controls_section();

        // Tab Wrapper Style Section
        $this->start_controls_section(
            'section_wrapper_style',
            [
                'label' => esc_html__('Tab Wrapper', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'wrapper_background_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '#EBEBEB',
                'selectors' => [
                    '{{WRAPPER}} .uc-tab-wrapper' => 'background-color: {{VALUE}};',
                ],
            ]
        );
         
        $this->add_responsive_control(
            'wrapper_padding',
            [
                'label' => esc_html__('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-tab-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_margin',
            [
                'label' => esc_html__('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-tab-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'wrapper_border',
                'selector' => '{{WRAPPER}} .uc-tab-wrapper',
            ]
        );

        $this->add_responsive_control(
            'wrapper_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%', 'em'],
                'default' => [
                    'top' => '8',
                    'right' => '8',
                    'bottom' => '8',
                    'left' => '8',
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-tab-wrapper' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'wrapper_box_shadow',
                'selector' => '{{WRAPPER}} .uc-tab-wrapper',
            ]
        );

        
        $this->end_controls_section();

        // Tab Nav Wrapper Style Section
        $this->start_controls_section(
            'section_tab_nav_style',
            [
                'label' => esc_html__('Tab Nav Wrapper', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
    
        $this->add_responsive_control(
            'tab_nav_min_width',
            [
                'label' => esc_html__('Min Width', 'unistudio-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 1280,
                    ],
                ],
                'default' => [
                    'size' => 250,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .uc-tab' => 'min-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'tab_nav_background_color',
            [
                'label' => esc_html__('Background Color', 'unistudio-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .uc-tab' => 'background-color: {{VALUE}};',
                ],
            ]
        );
         
        $this->add_responsive_control(
            'tab_nav_padding',
            [
                'label' => esc_html__('Padding', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-tab' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'tab_nav_margin',
            [
                'label' => esc_html__('Margin', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-tab' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'tab_nav_border',
                'selector' => '{{WRAPPER}} .uc-tab',
            ]
        );

        $this->add_responsive_control(
            'tab_nav_border_radius',
            [
                'label' => esc_html__('Border Radius', 'unistudio-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .uc-tab' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'tab_nav_box_shadow',
                'selector' => '{{WRAPPER}} .uc-tab',
            ]
        );

        
        $this->end_controls_section();
    }
    
    protected function render() {
        $check_settings = Settings::getInstance();
        if (!$check_settings->isEnabled('widget_tabs')) {
            return;
        }

        $settings = $this->get_settings_for_display();
        
        // Generate unique IDs for connecting tabs with switcher
        $tabs_id = 'uc-tabs-' . $this->get_id();
        $switcher_id = 'uc-switcher-' . $this->get_id();

        // Prepare tabs options
        $tabs_options = [];

        $tabs_options[] = 'connect: #' . $switcher_id;
        
        if (!empty($settings['tab_animation'])) {
            $tabs_options[] = 'animation: ' . $settings['tab_animation'];
        }

        if ($settings['tab_duration']) {
            $tabs_options[] = 'duration: ' . $settings['tab_duration'];
        }

        // Swiping
        if ($settings['swiping'] === 'yes') {
            $tabs_options[] = 'swiping: true';
        }
        
        // Media
        if (!empty($settings['media'])) {
            $tabs_options[] = 'media: ' . $settings['media'];
        }
        
        // Active tab
        if (isset($settings['active_tab'])) {
            $tabs_options[] = 'active: ' . $settings['active_tab'];
        }

        $options_string = implode('; ', $tabs_options);

        $tab_classes = ['uc-tab'];
        if (!empty($settings['tab_position'])) {
            $tab_classes[] = $settings['tab_position'];
        }
        ?>

        <div class="uc-tab-wrapper">
            <!-- Tabs Navigation -->
            <ul <?php echo !empty($tabs_id) ? ' id="' . esc_attr($tabs_id) . '"' : ''; ?> class="<?php echo esc_attr(implode(' ', $tab_classes)); ?>" data-uc-tab<?php echo !empty($options_string) ? '="' . esc_attr($options_string) . '"' : ''; ?>>
                <?php foreach ($settings['tabs'] as $index => $item) : 
                    $tab_count = $index + 1;
                    $tab_classes = ['uc-tab-item'];
                    
                    if ($settings['active_tab'] === $index) {
                        $tab_classes[] = 'uc-active';
                    }
                    
                    if ($item['is_disabled'] === 'yes') {
                        $tab_classes[] = 'uc-disabled';
                    }
                    ?>
                    <li class="<?php echo esc_attr(implode(' ', $tab_classes)); ?>">
                        <a href="#">
                            <?php if (!empty($item['tab_icon']['value'])) : ?>
                                <span class="uc-tab-icon">
                                    <?php \Elementor\Icons_Manager::render_icon($item['tab_icon'], ['aria-hidden' => 'true']); ?>
                                </span>
                            <?php endif; ?>
                            <span class="uc-tab-title"><?php echo esc_html($item['tab_title']); ?></span>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>

            <!-- Tab Content -->
            <div class="uc-switcher"<?php echo !empty($switcher_id) ? ' id="' . esc_attr($switcher_id) . '"' : ''; ?>>
                <?php foreach ($settings['tabs'] as $index => $item) : ?>
                    <div class="uc-tab-content">
                        <?php echo wp_kses_post($item['tab_content']); ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    protected function content_template() {
        ?>
        <div class="uc-tab-wrapper">
            <# 
            // Generate unique IDs
            var tabsId = 'uc-tabs-' + view.getIDInt();
            var switcherId = 'uc-switcher-' + view.getIDInt();
            
            // Build options array
            var tabOptions = [];
            tabOptions.push('connect: #' + switcherId);
            
            // Animation
            if (settings.tab_animation) {
                tabOptions.push('animation: ' + settings.tab_animation);
            }
    
            // Duration
            if (settings.tab_duration) {
                tabOptions.push('duration: ' + settings.tab_duration);
            }
            
            // Swiping
            if (settings.swiping === 'yes') {
                tabOptions.push('swiping: true');
            }
            
            // Media
            if (settings.media) {
                tabOptions.push('media: ' + settings.media);
            }
            
            // Active tab
            if (settings.active_tab >= 0) {
                tabOptions.push('active: ' + settings.active_tab);
            }
            
            var optionsString = tabOptions.join('; ');
            #>
            
            <!-- Tabs Navigation -->
            <ul id="{{ tabsId }}" class="uc-tab" data-uc-tab="{{ optionsString }}">
                <# if (settings.tabs) {
                    _.each(settings.tabs, function(item, index) {
                        var tabClasses = ['uc-tab-item'];
                        
                        if (settings.active_tab === index) {
                            tabClasses.push('uc-active');
                        }
                        
                        if (item.is_disabled === 'yes') {
                            tabClasses.push('uc-disabled');
                        }
                        #>
                        <li class="{{ tabClasses.join(' ') }}">
                            <a href="#">
                                <# if (item.tab_icon && item.tab_icon.value) { #>
                                    <span class="uc-tab-icon">
                                        {{{ elementor.helpers.renderIcon(view, item.tab_icon, {}, 'i', 'object').value }}}
                                    </span>
                                <# } #>
                                <span class="uc-tab-title">{{{ item.tab_title }}}</span>
                            </a>
                        </li>
                    <# });
                } #>
            </ul>
    
            <!-- Tab Content -->
            <div id="{{ switcherId }}" class="uc-switcher">
                <# if (settings.tabs) {
                    _.each(settings.tabs, function(item, index) { #>
                        <div class="uc-tab-content">
                            {{{ item.tab_content }}}
                        </div>
                    <# });
                } #>
            </div>
        </div>
        <?php
    }
}