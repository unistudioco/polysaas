<?php
namespace UniStudioCore\ElementorManager\Helpers;

use Elementor\Plugin;
use Walker_Nav_Menu;

class NavbarWalker extends Walker_Nav_Menu {
    private $mega_menu_items = array();
    private $drop_options = '';

    public function set_drop_options($options) {
        $this->drop_options = $options;
    }
    
    private function get_elementor_content($mega_menu_id) {
        if (!class_exists('\Elementor\Plugin')) {
            return '';
        }

        $elementor = Plugin::instance();
        $document = $elementor->documents->get($mega_menu_id);
        
        if (!$document) {
            return '';
        }

        // Store current post and global states
        $current_post = get_post();
        
        // Switch to mega menu post
        global $post;
        $post = get_post($mega_menu_id);
        setup_postdata($post);

        // Force frontend mode
        $is_edit_mode = $elementor->editor->is_edit_mode();
        $elementor->editor->set_edit_mode(false);

        // Get the content
        $content = $elementor->frontend->get_builder_content($mega_menu_id, true);

        // Reset edit mode
        $elementor->editor->set_edit_mode($is_edit_mode);

        // Reset everything back
        $post = $current_post;
        if ($current_post) {
            setup_postdata($current_post);
        }

        return $content;
    }

    public function start_el(&$output, $item, $depth = 0, $args = array(), $id = 0) {
        $indent = ($depth) ? str_repeat("\t", $depth) : '';
        
        // Store item for mega menu check
        $this->mega_menu_items[] = $item;

        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;

        // Check for mega menu
        $is_mega_menu = get_post_meta($item->ID, '_uc_mega_menu_enabled', true);
        $mega_menu_id = get_post_meta($item->ID, '_uc_mega_menu_id', true);

        if ($depth === 0 && $is_mega_menu) {
            $classes[] = 'uc-mega-menu-item';
        }

        if($args->walker->has_children) {
            $classes[] = 'uc-parent';
        }

        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
        $class_names = ' class="' . esc_attr($class_names) . '"';

        $id = apply_filters('nav_menu_item_id', 'menu-item-'. $item->ID, $item, $args);
        $id = strlen($id) ? ' id="' . esc_attr($id) . '"' : '';

        $output .= $indent . '<li' . $id . $class_names . '>';

        $atts = array();
        $atts['title']  = !empty($item->attr_title) ? $item->attr_title : '';
        $atts['target'] = !empty($item->target) ? $item->target : '';
        $atts['rel']    = !empty($item->xfn) ? $item->xfn : '';
        $atts['href']   = !empty($item->url) ? $item->url : '#';

        if ($depth === 0 && $is_mega_menu) {
            $atts['role'] = 'button';
            $atts['aria-haspopup'] = 'true';
            $atts['class'] = 'uc-has-mega-menu';
            if ($mega_menu_id) {
                $atts['data-mega-menu-id'] = $mega_menu_id;
            }
        }

        $atts = apply_filters('nav_menu_link_attributes', $atts, $item, $args);

        $attributes = '';
        foreach ($atts as $attr => $value) {
            if (!empty($value)) {
                $value = ('href' === $attr) ? esc_url($value) : esc_attr($value);
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }

        $item_output = $args->before;
        $item_output .= '<a'. $attributes .'>';
        $item_output .= $args->link_before . apply_filters('the_title', $item->title, $item->ID) . $args->link_after;
        
        if ($depth === 0 && ($args->walker->has_children || $is_mega_menu)) {
            $item_output .= '<span data-uc-navbar-parent-icon></span>';
        }
        
        $item_output .= '</a>';

        // Add mega menu content directly after the link
        if ($depth === 0 && $is_mega_menu && $mega_menu_id) {
            $content = $this->get_elementor_content($mega_menu_id);
            if ($content) {
                $item_output .= sprintf(
                    '<div class="uc-dropbar uc-dropbar-top hide-scrollbar uc-drop" data-uc-drop="%s">
                        <div class="uc-dropbar-content">%s</div>
                    </div>',
                    esc_attr($this->drop_options),
                    $content
                );
            }
        }

        $item_output .= $args->after;
        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }

    public function start_lvl(&$output, $depth = 0, $args = array()) {
        $indent = str_repeat("\t", $depth);
        
        // Check if this is a regular dropdown (not mega menu)
        $parent_item = end($this->mega_menu_items);
        if (!($depth === 0 && $parent_item && get_post_meta($parent_item->ID, '_uc_mega_menu_enabled', true))) {
            $submenu = ($depth > 0) ? ' uc-navbar-sub uc-navbar-dropdown-nav' : ' uc-navbar-dropdown-nav';
            $dropdown = ($depth > 0) ? "" : "<div class=\"uc-navbar-dropdown\">";
            $output .= "\n$indent$dropdown<ul class=\"uc-nav$submenu\">\n";
        }
    }

    public function end_el(&$output, $item, $depth = 0, $args = array()) {
        array_pop($this->mega_menu_items);
        $output .= "</li>\n";
    }

    public function end_lvl(&$output, $depth = 0, $args = array()) {
        $indent = str_repeat("\t", $depth);
        
        // Check if this is a regular dropdown (not mega menu)
        $parent_item = end($this->mega_menu_items);
        if (!($depth === 0 && $parent_item && get_post_meta($parent_item->ID, '_uc_mega_menu_enabled', true))) {
            $dropdown = ($depth > 0) ? "" : "</div>";
            $output .= "$indent</ul>$dropdown\n";
        }
    }
}