<?php
namespace UniStudioCore\ElementorManager\Documents;

use Elementor\Core\DocumentTypes\Post;
use Elementor\Controls_Manager;
use Elementor\Modules\Library\Documents\Library_Document;

class Global_Section extends Library_Document {
    public static function get_properties() {
        $properties = parent::get_properties();
        
        $properties['support_kit'] = true;
        $properties['support_site_editor'] = true;
        $properties['show_in_library'] = true;
        $properties['cpt'] = ['uc_global_sections'];
        
        return $properties;
    }

    public function get_name() {
        return 'uc_global_sections';
    }

    public static function get_title() {
        return __('Global Section', 'unistudio-core');
    }

    protected function register_controls() {
        parent::register_controls();

        $this->start_controls_section(
            'section_display_conditions',
            [
                'label' => __('Display Conditions', 'unistudio-core'),
                'tab' => Controls_Manager::TAB_SETTINGS,
            ]
        );

        $this->add_control(
            'preview_type',
            [
                'label' => esc_html__('Preview Type', 'unistudio-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'generic',
                'options' => [
                    'generic' => esc_html__('Generic Section', 'unistudio-core'),
                    'header' => esc_html__('Header', 'unistudio-core'),
                    'footer' => esc_html__('Footer', 'unistudio-core'),
                    'megamenu' => esc_html__('Mega Menu', 'unistudio-core'),
                    'offcanvas' => esc_html__('Off Canvas', 'unistudio-core'),
                    'popup' => esc_html__('Popup', 'unistudio-core'),
                    'card' => esc_html__('Dynamic Card', 'unistudio-core'),
                    'pagecover' => esc_html__('Page Cover', 'unistudio-core'),
                ],
            ]
        );

        $this->add_control(
            'display_on',
            [
                'label' => __('Display On', 'unistudio-core'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => [
                    'entire_site' => __('Entire Site', 'unistudio-core'),
                    'front_page' => __('Front Page', 'unistudio-core'),
                    'archive' => __('Archive Pages', 'unistudio-core'),
                    'single' => __('Single Posts', 'unistudio-core'),
                    'pages' => __('Pages', 'unistudio-core'),
                ],
                'default' => ['entire_site'],
            ]
        );

        $this->add_control(
            'exclude_from',
            [
                'label' => __('Exclude From', 'unistudio-core'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => [
                    'front_page' => __('Front Page', 'unistudio-core'),
                    'archive' => __('Archive Pages', 'unistudio-core'),
                    'single' => __('Single Posts', 'unistudio-core'),
                    'pages' => __('Pages', 'unistudio-core'),
                ],
            ]
        );

        $this->add_control(
            'specific_pages',
            [
                'label' => __('Specific Pages', 'unistudio-core'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->get_all_pages(),
                'condition' => [
                    'display_on' => 'pages',
                ],
            ]
        );

        $this->add_control(
            'user_roles',
            [
                'label' => __('User Roles', 'unistudio-core'),
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $this->get_user_roles(),
            ]
        );

        $this->end_controls_section();
    }

    private function get_all_pages() {
        $pages = get_pages();
        $options = [];
        
        foreach ($pages as $page) {
            $options[$page->ID] = $page->post_title;
        }
        
        return $options;
    }

    private function get_user_roles() {
        global $wp_roles;
        return $wp_roles->get_names();
    }

    public function get_preview_as_query_args() {
        return [
            'preview_section' => $this->get_main_id(),
        ];
    }
}