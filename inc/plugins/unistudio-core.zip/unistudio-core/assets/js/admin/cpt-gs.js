(function($) {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.uc-preview-iframe').forEach(function(container) {
            const btn = container.querySelector('.btn');
            const holder = container.querySelector('.uc-preview-iframe-holder');
            const iframe = holder.querySelector('iframe');
    
            btn.addEventListener('mouseenter', function(e) {
                // Load iframe if not loaded
                if (!iframe.src) {
                    iframe.src = iframe.dataset.src;
                }
    
                // Get button position
                const btnRect = btn.getBoundingClientRect();
                const holderWidth = 680;
                const holderHeight = 420;
                
                // Calculate available space
                const spaceBelow = window.innerHeight - btnRect.bottom;
                const spaceLeft = window.innerWidth - btnRect.right;
                
                // Position the holder
                let top = btnRect.bottom - 30;
                let right = btnRect.right;
    
                // Check if preview would go below viewport
                if (spaceBelow < holderHeight + 10) {
                    top = btnRect.top - holderHeight + 150;
                }
    
                // Check if preview would go beyond right edge
                if (spaceLeft < holderWidth) {
                    right = window.innerWidth - holderWidth - 300;
                }
    
                // Apply position
                holder.style.top = `${top}px`;
                holder.style.right = `${right}px`;
                holder.style.display = 'block';
            });
    
            // Hide preview when mouse leaves either the button or the preview
            [btn, holder].forEach(element => {
                element.addEventListener('mouseleave', function(e) {
                    // Check if mouse moved to the other element
                    const relatedTarget = e.relatedTarget;
                    if (!btn.contains(relatedTarget) && !holder.contains(relatedTarget)) {
                        holder.style.display = 'none';
                    }
                });
            });
        });
    });

    // Shortcode copy functionality
    $('.uc-copy-shortcode').on('click', function() {
        const $button = $(this);
        const shortcode = $button.data('shortcode');
        
        // Create temporary input
        const $temp = $('<input>');
        $('body').append($temp);
        $temp.val(shortcode).select();
        
        // Copy and remove temp input
        document.execCommand('copy');
        $temp.remove();
        
        // Show feedback
        const $icon = $button.find('.dashicons');
        $icon.removeClass('dashicons-clipboard').addClass('dashicons-yes');
        
        setTimeout(function() {
            $icon.removeClass('dashicons-yes').addClass('dashicons-clipboard');
        }, 1000);
    });
    
})(jQuery);