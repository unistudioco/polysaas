(function($) {
    'use strict';

    $(document).ready(function() {
        // Initialize Select2 for default header/footer selects
        $('.uc-select2').select2({
            width: '100%',
            minimumResultsForSearch: 10,
            dropdownAutoWidth: true,
            dropdownParent: $('.unicore-wrap')
        });
    });
})(jQuery);