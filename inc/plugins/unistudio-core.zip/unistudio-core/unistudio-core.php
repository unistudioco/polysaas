<?php
/**
 * Plugin Name: UniStudio Core
 * Description: Core plugin for our themes to add advanced WordPress functionalities
 * Version: 1.0.0
 * Author: UniStudio Inc
 * Text Domain: unistudio-core
 * Domain Path: /languages
 */

namespace UniStudioCore;

use UniStudioCore\ACF\ACF_Options;

// If this file is called directly, abort.
if (!defined('ABSPATH')) {
    exit;
}

class UniStudioCore {
    private static $instance = null;
    private $settings;
    private $global_sections;
    private $post_types;
    private $acf;
    private $mega_menu;
    private $elementor;
    private $logger;
    private $display_conditions;

    public static function getInstance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->define_constants();
        $this->init_components();
    }

    private function define_constants() {
        define('UC_VERSION', '1.0.0');
        define('UC_FILE', __FILE__);
        define('UC_PATH', plugin_dir_path(UC_FILE));
        define('UC_URL', plugin_dir_url(UC_FILE));
        define('ALLOW_UNFILTERED_UPLOADS', true);
    }

    private function init_components() {
        // Initialize core components
        $this->settings                 = Settings::getInstance();
        $this->display_conditions       = Display_Conditions::getInstance();
        $this->global_sections          = Global_Sections::getInstance();
        $this->post_types               = Post_Types::getInstance();
        $this->acf                      = ACF_Fields::getInstance();
        $this->mega_menu                = Mega_Menu::getInstance();
        $this->elementor                = ElementorManager::getInstance();
        $this->logger                   = Logger::getInstance();
        
        // Initialize plugin components
        add_action('plugins_loaded', [$this, 'loadTextdomain']);
        add_action('admin_init', [$this, 'checkDependencies']);
    }

    public function loadTextdomain() {
        load_plugin_textdomain('unistudio-core', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    public function checkDependencies() {
        if (!class_exists('ACF')) {
            add_action('admin_notices', function() {
                echo '<div class="error"><p>' . 
                     esc_html__('UniStudio Core requires Advanced Custom Fields to be installed and activated.', 'unistudio-core') . 
                     '</p></div>';
            });
        }
        
        if (!did_action('elementor/loaded')) {
            add_action('admin_notices', function() {
                echo '<div class="error"><p>' . 
                     esc_html__('UniStudio Core requires Elementor to be installed and activated.', 'unistudio-core') . 
                     '</p></div>';
            });
        }
    }
}


spl_autoload_register(function ($class) {
    // Project-specific namespace prefix
    $prefix = 'UniStudioCore\\';
    
    // Base directory for the namespace prefix
    $base_dir = plugin_dir_path(__FILE__) . 'includes/';
    
    // Check if the class uses the namespace prefix
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    // Get the relative class name
    $relative_class = substr($class, $len);
    
    // Special handling for Elementor-related classes
    $namespace_mappings = [
        'ElementorManager\\Widgets\\' => 'elementor-manager/widgets/',
        'ElementorManager\\DynamicTags\\' => 'elementor-manager/dynamic-tags/',
        'ElementorManager\\Helpers\\' => 'elementor-manager/helpers/',
        'ElementorManager\\Documents\\' => 'elementor-manager/documents/',
        'ElementorManager\\' => 'elementor-manager/',
        'ElementorManager' => 'elementor-manager/class-elementor-manager.php',
    ];

    // Check for special namespace mappings
    foreach ($namespace_mappings as $namespace => $path) {
        if (strpos($relative_class, $namespace) === 0) {
            if (substr($path, -4) === '.php') {
                // Direct file mapping
                $file = $base_dir . $path;
            } else {
                // Directory mapping
                $class_path = substr($relative_class, strlen($namespace));
                
                // Convert class name to filename, replacing both underscores and camel case
                $filename = strtolower(preg_replace(['/([a-z\d])([A-Z])/', '/([^-])_([^-])/'], '$1-$2', $class_path));
                $file = $base_dir . $path . 'class-' . $filename . '.php';
            }            
            if (file_exists($file)) {
                require $file;
                return;
            } else {
                return;
            }
        }
    }

    // Regular class handling for non-special cases
    $file = str_replace('\\', '/', $relative_class);
    $file = strtolower(preg_replace(['/([a-z\d])([A-Z])/', '/([^-])_([^-])/'], '$1-$2', $file));
    $file = str_replace('_', '-', $file);
    $file = preg_replace('/([^\/]+)$/', 'class-$1', $file);
    $file = $base_dir . $file . '.php';

    if (file_exists($file)) {
        require $file;
    } else {
        error_log("File not found: " . $file);
    }
});

// Initialize the plugin
add_action('plugins_loaded', function() {
    UniStudioCore::getInstance();
});