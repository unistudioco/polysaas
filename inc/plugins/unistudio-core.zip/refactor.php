<?php
/**
 * Refactoring script to update plugin files to use namespaces
 * Save this as refactor.php in your plugin root directory
 */

class PluginRefactor {
    private $plugin_dir;
    private $namespace = 'UniStudioCore';
    private $class_map = [];
    private $file_map = [];
    private $namespace_map = [
        'includes/' => 'UniStudioCore',
        'includes/elementor/' => 'UniStudioCore\\ElementorManager',
        'includes/elementor/widgets/' => 'UniStudioCore\\ElementorManager\\Widgets',
        'includes/elementor/helpers/' => 'UniStudioCore\\ElementorManager\\Helpers',
    ];

    public function __construct($plugin_dir) {
        $this->plugin_dir = rtrim($plugin_dir, '/');
        $this->buildClassMap();
    }

    private function buildClassMap() {
        // Map old class names to new namespaced names
        $this->class_map = [
            'UC_Settings' => 'UniStudioCore\\Settings',
            'UC_Template_Loader' => 'UniStudioCore\\Template_Loader',
            'UC_Post_Types' => 'UniStudioCore\\Post_Types',
            'UC_Taxonomies' => 'UniStudioCore\\Taxonomies',
            'UC_ACF' => 'UniStudioCore\\ACF',
            'UC_Mega_Menu' => 'UniStudioCore\\Mega_Menu',
            'UC_Logger' => 'UniStudioCore\\Logger',
            'UC_Asset_Manager' => 'UniStudioCore\\Asset_Manager',
            'UC_Elementor' => 'UniStudioCore\\ElementorManager',
            'UC_Elementor_Navbar_Walker' => 'UniStudioCore\\ElementorManager\\Helpers\\Navbar_Walker',
        
            
            // Widget mappings
            'UC_Accordion_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Accordion',
            'UC_Heading_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Heading',
            'UC_Header_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Header',
            'UC_Logo_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Logo',
            'UC_Menu_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Menu',
            'UC_Button_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Button',
            'UC_Tabs_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Tabs',
            'UC_Slider_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Slider',
            'UC_Icon_Box_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Icon_Box',
            'UC_Image_Box_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Image_Box',
            'UC_Animated_Text_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Animated_Text',
            'UC_Marquee_Text_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Marquee_Text',
            'UC_Portfolio_Grid_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Portfolio_Grid',
            'UC_Team_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Team',
            'UC_Team_Slider_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Team_Slider',
            'UC_Testimonials_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Testimonials',
            'UC_Price_Table_Widget' => 'UniStudioCore\\ElementorManager\\Widgets\\Price_Table',
            
            // Dynamic tags mappings
            'UC_Post_Title_Tag' => 'UniStudioCore\\ElementorManager\\DynamicTags\\Post_Title',
            'UC_Post_URL_Tag' => 'UniStudioCore\\ElementorManager\\DynamicTags\\Post_URL',
            'UC_Post_Excerpt_Tag' => 'UniStudioCore\\ElementorManager\\DynamicTags\\Post_Excerpt',
            'UC_Featured_Image_Tag' => 'UniStudioCore\\ElementorManager\\DynamicTags\\Featured_Image',
        ];

        // Map old filenames to new ones
        $this->file_map = [
            'class-uc-settings.php' => 'class-settings.php',
            'class-uc-template-loader.php' => 'class-template-loader.php',
            'class-uc-post-types.php' => 'class-post-types.php',
            'class-uc-taxonomies.php' => 'class-taxonomies.php',
            'class-uc-acf.php' => 'class-acf.php',
            'class-uc-mega-menu.php' => 'class-mega-menu.php',
            'class-uc-logger.php' => 'class-logger.php',
            'class-uc-asset-manager.php' => 'class-asset-manager.php',
            'class-uc-elementor.php' => 'class-elementor-manager.php',
            'class-uc-elementor-navbar-walker.php' => 'class-navbar-walker.php',

            // Widget files
            'class-uc-accordion-widget.php' => 'class-accordion.php',
            'class-uc-heading-widget.php' => 'class-heading.php',
            'class-uc-header-widget.php' => 'class-header.php',
            'class-uc-logo-widget.php' => 'class-logo.php',
            'class-uc-menu-widget.php' => 'class-menu.php',
            'class-uc-button-widget.php' => 'class-button.php',
            'class-uc-tabs-widget.php' => 'class-tabs.php',
            'class-uc-slider-widget.php' => 'class-slider.php',
            'class-uc-icon-box-widget.php' => 'class-icon-box.php',
            'class-uc-image-box-widget.php' => 'class-image-box.php',
            'class-uc-animated-text-widget.php' => 'class-animated-text.php',
            'class-uc-marquee-text-widget.php' => 'class-marquee-text.php',
            'class-uc-portfolio-grid-widget.php' => 'class-portfolio-grid.php',
            'class-uc-team-widget.php' => 'class-team.php',
            'class-uc-team-slider-widget.php' => 'class-team-slider.php',
            'class-uc-testimonials-widget.php' => 'class-testimonials.php',
            'class-uc-price-table-widget.php' => 'class-price-table.php',
            
            // Dynamic tags files
            'class-uc-post-title-tag.php' => 'class-post-title.php',
            'class-uc-post-url-tag.php' => 'class-post-url.php',
            'class-uc-post-excerpt-tag.php' => 'class-post-excerpt.php',
            'class-uc-featured-image-tag.php' => 'class-featured-image.php',
        ];
    }

    public function refactor() {
        // Create backup
        $this->createBackup();

        // Process each PHP file in the plugin directory
        $this->processDirectory($this->plugin_dir);

        // Rename files
        $this->renameFiles();

        echo "Refactoring completed!\n";
    }

    private function createBackup() {
        $backup_dir = $this->plugin_dir . '-backup-' . date('Y-m-d-His');
        $this->recursiveCopy($this->plugin_dir, $backup_dir);
        echo "Backup created at: $backup_dir\n";
    }

    private function recursiveCopy($src, $dst) {
        $dir = opendir($src);
        @mkdir($dst);
        while (($file = readdir($dir)) !== false) {
            if ($file != '.' && $file != '..') {
                if (is_dir($src . '/' . $file)) {
                    $this->recursiveCopy($src . '/' . $file, $dst . '/' . $file);
                } else {
                    copy($src . '/' . $file, $dst . '/' . $file);
                }
            }
        }
        closedir($dir);
    }

    private function processDirectory($dir) {
        $files = glob($dir . '/{,.}*[!.,!..].php', GLOB_BRACE);
        foreach ($files as $file) {
            if (is_file($file)) {
                $this->processFile($file);
            }
        }

        $subdirs = glob($dir . '/*', GLOB_ONLYDIR);
        foreach ($subdirs as $subdir) {
            if (basename($subdir) !== 'vendor' && basename($subdir) !== 'node_modules') {
                $this->processDirectory($subdir);
            }
        }
    }

    private $path_patterns = [
        // File inclusion patterns
        '/require_once\s+UC_PATH\s*\.\s*[\'"]includes\/class-uc-([a-z0-9-]+)\.php[\'"]/i',
        '/require_once\s+UC_PATH\s*\.\s*[\'"]includes\/elementor\/class-uc-([a-z0-9-]+)\.php[\'"]/i',
        '/require_once\s+UC_PATH\s*\.\s*[\'"]includes\/elementor\/widgets\/class-uc-([a-z0-9-]+)\.php[\'"]/i',
        
        // Dynamic path construction patterns
        '/UC_PATH\s*\.\s*[\'"]includes\/elementor\/dynamic-tags\/class-uc-[\'"]\s*\.\s*\$([a-z0-9_]+)\s*\.\s*[\'"]-tag\.php[\'"]/i',
        '/UC_PATH\s*\.\s*[\'"]includes\/elementor\/widgets\/class-uc-[\'"]\s*\.\s*\$([a-z0-9_]+)\s*\.\s*[\'"]-widget\.php[\'"]/i',
        
        // General file path patterns
        '/[\'"]includes\/class-uc-([a-z0-9-]+)\.php[\'"]/i',
        '/[\'"]includes\/elementor\/class-uc-([a-z0-9-]+)\.php[\'"]/i',
        '/[\'"]includes\/elementor\/widgets\/class-uc-([a-z0-9-]+)\.php[\'"]/i'
    ];

    private $path_replacements = [
        // File inclusion replacements
        'require_once UC_PATH . \'includes/class-$1.php\'',
        'require_once UC_PATH . \'includes/elementor/class-$1.php\'',
        'require_once UC_PATH . \'includes/elementor/widgets/class-$1.php\'',
        
        // Dynamic path construction replacements
        'UC_PATH . \'includes/elementor/dynamic-tags/class-\' . $$1 . \'-tag.php\'',
        'UC_PATH . \'includes/elementor/widgets/class-\' . $$1 . \'-widget.php\'',
        
        // General file path replacements
        '\'includes/class-$1.php\'',
        '\'includes/elementor/class-$1.php\'',
        '\'includes/elementor/widgets/class-$1.php\''
    ];

    private function updateClassConstants($content) {
        // Update ::class constant references
        foreach ($this->class_map as $old => $new) {
            $content = preg_replace(
                '/' . preg_quote($old . '::class', '/') . '/',
                $new . '::class',
                $content
            );
        }

        // Update array definitions with class constants
        $widget_patterns = [
            // Match array assignments with ::class
            '/([\'"][\w_]+[\'"]\s*=>\s*)[\w_]+::class/',
            // Match array assignments with full class names
            '/([\'"][\w_]+[\'"]\s*=>\s*)[\w_\\\\]+/'
        ];

        foreach ($widget_patterns as $pattern) {
            preg_match_all($pattern, $content, $matches, PREG_SET_ORDER);
            
            foreach ($matches as $match) {
                $key = $match[1];
                $old_class = trim(str_replace('::class', '', $match[0]));
                
                if (isset($this->class_map[$old_class])) {
                    $new_class = $this->class_map[$old_class];
                    $content = str_replace(
                        $match[0],
                        $key . $new_class . '::class',
                        $content
                    );
                }
            }
        }

        return $content;
    }

    private function processFile($file) {
        $content = file_get_contents($file);
        $original_content = $content;

        // Add namespace
        $relative_path = str_replace($this->plugin_dir . '/', '', $file);
        $namespace = $this->getNamespaceForFile($relative_path);
        if ($namespace) {
            $content = $this->addNamespace($content, $namespace);
        }

        // Update class references
        foreach ($this->class_map as $old => $new) {
            $content = $this->updateClassReferences($content, $old, $new);
        }

        // Update class constants
        $content = $this->updateClassConstants($content);

        // Update file paths
        foreach ($this->path_patterns as $index => $pattern) {
            $content = preg_replace(
                $pattern,
                $this->path_replacements[$index],
                $content
            );
        }

        // Add use statements where needed
        $content = $this->addUseStatements($content);

        if ($content !== $original_content) {
            file_put_contents($file, $content);
            echo "Updated: $file\n";
        }
    }

    private function updateConstructorInitializations($content) {
        // Update property initializations
        foreach ($this->class_map as $old => $new) {
            $old_base = preg_replace('/^UC_/', '', $old);
            $new_base = basename(str_replace('\\', '/', $new));
            
            // Pattern matches property initialization with old class name
            $pattern = '/\$this->([a-z_]+)\s*=\s*' . preg_quote($old, '/') . '::getInstance\(\)/i';
            $replacement = '$this->$1 = ' . $new_base . '::getInstance()';
            
            $content = preg_replace($pattern, $replacement, $content);
        }

        return $content;
    }

    private function getNamespaceForFile($relative_path) {
        foreach ($this->namespace_map as $dir => $namespace) {
            if (strpos($relative_path, $dir) === 0) {
                return $namespace;
            }
        }
        return null;
    }

    private function addNamespace($content, $namespace) {
        // Remove existing namespace if present
        $content = preg_replace('/^namespace.*?;[\r\n]+/s', '', $content);

        // Add new namespace after opening PHP tag
        $content = preg_replace(
            '/^(<\?php.*?)([\r\n]+)/s',
            "$1\n\nnamespace $namespace;$2",
            $content
        );

        return $content;
    }

    private function updateClassReferences($content, $old, $new) {
        // Update class definitions
        $content = preg_replace(
            '/class\s+' . preg_quote($old, '/') . '(?=[\s{])/i',
            'class ' . basename(str_replace('\\', '/', $new)),
            $content
        );

        // Update static calls
        $content = preg_replace(
            '/' . preg_quote($old, '/') . '::/i',
            basename(str_replace('\\', '/', $new)) . '::',
            $content
        );

        // Update new instance creation
        $content = preg_replace(
            '/new\s+' . preg_quote($old, '/') . '(?=[\s(])/i',
            'new ' . basename(str_replace('\\', '/', $new)),
            $content
        );

        return $content;
    }

    private function addUseStatements($content) {
        // Find all class references including getInstance() calls
        $patterns = array_map(function($class) {
            return '\b' . preg_quote($class, '/') . '(?=\s*::|::getInstance\(\))';
        }, array_keys($this->class_map));
        
        $pattern = '/' . implode('|', $patterns) . '/';
        preg_match_all($pattern, $content, $matches);
        
        $use_statements = [];
        foreach ($matches[0] as $match) {
            if (isset($this->class_map[$match])) {
                $use_statements[] = "use " . $this->class_map[$match] . ";";
            }
        }

        if (!empty($use_statements)) {
            $use_statements = array_unique($use_statements);
            sort($use_statements);
            $use_block = "\n" . implode("\n", $use_statements) . "\n";

            // Add use statements after namespace
            $content = preg_replace(
                '/(namespace.*?;[\r\n]+)/s',
                "$1$use_block",
                $content
            );
        }

        return $content;
    }

    private function renameFiles() {
        foreach ($this->file_map as $old => $new) {
            $old_path = $this->findFile($old);
            if ($old_path) {
                $new_path = dirname($old_path) . '/' . $new;
                if (rename($old_path, $new_path)) {
                    echo "Renamed: $old to $new\n";
                }
            }
        }
    }

    private function findFile($filename) {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($this->plugin_dir)
        );

        foreach ($iterator as $file) {
            if ($file->getFilename() === $filename) {
                return $file->getPathname();
            }
        }

        return null;
    }
}

// Usage
$refactor = new PluginRefactor(__DIR__);
$refactor->refactor();