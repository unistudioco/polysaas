(function($) {
    'use strict';
    
    // Process special links when the document is ready
    $(document).ready(function() {
        // Process any existing links
        processSpecialLinks();
        
        // Set up a MutationObserver to catch dynamically added links
        setupMutationObserver();
    });
    
    /**
     * Process all links that point to offcanvas or popup elements
     */
    function processSpecialLinks() {
        // Find all links that point to offcanvas or popup elements
        var specialLinks = $('a[href^="#uc-offcanvas-"], a[href^="#uc-popup-"]');
        
        specialLinks.each(function() {
            var link = $(this);
            var href = link.attr('href');
            
            // Add the data-uc-toggle attribute if it doesn't already have one
            if (!link.attr('data-uc-toggle')) {
                link.attr('data-uc-toggle', 'target: ' + href);
            }
            
            // Add appropriate class to the link
            if (href.indexOf('offcanvas') > -1) {
                link.addClass('uc-offcanvas-trigger');
            } else if (href.indexOf('popup') > -1) {
                link.addClass('uc-popup-trigger');
            }
        });
    }
    
    /**
     * Set up a MutationObserver to watch for dynamic content changes
     */
    function setupMutationObserver() {
        // Only set up if the browser supports MutationObserver
        if (!window.MutationObserver) {
            return;
        }
        
        // Create an observer instance
        var observer = new MutationObserver(function(mutations) {
            // Check if we need to process links after DOM changes
            var needsProcessing = false;
            
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    for (var i = 0; i < mutation.addedNodes.length; i++) {
                        var node = mutation.addedNodes[i];
                        
                        // Check if the added node is an element and might contain links
                        if (node.nodeType === 1) {
                            if (node.tagName === 'A' || $(node).find('a').length > 0) {
                                needsProcessing = true;
                                break;
                            }
                        }
                    }
                }
            });
            
            // Process links if needed
            if (needsProcessing) {
                processSpecialLinks();
            }
        });
        
        // Configure the observer to watch for changes to the entire document
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }
    
})(jQuery);