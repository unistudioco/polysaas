<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// General Controls
$easing_options = [
    'linear' => __( 'Linear', 'animejs-elementor-addon' ),
    'easeInQuad' => __( 'EaseInQuad', 'animejs-elementor-addon' ),
    'easeInCubic' => __( 'EaseInCubic', 'animejs-elementor-addon' ),
    'easeInQuart' => __( 'EaseInQuart', 'animejs-elementor-addon' ),
    'easeInQuint' => __( 'EaseInQuint', 'animejs-elementor-addon' ),
    'easeInSine' => __( 'EaseInSine', 'animejs-elementor-addon' ),
    'easeInExpo' => __( 'EaseInExpo', 'animejs-elementor-addon' ),
    'easeInCirc' => __( 'EaseInCirc', 'animejs-elementor-addon' ),
    'easeInBack' => __( 'EaseInBack', 'animejs-elementor-addon' ),
    'easeOutQuad' => __( 'EaseOutQuad', 'animejs-elementor-addon' ),
    'easeOutCubic' => __( 'EaseOutCubic', 'animejs-elementor-addon' ),
    'easeOutQuart' => __( 'EaseOutQuart', 'animejs-elementor-addon' ),
    'easeOutQuint' => __( 'EaseOutQuint', 'animejs-elementor-addon' ),
    'easeOutSine' => __( 'EaseOutSine', 'animejs-elementor-addon' ),
    'easeOutExpo' => __( 'EaseOutExpo', 'animejs-elementor-addon' ),
    'easeOutCirc' => __( 'EaseOutCirc', 'animejs-elementor-addon' ),
    'easeOutBack' => __( 'EaseOutBack', 'animejs-elementor-addon' ),
    'easeInBounce' => __( 'EaseInBounce', 'animejs-elementor-addon' ),
    'easeInOutQuad' => __( 'EaseInOutQuad', 'animejs-elementor-addon' ),
    'easeInOutCubic' => __( 'EaseInOutCubic', 'animejs-elementor-addon' ),
    'easeInOutQuart' => __( 'EaseInOutQuart', 'animejs-elementor-addon' ),
    'easeInOutQuint' => __( 'EaseInOutQuint', 'animejs-elementor-addon' ),
    'easeInOutSine' => __( 'EaseInOutSine', 'animejs-elementor-addon' ),
    'easeInOutExpo' => __( 'EaseInOutExpo', 'animejs-elementor-addon' ),
    'easeInOutCirc' => __( 'EaseInOutCirc', 'animejs-elementor-addon' ),
    'easeInOutBack' => __( 'EaseInOutBack', 'animejs-elementor-addon' ),
    'easeInOutBounce' => __( 'EaseInOutBounce', 'animejs-elementor-addon' ),
    'easeOutBounce' => __( 'EaseOutBounce', 'animejs-elementor-addon' ),
    'easeOutInQuad' => __( 'EaseOutInQuad', 'animejs-elementor-addon' ),
    'easeOutInCubic' => __( 'EaseOutInCubic', 'animejs-elementor-addon' ),
    'easeOutInQuart' => __( 'EaseOutInQuart', 'animejs-elementor-addon' ),
    'easeOutInQuint' => __( 'EaseOutInQuint', 'animejs-elementor-addon' ),
    'easeOutInSine' => __( 'EaseOutInSine', 'animejs-elementor-addon' ),
    'easeOutInExpo' => __( 'EaseOutInExpo', 'animejs-elementor-addon' ),
    'easeOutInCirc' => __( 'EaseOutInCirc', 'animejs-elementor-addon' ),
    'easeOutInBack' => __( 'EaseOutInBack', 'animejs-elementor-addon' ),
    'easeOutInBounce' => __( 'EaseOutInBounce', 'animejs-elementor-addon' ),
    'custom' => __( 'Custom', 'animejs-elementor-addon' ),
];

$element->add_control(
    'animejs_animation_speed',
    [
        'label' => esc_html__( 'Speed (ms)', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'min' => 0,
        'max' => 5000,
        'step' => 50,
        'default' => 500,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_delay',
    [
        'label' => esc_html__( 'Delay (ms)', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'min' => 0,
        'max' => 5000,
        'step' => 50,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_easing',
    [
        'label' => __( 'Easing', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::SELECT,
        'options' => $easing_options,
        'default' => 'easeInCubic',
        'condition' => [
            'animejs_animation_type' => 'onview',
        ],
    ]
);

$element->add_control(
    'animejs_animation_easing_custom',
    [
        'label' => __( 'Custom Easing Function', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::TEXT,
        'label_block' => true,
        'default' => 'cubicBezier(1, 0, 0, 1)',
		'ai' => [
			'active' => false,
		],
        'condition' => [
            'animejs_animation_type' => 'onview',
            'animejs_animation_easing' => 'custom',
        ],
    ]
);

$element->add_control(
    'animejs_animation_enter',
    [
        'label' => esc_html__( 'Enter Animations', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->start_popover();

$element->add_control(
    'animejs_animation_from_opacity',
    [
        'label' => esc_html__( 'Opacity', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'min' => 0,
        'max' => 1,
        'step' => 0.1,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_from_translateX',
    [
        'label' => __( 'Translate X', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_from_translateY',
    [
        'label' => __( 'Translate Y', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_from_scale',
    [
        'label' => __( 'Scale', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 1,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_from_rotate',
    [
        'label' => __( 'Rotate', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_from_skew',
    [
        'label' => __( 'Skew', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->end_popover();

$element->add_control(
    'animejs_animation_exit',
    [
        'label' => esc_html__( 'Exit Animations', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::POPOVER_TOGGLE,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->start_popover();

$element->add_control(
    'animejs_animation_to_opacity',
    [
        'label' => esc_html__( 'Opacity', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'min' => 0,
        'max' => 1,
        'step' => 0.1,
        'default' => 1,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_to_translateX',
    [
        'label' => __( 'Translate X', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_to_translateY',
    [
        'label' => __( 'Translate Y', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_to_scale',
    [
        'label' => __( 'Scale', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 1,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_to_rotate',
    [
        'label' => __( 'Rotate', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->add_control(
    'animejs_animation_to_skew',
    [
        'label' => __( 'Skew', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 0,
        'condition' => [
            'animejs_animation_type!' => 'disable',
        ],
    ]
);

$element->end_popover();