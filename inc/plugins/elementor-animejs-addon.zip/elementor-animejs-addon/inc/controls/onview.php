<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// OnView Controls
$element->add_control(
    'animejs_onview_enable',
    [
        'label' => __( 'On Viewport?', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'default' => 'yes',
        'condition' => [
            'animejs_animation_type' => 'onview',
        ],
    ]
);

$element->add_control(
    'animejs_onview_trigger_viewport',
    [
        'label' => __( 'Trigger Viewport', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => -100,
        'condition' => [
            'animejs_onview_enable' => 'yes',
            'animejs_animation_type' => 'onview',
        ],
    ]
);

$element->add_control(
    'animejs_onview_direction',
    [
        'label' => esc_html__( 'Direction', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::CHOOSE,
        'options' => [
            'normal' => [
                'title' => esc_html__( 'Normal', 'animejs-elementor-addon' ),
                'icon' => 'eicon-long-arrow-right',
            ],
            'alternate' => [
                'title' => esc_html__( 'Alternate', 'animejs-elementor-addon' ),
                'icon' => 'eicon-exchange',
            ],
            'reverse' => [
                'title' => esc_html__( 'Reverse', 'animejs-elementor-addon' ),
                'icon' => 'eicon-undo',
            ],
        ],
        'default' => 'normal',
        'toggle' => false,
        'condition' => [
            'animejs_animation_type' => 'onview',
        ],
    ]
);

$element->add_control(
    'animejs_onview_repeat',
    [
        'label' => esc_html__( 'Loop', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::SWITCHER,
        'label_on' => esc_html__( 'Yes', 'animejs-elementor-addon' ),
        'label_off' => esc_html__( 'No', 'animejs-elementor-addon' ),
        'return_value' => 'yes',
        'default' => '',
        'condition' => [
            'animejs_animation_type' => 'onview',
        ],
    ]
);

$element->add_control(
    'animejs_onview_targets',
    [
        'label' => __( 'Targets', 'animejs-elementor-addon' ),
        'description' => 'A CSS Selector to target child elements, keep it empty if you want this animation apply to the current element.',
        'type' => \Elementor\Controls_Manager::TEXT,
		'ai' => [
			'active' => false,
		],
        'condition' => [
            'animejs_animation_type' => 'onview',
        ],
    ]
);

$element->add_control(
    'animejs_onview_staggering',
    [
        'label' => __( 'Staggering Delay (ms)', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 100,
        'condition' => [
            'animejs_animation_type' => 'onview',
            'animejs_onview_targets!' => '',
        ],
    ]
);

$element->add_control(
    'animejs_onview_staggering_from',
    [
        'label' => __( 'From', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::SELECT,
        'options' => [
            'first' => __( 'First', 'animejs-elementor-addon' ),
            'center' => __( 'Center', 'animejs-elementor-addon' ),
            'last' => __( 'Last', 'animejs-elementor-addon' ),
        ],
        'default' => 'first',
        'condition' => [
            'animejs_animation_type' => 'onview',
            'animejs_onview_targets!' => '',
        ],
    ]
);

$element->add_control(
    'animejs_onview_staggering_start_after',
    [
        'label' => __( 'Start after (ms)', 'animejs-elementor-addon' ),
        'type' => \Elementor\Controls_Manager::NUMBER,
        'default' => 500,
        'condition' => [
            'animejs_animation_type' => 'onview',
            'animejs_onview_targets!' => '',
        ],
    ]
);