<?php
/**
 * Plugin Name: Elementor AnimeJS Addon
 * Plugin URI: https://unistudio.co/elementor-animejs-addon
 * Description: Bring the power of AnimeJS advanced animations to all of your Elementor widgets and containers.
 * Version: 1.0.0
 * Elementor tested up to: 3.16.4
 * Author: UniStudio (Oussama Byr)
 * Author URI: https://unistudio.co
 * Text Domain: elementor-animejs-addon
 * Domain Path: /languages
 * License: GPL3
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Load the addon class.
require_once( __DIR__ . '/inc/class-elementor-animejs-addon.php' );